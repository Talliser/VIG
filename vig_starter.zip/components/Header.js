import Link from "next/link";

export default function Header(){
  return (
    <header className="w-full py-4 px-6 flex items-center justify-between card-glass">
      <div className="flex items-center gap-3">
        <div className="rounded-md p-2 bg-[var(--vig-primary)] text-white font-bold">VIG</div>
        <div>
          <div className="font-semibold">VIG</div>
          <div className="text-xs subtle">Verified Info Guide</div>
        </div>
      </div>

      <nav className="flex items-center gap-4">
        <Link href="/"><a className="text-sm hover:text-[var(--vig-primary)]">Главная</a></Link>
        <Link href="/catalog"><a className="text-sm hover:text-[var(--vig-primary)]">Каталог</a></Link>
        <Link href="/compare"><a className="text-sm hover:text-[var(--vig-primary)]">Сравнение</a></Link>
      </nav>
    </header>
  )
}
