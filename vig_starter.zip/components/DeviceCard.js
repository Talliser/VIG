import Link from "next/link";

export default function DeviceCard({device}){
  return (
    <div className="card-glass p-4 rounded-xl w-full">
      <div className="flex gap-4">
        <div className="w-28 h-28 bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
          {device.image ? <img src={device.image} alt={device.model} className="object-cover w-full h-full" /> : <div className="text-sm subtle">No image</div>}
        </div>
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-md font-semibold">{device.brand} {device.model}</div>
              <div className="subtle text-sm">{device.cpu} • {device.screen}</div>
            </div>
            <div className="text-right">
              <div className="text-sm subtle">VIG Score</div>
              <div className="text-lg font-semibold">{device.vigScore}</div>
            </div>
          </div>

          <div className="mt-3 flex gap-2 items-center">
            <div className="px-2 py-1 rounded-md bg-[var(--vig-primary)]/10 text-[var(--vig-primary)] text-xs">Perf {device.performanceScore}</div>
            <div className="px-2 py-1 rounded-md bg-[var(--vig-accent)]/10 text-[var(--vig-accent)] text-xs">Cam {device.cameraScore}</div>
            <div className="px-2 py-1 rounded-md bg-green-100 text-green-800 text-xs">Bat {device.batteryScore}</div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <Link href={`/device/${device.id}`}><a className="text-sm text-[var(--vig-primary)]">Открыть</a></Link>
            <div className="text-xs subtle">{device.notes?.join(" • ")}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
