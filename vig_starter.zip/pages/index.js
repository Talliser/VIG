import fs from "fs";
import path from "path";
import DeviceCard from "../components/DeviceCard";

export default function Home({ devices }){
  return (
    <>
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold">VIG — Verified Info Guide</h1>
            <p className="subtle">All about Vivo & IQOO — Smart. Simple. Verified.</p>
          </div>
          <div className="w-96">
            <input placeholder="🔍 Найди модель Vivo или IQOO" className="w-full rounded-lg p-3 border border-gray-200" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {devices.slice(0,2).map(d => (
            <DeviceCard key={d.id} device={d} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Последние обзоры и тесты</h2>
        <div className="grid grid-cols-3 gap-4">
          <div className="card-glass p-4 rounded-xl">Тест: IQOO 12 — производительность и троттлинг (мини-превью)</div>
          <div className="card-glass p-4 rounded-xl">Обзор: Vivo X200 — камера в реальных условиях</div>
          <div className="card-glass p-4 rounded-xl">Рейтинг SoC — кто лидер?</div>
        </div>
      </section>
    </>
  )
}

export async function getStaticProps(){
  const file = path.join(process.cwd(), "data", "devices.json");
  const devices = JSON.parse(fs.readFileSync(file, "utf8"));
  return { props: { devices } }
}
