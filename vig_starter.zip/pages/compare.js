import fs from "fs";
import path from "path";

export default function Compare({ devices }){
  const left = devices[0];
  const right = devices[1];

  const perfDiff = left.performanceScore - right.performanceScore;
  const summary = perfDiff > 0
    ? `${left.brand} ${left.model} быстрее примерно на ${Math.round((perfDiff/ right.performanceScore)*100)}%`
    : `${right.brand} ${right.model} имеет преимущество в производительности`

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Сравнение</h1>

      <div className="grid grid-cols-2 gap-4">
        <div className="card-glass p-4">
          <h3 className="font-semibold">{left.brand} {left.model}</h3>
          <div className="subtle">Perf {left.performanceScore} • Cam {left.cameraScore} • Bat {left.batteryScore}</div>
        </div>
        <div className="card-glass p-4">
          <h3 className="font-semibold">{right.brand} {right.model}</h3>
          <div className="subtle">Perf {right.performanceScore} • Cam {right.cameraScore} • Bat {right.batteryScore}</div>
        </div>
      </div>

      <div className="card-glass p-4">
        <strong>AI-резюме: </strong>{summary}
      </div>
    </div>
  )
}

export async function getStaticProps(){
  const file = path.join(process.cwd(), "data", "devices.json");
  const devices = JSON.parse(fs.readFileSync(file, "utf8"));
  return { props: { devices } }
}
