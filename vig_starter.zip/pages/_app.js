import "../styles/globals.css";
import Header from "../components/Header";

export default function App({ Component, pageProps }){
  return (
    <div className="min-h-screen bg-[var(--vig-bg)]">
      <Header />
      <main className="max-w-6xl mx-auto px-6 py-8">
        <Component {...pageProps} />
      </main>
    </div>
  )
}
