import fs from "fs";
import path from "path";

export default function DevicePage({ device }){
  if (!device) return <div>Устройство не найдено</div>;

  return (
    <div className="space-y-6">
      <div className="flex gap-6 items-start">
        <div className="w-48 h-48 bg-gray-100 rounded-xl overflow-hidden flex items-center justify-center">
          {device.image ? <img src={device.image} alt={device.model} className="object-cover w-full h-full" /> : null}
        </div>

        <div className="flex-1">
          <h1 className="text-2xl font-bold">{device.brand} {device.model}</h1>
          <div className="subtle">{device.cpu} • {device.screen} • {device.year}</div>
          <div className="mt-4 flex gap-2">
            <div className="px-3 py-1 rounded-md bg-[var(--vig-primary)]/10 text-[var(--vig-primary)]">Perf {device.performanceScore}</div>
            <div className="px-3 py-1 rounded-md bg-[var(--vig-accent)]/10 text-[var(--vig-accent)]">Cam {device.cameraScore}</div>
            <div className="px-3 py-1 rounded-md bg-green-100 text-green-800">Bat {device.batteryScore}</div>
          </div>
        </div>

        <div className="w-40 card-glass p-4 rounded-xl">
          <div className="text-sm subtle">VIG Score</div>
          <div className="text-3xl font-bold">{device.vigScore}</div>
          <div className="mt-2 text-xs subtle">AI Rank: {device.vigScore > 85 ? "Top-tier" : "Balanced"}</div>
        </div>
      </div>

      <section className="card-glass p-4 rounded-xl">
        <h3 className="font-semibold mb-2">Характеристики</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="subtle">CPU</div>
            <div>{device.cpu}</div>
          </div>
          <div>
            <div className="subtle">Экран</div>
            <div>{device.screen}</div>
          </div>
          <div>
            <div className="subtle">Батарея</div>
            <div>{device.battery} mAh</div>
          </div>
          <div>
            <div className="subtle">Камера</div>
            <div>{device.camera.main_mp} MP • {device.camera.sensor}</div>
          </div>
        </div>
      </section>
    </div>
  )
}

export async function getStaticPaths(){
  const file = path.join(process.cwd(), "data", "devices.json");
  const devices = JSON.parse(fs.readFileSync(file, "utf8"));
  const paths = devices.map(d => ({ params: { id: d.id } }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params }){
  const file = path.join(process.cwd(), "data", "devices.json");
  const devices = JSON.parse(fs.readFileSync(file, "utf8"));
  const device = devices.find(d => d.id === params.id) || null;
  return { props: { device } }
}
