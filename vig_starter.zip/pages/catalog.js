import fs from "fs";
import path from "path";
import DeviceCard from "../components/DeviceCard";

export default function Catalog({ devices }){
  return (
    <>
      <div className="flex gap-6">
        <aside className="w-64 space-y-4">
          <div className="card-glass p-4">Фильтры (серия, цена, CPU)</div>
        </aside>

        <section className="flex-1">
          <h1 className="text-2xl font-semibold mb-4">Каталог устройств</h1>
          <div className="grid grid-cols-2 gap-4">
            {devices.map(d => <DeviceCard key={d.id} device={d} />)}
          </div>
        </section>
      </div>
    </>
  );
}

export async function getStaticProps(){
  const file = path.join(process.cwd(), "data", "devices.json");
  const devices = JSON.parse(fs.readFileSync(file, "utf8"));
  return { props: { devices } }
}
