export function formatDownloads(num: number): string {
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(2) + ' млрд';
  }
  if (num >= 1000000) {
    return (num / 1000000).toFixed(2) + ' млн';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + ' тыс';
  }
  return num.toString();
}

export function formatNumber(num: number): string {
  return formatDownloads(num);
}

export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  const diffWeeks = Math.floor(diffDays / 7);
  const diffMonths = Math.floor(diffDays / 30);
  const diffYears = Math.floor(diffDays / 365);

  if (diffMins < 1) return 'только что';
  if (diffMins < 60) return `${diffMins} мин. назад`;
  if (diffHours < 24) return `${diffHours} ч. назад`;
  if (diffDays < 7) return `${diffDays} дн. назад`;
  if (diffWeeks < 5) return `${diffWeeks} нед. назад`;
  if (diffMonths < 12) return `${diffMonths} мес. назад`;
  return `${diffYears} г. назад`;
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}
