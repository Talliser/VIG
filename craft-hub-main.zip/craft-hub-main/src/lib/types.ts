export type Edition = 'java' | 'bedrock';

export type Loader = 
  | 'fabric' 
  | 'forge' 
  | 'neoforge' 
  | 'quilt' 
  | 'liteloader'
  | 'rift'
  | 'modloader';

export type Category = 
  | 'adventure'
  | 'decoration'
  | 'economy'
  | 'equipment'
  | 'food'
  | 'library'
  | 'magic'
  | 'management'
  | 'minigame'
  | 'mobs'
  | 'optimization'
  | 'social'
  | 'storage'
  | 'technology'
  | 'transportation'
  | 'utility'
  | 'worldgen';

export interface ModAuthor {
  id: string;
  username: string;
  avatar?: string;
  verified?: boolean;
}

export interface ModVersion {
  id: string;
  version: string;
  minecraftVersions: string[];
  loaders: Loader[];
  releaseDate: string;
  downloads: number;
  fileSize: string;
  changelog?: string;
}

export interface Mod {
  id: string;
  slug: string;
  name: string;
  summary: string;
  description: string;
  icon: string;
  banner?: string;
  gallery: string[];
  edition: Edition;
  categories: Category[];
  loaders: Loader[];
  minecraftVersions: string[];
  author: ModAuthor;
  downloads: number;
  views: number;
  rating: number;
  ratingCount: number;
  createdAt: string;
  updatedAt: string;
  versions: ModVersion[];
  featured?: boolean;
  tags: string[];
}

export interface Comment {
  id: string;
  userId: string;
  username: string;
  userAvatar?: string;
  content: string;
  rating?: number;
  createdAt: string;
  likes: number;
  replies?: Comment[];
}

export type SortOption = 
  | 'downloads' 
  | 'updated' 
  | 'created' 
  | 'rating'
  | 'views'
  | 'comments';

export interface FilterState {
  edition?: Edition;
  categories: Category[];
  loaders: Loader[];
  minecraftVersions: string[];
  search: string;
  sort: SortOption;
}
