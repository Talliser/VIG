import type { Category, Loader, SortOption } from './types';

export const CATEGORIES: { id: Category; name: string; icon: string }[] = [
  { id: 'adventure', name: 'Приключения', icon: '🗺️' },
  { id: 'decoration', name: 'Декор', icon: '🎨' },
  { id: 'economy', name: 'Экономика', icon: '💰' },
  { id: 'equipment', name: 'Снаряжение', icon: '⚔️' },
  { id: 'food', name: 'Еда', icon: '🍖' },
  { id: 'library', name: 'Библиотеки', icon: '📚' },
  { id: 'magic', name: 'Магия', icon: '✨' },
  { id: 'management', name: 'Управление', icon: '📊' },
  { id: 'minigame', name: 'Мини-игры', icon: '🎮' },
  { id: 'mobs', name: 'Мобы', icon: '🐲' },
  { id: 'optimization', name: 'Оптимизация', icon: '⚡' },
  { id: 'social', name: 'Социальное', icon: '👥' },
  { id: 'storage', name: 'Хранение', icon: '📦' },
  { id: 'technology', name: 'Технологии', icon: '⚙️' },
  { id: 'transportation', name: 'Транспорт', icon: '🚂' },
  { id: 'utility', name: 'Утилиты', icon: '🔧' },
  { id: 'worldgen', name: 'Генерация мира', icon: '🌍' },
];

export const LOADERS: { id: Loader; name: string; color: string }[] = [
  { id: 'fabric', name: 'Fabric', color: 'fabric' },
  { id: 'forge', name: 'Forge', color: 'forge' },
  { id: 'neoforge', name: 'NeoForge', color: 'neoforge' },
  { id: 'quilt', name: 'Quilt', color: 'quilt' },
  { id: 'liteloader', name: 'LiteLoader', color: 'category' },
  { id: 'rift', name: 'Rift', color: 'category' },
  { id: 'modloader', name: 'ModLoader', color: 'category' },
];

export const MINECRAFT_VERSIONS = [
  '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
  '1.20.6', '1.20.4', '1.20.2', '1.20.1', '1.20',
  '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
  '1.18.2', '1.18.1', '1.18',
  '1.17.1', '1.17',
  '1.16.5', '1.16.4', '1.16.3',
  '1.12.2', '1.12.1', '1.12',
  '1.8.9', '1.7.10',
];

export const SORT_OPTIONS: { id: SortOption; label: string }[] = [
  { id: 'downloads', label: 'По загрузкам' },
  { id: 'updated', label: 'По дате обновления' },
  { id: 'created', label: 'По дате создания' },
  { id: 'rating', label: 'По рейтингу' },
  { id: 'views', label: 'По просмотрам' },
];
