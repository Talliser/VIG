import { Mod, Category, Loader } from './types';

export const CATEGORIES: { id: Category; name: string; icon: string }[] = [
  { id: 'adventure', name: 'Приключения', icon: '🗺️' },
  { id: 'decoration', name: 'Декор', icon: '🎨' },
  { id: 'economy', name: 'Экономика', icon: '💰' },
  { id: 'equipment', name: 'Снаряжение', icon: '⚔️' },
  { id: 'food', name: 'Еда', icon: '🍖' },
  { id: 'library', name: 'Библиотеки', icon: '📚' },
  { id: 'magic', name: 'Магия', icon: '✨' },
  { id: 'management', name: 'Управление', icon: '📊' },
  { id: 'minigame', name: 'Мини-игры', icon: '🎮' },
  { id: 'mobs', name: 'Мобы', icon: '🐲' },
  { id: 'optimization', name: 'Оптимизация', icon: '⚡' },
  { id: 'social', name: 'Социальное', icon: '👥' },
  { id: 'storage', name: 'Хранение', icon: '📦' },
  { id: 'technology', name: 'Технологии', icon: '⚙️' },
  { id: 'transportation', name: 'Транспорт', icon: '🚂' },
  { id: 'utility', name: 'Утилиты', icon: '🔧' },
  { id: 'worldgen', name: 'Генерация мира', icon: '🌍' },
];

export const LOADERS: { id: Loader; name: string; color: string }[] = [
  { id: 'fabric', name: 'Fabric', color: 'fabric' },
  { id: 'forge', name: 'Forge', color: 'forge' },
  { id: 'neoforge', name: 'NeoForge', color: 'neoforge' },
  { id: 'quilt', name: 'Quilt', color: 'quilt' },
  { id: 'liteloader', name: 'LiteLoader', color: 'category' },
  { id: 'rift', name: 'Rift', color: 'category' },
  { id: 'modloader', name: 'ModLoader', color: 'category' },
];

export const MINECRAFT_VERSIONS = [
  '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
  '1.20.6', '1.20.4', '1.20.2', '1.20.1', '1.20',
  '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
  '1.18.2', '1.18.1', '1.18',
  '1.17.1', '1.17',
  '1.16.5', '1.16.4', '1.16.3',
  '1.12.2', '1.12.1', '1.12',
  '1.8.9', '1.7.10',
];

export const MOCK_MODS: Mod[] = [
  {
    id: '1',
    slug: 'sodium',
    name: 'Sodium',
    summary: 'Современный рендер-движок для Minecraft, значительно повышающий FPS',
    description: `# Sodium

Sodium — это бесплатный и с открытым исходным кодом мод для оптимизации рендеринга, который значительно улучшает частоту кадров и уменьшает подтормаживания.

## Особенности

- **Улучшенная производительность**: Значительное увеличение FPS
- **Оптимизированный рендеринг**: Переработанный движок рендеринга чанков
- **Совместимость**: Работает с большинством модов

## Установка

1. Установите Fabric Loader
2. Скачайте Sodium
3. Поместите в папку mods`,
    icon: 'https://cdn.modrinth.com/data/AANobbMI/icon.png',
    banner: 'https://cdn.modrinth.com/data/AANobbMI/images/7e7c9f8f4b4a7c7d9e8f4b4a7c7d9e8f.png',
    gallery: [
      'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=800',
      'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800',
    ],
    edition: 'java',
    categories: ['optimization', 'utility'],
    loaders: ['fabric', 'quilt'],
    minecraftVersions: ['1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21', '1.20.6', '1.20.4', '1.20.1'],
    author: {
      id: 'jellysquid',
      username: 'JellySquid',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=JellySquid',
      verified: true,
    },
    downloads: 89500000,
    views: 156000000,
    rating: 4.9,
    ratingCount: 45230,
    createdAt: '2020-04-15T10:30:00Z',
    updatedAt: '2024-12-20T14:25:00Z',
    versions: [
      {
        id: 'v1',
        version: '0.6.0',
        minecraftVersions: ['1.21.4', '1.21.3'],
        loaders: ['fabric'],
        releaseDate: '2024-12-20T14:25:00Z',
        downloads: 2500000,
        fileSize: '1.2 MB',
      },
    ],
    featured: true,
    tags: ['fps', 'performance', 'optimization', 'rendering'],
  },
  {
    id: '2',
    slug: 'fabric-api',
    name: 'Fabric API',
    summary: 'Легковесный и модульный API для модов Fabric',
    description: `# Fabric API

Fabric API — это основная библиотека для разработки модов на Fabric. Предоставляет общие хуки и утилиты для модификации игры.

## Для разработчиков

Fabric API предоставляет множество модулей для различных аспектов моддинга.`,
    icon: 'https://cdn.modrinth.com/data/P7dR8mSH/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['library'],
    loaders: ['fabric'],
    minecraftVersions: ['1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21', '1.20.6', '1.20.4', '1.20.1'],
    author: {
      id: 'modmuss50',
      username: 'modmuss50',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=modmuss50',
      verified: true,
    },
    downloads: 109930000,
    views: 234000000,
    rating: 4.8,
    ratingCount: 12450,
    createdAt: '2019-01-10T08:00:00Z',
    updatedAt: '2024-12-28T09:15:00Z',
    versions: [],
    featured: true,
    tags: ['api', 'library', 'fabric', 'modding'],
  },
  {
    id: '3',
    slug: 'create',
    name: 'Create',
    summary: 'Технический мод с красивой эстетикой и инженерными механизмами',
    description: `# Create

Create — это мод, который добавляет множество механизмов и устройств для автоматизации и транспортировки.

## Основные возможности

- Ротационная механика
- Конвейерные системы
- Поезда и железные дороги
- Схематики`,
    icon: 'https://cdn.modrinth.com/data/LNytGWDc/icon.png',
    gallery: [
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800',
      'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800',
    ],
    edition: 'java',
    categories: ['technology', 'transportation', 'decoration'],
    loaders: ['forge', 'fabric', 'neoforge'],
    minecraftVersions: ['1.20.1', '1.19.2', '1.18.2'],
    author: {
      id: 'simibubi',
      username: 'simibubi',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=simibubi',
      verified: true,
    },
    downloads: 67800000,
    views: 123000000,
    rating: 4.95,
    ratingCount: 89340,
    createdAt: '2020-02-20T12:00:00Z',
    updatedAt: '2024-11-15T16:30:00Z',
    versions: [],
    featured: true,
    tags: ['automation', 'technology', 'trains', 'engineering'],
  },
  {
    id: '4',
    slug: 'jei',
    name: 'Just Enough Items (JEI)',
    summary: 'Просмотр предметов и рецептов для Minecraft',
    description: `# Just Enough Items

JEI — это мод для просмотра предметов и рецептов. Позволяет легко находить рецепты крафта и использования предметов.`,
    icon: 'https://cdn.modrinth.com/data/u6dRKJwZ/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['utility', 'library'],
    loaders: ['forge', 'neoforge'],
    minecraftVersions: ['1.21.4', '1.21.1', '1.20.6', '1.20.1', '1.19.4', '1.18.2'],
    author: {
      id: 'mezz',
      username: 'mezz',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mezz',
      verified: true,
    },
    downloads: 234500000,
    views: 456000000,
    rating: 4.85,
    ratingCount: 156780,
    createdAt: '2016-06-15T10:00:00Z',
    updatedAt: '2024-12-25T11:20:00Z',
    versions: [],
    featured: false,
    tags: ['recipes', 'items', 'utility', 'nei'],
  },
  {
    id: '5',
    slug: 'iris-shaders',
    name: 'Iris Shaders',
    summary: 'Мод для шейдеров, совместимый с Sodium',
    description: `# Iris Shaders

Iris — это мод для загрузки шейдерпаков, совместимый с Sodium для максимальной производительности.`,
    icon: 'https://cdn.modrinth.com/data/YL57xq9U/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['decoration', 'optimization'],
    loaders: ['fabric', 'quilt'],
    minecraftVersions: ['1.21.4', '1.21.3', '1.21.1', '1.20.6', '1.20.4', '1.20.1'],
    author: {
      id: 'coderbot',
      username: 'coderbot',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=coderbot',
      verified: true,
    },
    downloads: 45600000,
    views: 89000000,
    rating: 4.88,
    ratingCount: 34560,
    createdAt: '2021-03-10T14:00:00Z',
    updatedAt: '2024-12-22T08:45:00Z',
    versions: [],
    featured: true,
    tags: ['shaders', 'graphics', 'optifine', 'sodium'],
  },
  {
    id: '6',
    slug: 'mca-reborn',
    name: 'Minecraft Comes Alive Reborn',
    summary: 'Превратите деревенских жителей в живых NPC с личностями',
    description: `# Minecraft Comes Alive Reborn

Замените стандартных жителей на полноценных NPC с личностями, возможностью брака и детей.`,
    icon: 'https://cdn.modrinth.com/data/r9aNVYvZ/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['mobs', 'social', 'adventure'],
    loaders: ['forge', 'fabric'],
    minecraftVersions: ['1.20.1', '1.19.4', '1.19.2', '1.18.2'],
    author: {
      id: 'wildnature',
      username: 'WildNature',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=wildnature',
    },
    downloads: 12300000,
    views: 28000000,
    rating: 4.7,
    ratingCount: 8920,
    createdAt: '2022-01-20T16:30:00Z',
    updatedAt: '2024-10-05T12:00:00Z',
    versions: [],
    featured: false,
    tags: ['villagers', 'npc', 'roleplay', 'family'],
  },
  {
    id: '7',
    slug: 'alex-mobs',
    name: "Alex's Mobs",
    summary: 'Добавляет более 80 реалистичных существ в мир Minecraft',
    description: `# Alex's Mobs

Добавляет разнообразных животных и существ, вдохновлённых реальным миром, с уникальным поведением и взаимодействиями.`,
    icon: 'https://cdn.modrinth.com/data/aNKpE5Xx/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['mobs', 'adventure', 'worldgen'],
    loaders: ['forge', 'neoforge'],
    minecraftVersions: ['1.21.1', '1.20.1', '1.19.2', '1.18.2'],
    author: {
      id: 'alex',
      username: 'alex1the1666',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex1',
    },
    downloads: 78900000,
    views: 145000000,
    rating: 4.92,
    ratingCount: 67890,
    createdAt: '2020-08-12T09:00:00Z',
    updatedAt: '2024-12-18T15:30:00Z',
    versions: [],
    featured: true,
    tags: ['animals', 'creatures', 'wildlife', 'realistic'],
  },
  {
    id: '8',
    slug: 'betternether',
    name: 'BetterNether',
    summary: 'Полностью переработанный Нижний мир с новыми биомами и мобами',
    description: `# BetterNether

Переосмысление Нижнего мира с новыми биомами, структурами, растениями и существами.`,
    icon: 'https://cdn.modrinth.com/data/MpzVLzy5/icon.png',
    gallery: [],
    edition: 'java',
    categories: ['worldgen', 'mobs', 'decoration'],
    loaders: ['fabric', 'forge'],
    minecraftVersions: ['1.21.1', '1.20.4', '1.20.1', '1.19.4'],
    author: {
      id: 'paulevs',
      username: 'paulevs',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=paulevs',
      verified: true,
    },
    downloads: 23400000,
    views: 45000000,
    rating: 4.75,
    ratingCount: 12340,
    createdAt: '2019-11-05T11:00:00Z',
    updatedAt: '2024-11-20T10:00:00Z',
    versions: [],
    featured: false,
    tags: ['nether', 'biomes', 'dimension', 'exploration'],
  },
  // Bedrock Edition Mods
  {
    id: '9',
    slug: 'better-on-bedrock',
    name: 'Better on Bedrock',
    summary: 'Улучшенный геймплей для Bedrock Edition',
    description: `# Better on Bedrock

Комплексный аддон, улучшающий различные аспекты игры на Bedrock Edition.`,
    icon: 'https://api.dicebear.com/7.x/shapes/svg?seed=betteronbedrock',
    gallery: [],
    edition: 'bedrock',
    categories: ['utility', 'optimization'],
    loaders: [],
    minecraftVersions: ['1.21.50', '1.21.40', '1.21.30', '1.21.0'],
    author: {
      id: 'bedrockdev',
      username: 'BedrockDev',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bedrockdev',
    },
    downloads: 5600000,
    views: 12000000,
    rating: 4.6,
    ratingCount: 3450,
    createdAt: '2023-03-15T14:00:00Z',
    updatedAt: '2024-12-10T09:30:00Z',
    versions: [],
    featured: true,
    tags: ['bedrock', 'addon', 'gameplay', 'enhancement'],
  },
  {
    id: '10',
    slug: 'natural-mobs-bedrock',
    name: 'Natural Mobs Bedrock',
    summary: 'Добавляет реалистичных животных в Bedrock Edition',
    description: `# Natural Mobs Bedrock

Аддон добавляющий разнообразных реалистичных животных в мир Minecraft Bedrock.`,
    icon: 'https://api.dicebear.com/7.x/shapes/svg?seed=naturalmobs',
    gallery: [],
    edition: 'bedrock',
    categories: ['mobs', 'adventure'],
    loaders: [],
    minecraftVersions: ['1.21.50', '1.21.40', '1.21.0', '1.20.80'],
    author: {
      id: 'mobcreator',
      username: 'MobCreator',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mobcreator',
    },
    downloads: 3200000,
    views: 7800000,
    rating: 4.5,
    ratingCount: 2100,
    createdAt: '2023-06-20T10:00:00Z',
    updatedAt: '2024-11-28T14:15:00Z',
    versions: [],
    featured: false,
    tags: ['mobs', 'animals', 'bedrock', 'addon'],
  },
];

export function formatDownloads(num: number): string {
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(2) + ' млрд';
  }
  if (num >= 1000000) {
    return (num / 1000000).toFixed(2) + ' млн';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + ' тыс';
  }
  return num.toString();
}

export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  const diffWeeks = Math.floor(diffDays / 7);
  const diffMonths = Math.floor(diffDays / 30);
  const diffYears = Math.floor(diffDays / 365);

  if (diffMins < 1) return 'только что';
  if (diffMins < 60) return `${diffMins} мин. назад`;
  if (diffHours < 24) return `${diffHours} ч. назад`;
  if (diffDays < 7) return `${diffDays} дн. назад`;
  if (diffWeeks < 5) return `${diffWeeks} нед. назад`;
  if (diffMonths < 12) return `${diffMonths} мес. назад`;
  return `${diffYears} г. назад`;
}
