import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProfileHeader, ProfileHeaderSkeleton } from '@/components/profile/ProfileHeader';
import { ProfileTabs } from '@/components/profile/ProfileTabs';
import { ProfileEditModal } from '@/components/profile/ProfileEditModal';
import { PrivacySettings } from '@/components/profile/PrivacySettings';
import { ReferralSection } from '@/components/profile/ReferralSection';
import { useUserProfile } from '@/hooks/useUserProfile';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/format';
import { Shield, History, AlertTriangle, Ban, Send } from 'lucide-react';

export default function UserProfilePage() {
  const { username } = useParams<{ username: string }>();
  const { profile: currentProfile } = useAuth();
  const { data: profile, isLoading, error } = useUserProfile(username);
  const [editOpen, setEditOpen] = useState(false);
  const isOwner = currentProfile?.id === profile?.id;

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 pt-24 pb-12">
          <ProfileHeaderSkeleton />
        </div>
      </Layout>
    );
  }

  if (error || !profile) {
    return (
      <Layout>
        <div className="container mx-auto px-4 pt-24 pb-12 text-center">
          <h1 className="text-2xl font-bold">Пользователь не найден</h1>
          <p className="text-muted-foreground mt-2">Проверьте правильность ссылки</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 pt-24 pb-12">
        <ProfileHeader profile={profile} onEdit={() => setEditOpen(true)} />
        
        {isOwner ? (
          <OwnerView profile={profile} />
        ) : (
          <ProfileTabs profile={profile} />
        )}

        {isOwner && (
          <ProfileEditModal open={editOpen} onOpenChange={setEditOpen} profile={profile} />
        )}
      </div>
    </Layout>
  );
}

function OwnerView({ profile }: { profile: NonNullable<ReturnType<typeof useUserProfile>['data']> }) {
  return (
    <Tabs defaultValue="mods" className="mt-6">
      <TabsList className="w-full justify-start bg-secondary/50 overflow-x-auto">
        <TabsTrigger value="mods">Моды</TabsTrigger>
        <TabsTrigger value="security">Безопасность</TabsTrigger>
        <TabsTrigger value="privacy">Приватность</TabsTrigger>
        <TabsTrigger value="referral">Реферальная</TabsTrigger>
      </TabsList>

      <TabsContent value="mods">
        <ProfileTabs profile={profile} />
      </TabsContent>

      <TabsContent value="security">
        <SecurityTab profileId={profile.id} />
      </TabsContent>

      <TabsContent value="privacy">
        <div className="mt-4">
          <PrivacySettings profile={profile} />
        </div>
      </TabsContent>

      <TabsContent value="referral">
        <div className="mt-4">
          <ReferralSection profile={profile} />
        </div>
      </TabsContent>
    </Tabs>
  );
}

function SecurityTab({ profileId }: { profileId: string }) {
  const { user } = useAuth();
  
  const { data: warnings = [] } = useQuery({
    queryKey: ['user-warnings-own', profileId],
    queryFn: async () => {
      const { data } = await supabase
        .from('user_warnings')
        .select('*')
        .eq('user_id', profileId)
        .order('created_at', { ascending: false });
      return data || [];
    },
  });

  const { data: bans = [] } = useQuery({
    queryKey: ['user-bans-own', profileId],
    queryFn: async () => {
      const { data } = await supabase
        .from('user_bans')
        .select('*')
        .eq('user_id', profileId)
        .order('created_at', { ascending: false });
      return data || [];
    },
  });

  const { data: loginHistory = [] } = useQuery({
    queryKey: ['login-history', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data } = await supabase
        .from('user_login_history')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);
      return data || [];
    },
    enabled: !!user?.id,
  });

  return (
    <div className="space-y-4 mt-4">
      {/* Login History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <History className="w-5 h-5" />
            История входов
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loginHistory.length === 0 ? (
            <p className="text-sm text-muted-foreground">Нет записей</p>
          ) : (
            <div className="space-y-2">
              {loginHistory.map((entry: any) => (
                <div key={entry.id} className="flex items-center justify-between text-sm p-2 rounded bg-secondary/50">
                  <span className="text-muted-foreground truncate max-w-[60%]">{entry.user_agent || 'Неизвестно'}</span>
                  <span className="text-xs text-muted-foreground">{formatDate(entry.created_at)}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Warnings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertTriangle className="w-5 h-5 text-warning" />
            Предупреждения ({warnings.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {warnings.length === 0 ? (
            <p className="text-sm text-muted-foreground">Нет предупреждений — отлично! 🎉</p>
          ) : (
            <div className="space-y-2">
              {warnings.map((w: any) => (
                <div key={w.id} className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                  <p className="text-sm">{w.reason}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">{w.severity}</Badge>
                    <span className="text-xs text-muted-foreground">{formatDate(w.created_at)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bans */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Ban className="w-5 h-5 text-destructive" />
            История блокировок ({bans.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {bans.length === 0 ? (
            <p className="text-sm text-muted-foreground">Нет блокировок</p>
          ) : (
            <div className="space-y-2">
              {bans.map((b: any) => (
                <div key={b.id} className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                  <p className="text-sm">{b.reason}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={b.is_active ? 'destructive' : 'outline'} className="text-xs">
                      {b.is_active ? 'Активна' : 'Истекла'}
                    </Badge>
                    <Badge variant="outline" className="text-xs">{b.ban_type}</Badge>
                    <span className="text-xs text-muted-foreground">{formatDate(b.created_at)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
