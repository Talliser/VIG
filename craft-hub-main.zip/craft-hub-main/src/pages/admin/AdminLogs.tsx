import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatDate } from '@/lib/format';
import {
  Search,
  Activity,
  Shield,
  User,
  Package,
  Settings,
} from 'lucide-react';

const actionIcons: Record<string, React.ReactNode> = {
  user_banned: <User className="h-4 w-4 text-red-400" />,
  role_changed: <Shield className="h-4 w-4 text-blue-400" />,
  mod_approved: <Package className="h-4 w-4 text-green-400" />,
  mod_rejected: <Package className="h-4 w-4 text-red-400" />,
  mod_featured: <Package className="h-4 w-4 text-yellow-400" />,
  settings_updated: <Settings className="h-4 w-4 text-purple-400" />,
  report_resolved: <Activity className="h-4 w-4 text-green-400" />,
  report_dismissed: <Activity className="h-4 w-4 text-gray-400" />,
};

const actionLabels: Record<string, string> = {
  user_banned: 'Пользователь заблокирован',
  role_changed: 'Роль изменена',
  mod_approved: 'Мод одобрен',
  mod_rejected: 'Мод отклонён',
  mod_featured: 'Мод в Featured',
  mod_unfeatured: 'Мод убран из Featured',
  settings_updated: 'Настройки обновлены',
  report_resolved: 'Жалоба решена',
  report_dismissed: 'Жалоба отклонена',
};

export default function AdminLogs() {
  const { hasPermission } = usePermissions();
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');

  const { data: logs, isLoading } = useQuery({
    queryKey: ['admin-logs', search, actionFilter],
    queryFn: async () => {
      let query = supabase
        .from('admin_logs')
        .select('*')
        .order('created_at', { ascending: false });

      if (actionFilter !== 'all') {
        query = query.eq('action', actionFilter);
      }

      const { data, error } = await query.limit(100);
      if (error) throw error;
      return data || [];
    },
    enabled: hasPermission('audit.view'),
  });

  if (!hasPermission('audit.view')) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к логам</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Логи действий</h1>
          <p className="text-muted-foreground">
            История административных действий
          </p>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Все действия" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все действия</SelectItem>
                  <SelectItem value="user_banned">Блокировки</SelectItem>
                  <SelectItem value="role_changed">Изменения ролей</SelectItem>
                  <SelectItem value="mod_approved">Одобрения модов</SelectItem>
                  <SelectItem value="mod_rejected">Отклонения модов</SelectItem>
                  <SelectItem value="settings_updated">Настройки</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Logs Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Действие</TableHead>
                  <TableHead>Цель</TableHead>
                  <TableHead>Детали</TableHead>
                  <TableHead>Дата</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      Загрузка...
                    </TableCell>
                  </TableRow>
                ) : logs?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                      <Activity className="h-12 w-12 mx-auto mb-3" />
                      <p>Логи не найдены</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  logs?.map((log: any) => (
                    <TableRow key={log.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {actionIcons[log.action] || <Activity className="h-4 w-4" />}
                          <span>{actionLabels[log.action] || log.action}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {log.target_type && (
                          <Badge variant="outline">
                            {log.target_type}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">
                        {log.details ? JSON.stringify(log.details) : '—'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(log.created_at)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
