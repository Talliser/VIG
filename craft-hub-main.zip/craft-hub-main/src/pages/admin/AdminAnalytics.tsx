import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Users,
  UserPlus,
  Package,
  Download,
  Eye,
  Activity,
  Shield,
  TrendingUp,
  Clock,
  CheckCircle,
  BarChart3,
  FileDown,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

type Period = '24h' | '7d' | '30d' | 'all';

export default function AdminAnalytics() {
  const { hasPermission } = usePermissions();
  const [period, setPeriod] = useState<Period>('30d');

  // Fetch user statistics
  const { data: userStats } = useQuery({
    queryKey: ['admin-analytics-users'],
    queryFn: async () => {
      const now = new Date();
      const day = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const week = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const month = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const [total, last24h, last7d, last30d] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', day.toISOString()),
        supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', week.toISOString()),
        supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', month.toISOString()),
      ]);

      return {
        total: total.count || 0,
        last24h: last24h.count || 0,
        last7d: last7d.count || 0,
        last30d: last30d.count || 0,
      };
    },
  });

  // Fetch content statistics
  const { data: contentStats } = useQuery({
    queryKey: ['admin-analytics-content'],
    queryFn: async () => {
      const [totalMods, publishedMods, pendingMods, draftMods, modsData] = await Promise.all([
        supabase.from('mods').select('id', { count: 'exact', head: true }),
        supabase.from('mods').select('id', { count: 'exact', head: true }).eq('status', 'published'),
        supabase.from('mods').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('mods').select('id', { count: 'exact', head: true }).eq('status', 'draft'),
        supabase.from('mods').select('name, downloads, views, rating, categories, created_at').order('downloads', { ascending: false }).limit(20),
      ]);

      const downloads = modsData.data?.reduce((sum, m) => sum + (m.downloads || 0), 0) || 0;
      const views = modsData.data?.reduce((sum, m) => sum + (m.views || 0), 0) || 0;

      return {
        total: totalMods.count || 0,
        published: publishedMods.count || 0,
        pending: pendingMods.count || 0,
        drafts: draftMods.count || 0,
        downloads,
        views,
        topMods: modsData.data || [],
      };
    },
  });

  // Fetch download trend data
  const { data: downloadTrend = [] } = useQuery({
    queryKey: ['admin-analytics-downloads', period],
    queryFn: async () => {
      const days = period === '24h' ? 1 : period === '7d' ? 7 : period === '30d' ? 30 : 90;
      const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      
      const { data } = await supabase
        .from('download_logs')
        .select('created_at')
        .gte('created_at', since.toISOString())
        .order('created_at');

      // Group by day
      const grouped: Record<string, number> = {};
      for (let i = 0; i < days; i++) {
        const d = new Date(Date.now() - (days - 1 - i) * 24 * 60 * 60 * 1000);
        grouped[d.toISOString().split('T')[0]] = 0;
      }
      data?.forEach((row) => {
        const key = new Date(row.created_at).toISOString().split('T')[0];
        if (grouped[key] !== undefined) grouped[key]++;
      });

      return Object.entries(grouped).map(([date, count]) => ({
        date: new Date(date).toLocaleDateString('ru', { day: 'numeric', month: 'short' }),
        downloads: count,
      }));
    },
  });

  // Admin activity
  const { data: adminActivity } = useQuery({
    queryKey: ['admin-analytics-activity'],
    queryFn: async () => {
      const now = new Date();
      const day = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const week = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      const [total, last24h, last7d, recentActions] = await Promise.all([
        supabase.from('admin_logs').select('id', { count: 'exact', head: true }),
        supabase.from('admin_logs').select('id', { count: 'exact', head: true }).gte('created_at', day.toISOString()),
        supabase.from('admin_logs').select('id', { count: 'exact', head: true }).gte('created_at', week.toISOString()),
        supabase.from('admin_logs').select('action, created_at').order('created_at', { ascending: false }).limit(10),
      ]);

      return {
        total: total.count || 0,
        last24h: last24h.count || 0,
        last7d: last7d.count || 0,
        recentActions: recentActions.data || [],
      };
    },
  });

  // Security & support
  const { data: securityStats } = useQuery({
    queryKey: ['admin-analytics-security'],
    queryFn: async () => {
      const day = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const [total, errors, warnings, critical] = await Promise.all([
        supabase.from('security_events').select('id', { count: 'exact', head: true }),
        supabase.from('security_events').select('id', { count: 'exact', head: true }).eq('severity', 'error').gte('created_at', day.toISOString()),
        supabase.from('security_events').select('id', { count: 'exact', head: true }).eq('severity', 'warning').gte('created_at', day.toISOString()),
        supabase.from('security_events').select('id', { count: 'exact', head: true }).eq('severity', 'critical').gte('created_at', day.toISOString()),
      ]);
      return { total: total.count || 0, errors: errors.count || 0, warnings: warnings.count || 0, critical: critical.count || 0 };
    },
  });

  const { data: supportStats } = useQuery({
    queryKey: ['admin-analytics-support'],
    queryFn: async () => {
      const [openReports, openTickets, resolvedToday] = await Promise.all([
        supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('tickets').select('id', { count: 'exact', head: true }).in('status', ['open', 'in_progress']),
        supabase.from('tickets').select('id', { count: 'exact', head: true }).eq('status', 'resolved')
          .gte('resolved_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
      ]);
      return { openReports: openReports.count || 0, openTickets: openTickets.count || 0, resolvedToday: resolvedToday.count || 0 };
    },
  });

  // Export function
  const handleExport = (format: 'csv' | 'json') => {
    const data = {
      users: userStats,
      content: contentStats ? { ...contentStats, topMods: contentStats.topMods } : null,
      security: securityStats,
      support: supportStats,
      exportedAt: new Date().toISOString(),
    };

    if (format === 'json') {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `minemods-analytics-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      const rows = [
        ['Metric', 'Value'],
        ['Users Total', String(userStats?.total || 0)],
        ['Users 24h', String(userStats?.last24h || 0)],
        ['Users 7d', String(userStats?.last7d || 0)],
        ['Users 30d', String(userStats?.last30d || 0)],
        ['Mods Total', String(contentStats?.total || 0)],
        ['Mods Published', String(contentStats?.published || 0)],
        ['Downloads', String(contentStats?.downloads || 0)],
        ['Views', String(contentStats?.views || 0)],
      ];
      const csv = rows.map(r => r.join(',')).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `minemods-analytics-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  if (!hasPermission('audit.view')) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к аналитике</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Аналитика платформы</h1>
            <p className="text-muted-foreground">Обзор активности и статистики MineMods</p>
          </div>
          <div className="flex items-center gap-2">
            {(['24h', '7d', '30d', 'all'] as Period[]).map((p) => (
              <Button key={p} variant={period === p ? 'default' : 'outline'} size="sm" onClick={() => setPeriod(p)}>
                {p === '24h' ? '24ч' : p === '7d' ? '7д' : p === '30d' ? '30д' : 'Всё'}
              </Button>
            ))}
            <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
              <FileDown className="h-4 w-4 mr-1" /> CSV
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleExport('json')}>
              <FileDown className="h-4 w-4 mr-1" /> JSON
            </Button>
          </div>
        </div>

        {/* User Statistics */}
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Users className="h-5 w-5" /> Пользователи
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Всего пользователей', value: userStats?.total || 0, icon: Users, desc: 'За всё время' },
              { label: 'За 24 часа', value: userStats?.last24h || 0, icon: UserPlus, desc: 'Новые', color: 'text-green-500' },
              { label: 'За 7 дней', value: userStats?.last7d || 0, icon: TrendingUp, desc: 'Рост за неделю', color: 'text-blue-500' },
              { label: 'За 30 дней', value: userStats?.last30d || 0, icon: BarChart3, desc: 'Рост за месяц', color: 'text-purple-500' },
            ].map((s) => (
              <Card key={s.label}>
                <CardHeader className="pb-2">
                  <CardDescription>{s.label}</CardDescription>
                  <CardTitle className={`text-3xl ${s.color || ''}`}>
                    {s.color ? '+' : ''}{s.value}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <s.icon className="h-4 w-4 mr-1" /> {s.desc}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Content Statistics */}
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Package className="h-5 w-5" /> Контент
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { label: 'Всего', value: contentStats?.total || 0, icon: Package },
              { label: 'Опубликовано', value: contentStats?.published || 0, icon: CheckCircle, color: 'text-green-500' },
              { label: 'На модерации', value: contentStats?.pending || 0, icon: Clock, color: 'text-yellow-500' },
              { label: 'Черновики', value: contentStats?.drafts || 0, icon: Activity },
              { label: 'Загрузок', value: contentStats?.downloads?.toLocaleString() || '0', icon: Download },
              { label: 'Просмотров', value: contentStats?.views?.toLocaleString() || '0', icon: Eye },
            ].map((s) => (
              <Card key={s.label}>
                <CardHeader className="pb-2">
                  <CardDescription className="text-xs">{s.label}</CardDescription>
                  <CardTitle className={`text-2xl ${s.color || ''}`}>{s.value}</CardTitle>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>

        {/* Downloads Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" /> Загрузки за период
            </CardTitle>
          </CardHeader>
          <CardContent>
            {downloadTrend.length > 0 ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={downloadTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Line type="monotone" dataKey="downloads" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-12">Нет данных о загрузках за выбранный период</p>
            )}
          </CardContent>
        </Card>

        {/* Top mods bar chart */}
        {contentStats?.topMods && contentStats.topMods.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Топ модов по загрузкам</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={contentStats.topMods.slice(0, 10)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis type="category" dataKey="name" width={150} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                    <Bar dataKey="downloads" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Admin Activity & Security */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" /> Активность админов
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold">{adminActivity?.total || 0}</p>
                  <p className="text-xs text-muted-foreground">Всего</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-500">{adminActivity?.last24h || 0}</p>
                  <p className="text-xs text-muted-foreground">За 24ч</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-500">{adminActivity?.last7d || 0}</p>
                  <p className="text-xs text-muted-foreground">За 7 дней</p>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Последние действия</p>
                {adminActivity?.recentActions?.slice(0, 5).map((action: any, i: number) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <Badge variant="outline" className="text-xs">{action.action}</Badge>
                    <span className="text-muted-foreground text-xs">
                      {new Date(action.created_at).toLocaleString('ru-RU')}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" /> Здоровье системы
              </CardTitle>
              <CardDescription>События безопасности за 24 часа</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-500">{securityStats?.critical || 0}</p>
                  <p className="text-xs text-muted-foreground">Критические</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-orange-500">{securityStats?.errors || 0}</p>
                  <p className="text-xs text-muted-foreground">Ошибки</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-yellow-500">{securityStats?.warnings || 0}</p>
                  <p className="text-xs text-muted-foreground">Предупреждения</p>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Статус поддержки</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Открытые жалобы</span>
                  <Badge variant={supportStats?.openReports ? 'destructive' : 'outline'}>{supportStats?.openReports || 0}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Открытые тикеты</span>
                  <Badge variant={supportStats?.openTickets ? 'secondary' : 'outline'}>{supportStats?.openTickets || 0}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Решено сегодня</span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">
                    <CheckCircle className="h-3 w-3 mr-1" />{supportStats?.resolvedToday || 0}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
