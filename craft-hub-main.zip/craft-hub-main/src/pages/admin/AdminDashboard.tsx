import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { formatNumber, formatDate } from '@/lib/format';
import {
  Users,
  Package,
  Download,
  Eye,
  AlertTriangle,
  Clock,
  CheckCircle,
  XCircle,
  TrendingUp,
  Ticket,
  Shield,
  Activity,
} from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  const { role, hasPermission } = usePermissions();

  // Platform stats (for admins)
  const { data: platformStats } = useQuery({
    queryKey: ['admin-platform-stats'],
    queryFn: async () => {
      const [usersRes, modsRes, downloadsRes] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('mods').select('id, downloads, views', { count: 'exact' }),
        supabase.from('download_logs').select('id', { count: 'exact', head: true }),
      ]);

      const mods = modsRes.data || [];
      const totalDownloads = mods.reduce((sum, m) => sum + (m.downloads || 0), 0);
      const totalViews = mods.reduce((sum, m) => sum + (m.views || 0), 0);

      return {
        totalUsers: usersRes.count || 0,
        totalMods: modsRes.count || 0,
        totalDownloads,
        totalViews,
      };
    },
    enabled: hasPermission('users.view'),
  });

  // Moderation queue
  const { data: moderationStats } = useQuery({
    queryKey: ['admin-moderation-stats'],
    queryFn: async () => {
      const [pendingRes, approvedTodayRes, rejectedTodayRes] = await Promise.all([
        supabase.from('mods').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('mods').select('id', { count: 'exact', head: true })
          .eq('status', 'published')
          .gte('updated_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
        supabase.from('mods').select('id', { count: 'exact', head: true })
          .eq('status', 'rejected')
          .gte('updated_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
      ]);

      return {
        pending: pendingRes.count || 0,
        approvedToday: approvedTodayRes.count || 0,
        rejectedToday: rejectedTodayRes.count || 0,
      };
    },
    enabled: hasPermission('mods.view'),
  });

  // Reports
  const { data: reportsStats } = useQuery({
    queryKey: ['admin-reports-stats'],
    queryFn: async () => {
      const { count } = await supabase
        .from('reports')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'pending');

      return { pending: count || 0 };
    },
    enabled: hasPermission('reports.view'),
  });

  // Tickets
  const { data: ticketsStats } = useQuery({
    queryKey: ['admin-tickets-stats'],
    queryFn: async () => {
      const { count } = await supabase
        .from('tickets')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'open');

      return { open: count || 0 };
    },
    enabled: hasPermission('tickets.view'),
  });

  // Recent activity (security events)
  const { data: recentActivity } = useQuery({
    queryKey: ['admin-recent-activity'],
    queryFn: async () => {
      const { data } = await supabase
        .from('admin_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      return data || [];
    },
    enabled: hasPermission('audit.view'),
  });

  // Pending mods for quick review
  const { data: pendingMods } = useQuery({
    queryKey: ['admin-pending-mods'],
    queryFn: async () => {
      const { data } = await supabase
        .from('mods')
        .select(`
          id,
          name,
          slug,
          icon,
          created_at,
          author:author_id (
            username,
            display_name
          )
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: true })
        .limit(5);

      return data || [];
    },
    enabled: hasPermission('mods.view'),
  });

  const getRoleDashboard = () => {
    switch (role) {
      case 'super_admin':
      case 'admin':
        return (
          <>
            {/* Platform Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard
                title="Пользователи"
                value={formatNumber(platformStats?.totalUsers || 0)}
                icon={<Users className="h-5 w-5" />}
                trend="+12%"
                trendUp
              />
              <StatCard
                title="Проекты"
                value={formatNumber(platformStats?.totalMods || 0)}
                icon={<Package className="h-5 w-5" />}
                trend="+8%"
                trendUp
              />
              <StatCard
                title="Загрузки"
                value={formatNumber(platformStats?.totalDownloads || 0)}
                icon={<Download className="h-5 w-5" />}
                trend="+24%"
                trendUp
              />
              <StatCard
                title="Просмотры"
                value={formatNumber(platformStats?.totalViews || 0)}
                icon={<Eye className="h-5 w-5" />}
                trend="+15%"
                trendUp
              />
            </div>

            {/* Moderation & Reports */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-orange-500" />
                    Очередь модерации
                  </CardTitle>
                  <CardDescription>
                    Проекты, ожидающие проверки
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6 mb-6">
                    <div className="text-center">
                      <p className="text-3xl font-bold text-orange-500">{moderationStats?.pending || 0}</p>
                      <p className="text-sm text-muted-foreground">Ожидают</p>
                    </div>
                    <Separator orientation="vertical" className="h-12" />
                    <div className="text-center">
                      <p className="text-3xl font-bold text-green-500">{moderationStats?.approvedToday || 0}</p>
                      <p className="text-sm text-muted-foreground">Одобрено сегодня</p>
                    </div>
                    <Separator orientation="vertical" className="h-12" />
                    <div className="text-center">
                      <p className="text-3xl font-bold text-red-500">{moderationStats?.rejectedToday || 0}</p>
                      <p className="text-sm text-muted-foreground">Отклонено сегодня</p>
                    </div>
                  </div>

                  {pendingMods && pendingMods.length > 0 ? (
                    <div className="space-y-3">
                      {pendingMods.map((mod: any) => (
                        <div
                          key={mod.id}
                          className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                        >
                          <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                            {mod.icon ? (
                              <img src={mod.icon} alt="" className="h-full w-full object-cover" />
                            ) : (
                              <Package className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{mod.name}</p>
                            <p className="text-sm text-muted-foreground">
                              от {mod.author?.display_name || mod.author?.username}
                            </p>
                          </div>
                          <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/30">
                            Ожидает
                          </Badge>
                        </div>
                      ))}
                      <Link to="/admin/moderation">
                        <Button variant="outline" className="w-full">
                          Смотреть все
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-500" />
                      <p>Нет проектов на модерации</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                    Требует внимания
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Link to="/admin/reports">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5 text-red-500" />
                        <span>Жалобы</span>
                      </div>
                      <Badge variant="destructive">{reportsStats?.pending || 0}</Badge>
                    </div>
                  </Link>

                  <Link to="/admin/tickets">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <Ticket className="h-5 w-5 text-blue-500" />
                        <span>Открытые тикеты</span>
                      </div>
                      <Badge variant="secondary">{ticketsStats?.open || 0}</Badge>
                    </div>
                  </Link>

                  <Separator />

                  {hasPermission('security.view') && (
                    <Link to="/admin/security">
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                        <div className="flex items-center gap-3">
                          <Shield className="h-5 w-5 text-orange-500" />
                          <span>Безопасность</span>
                        </div>
                        <Activity className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Link>
                  )}
                </CardContent>
              </Card>
            </div>
          </>
        );

      case 'moderator':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <StatCard
                title="На модерации"
                value={String(moderationStats?.pending || 0)}
                icon={<Clock className="h-5 w-5" />}
                color="orange"
              />
              <StatCard
                title="Одобрено сегодня"
                value={String(moderationStats?.approvedToday || 0)}
                icon={<CheckCircle className="h-5 w-5" />}
                color="green"
              />
              <StatCard
                title="Открытые жалобы"
                value={String(reportsStats?.pending || 0)}
                icon={<AlertTriangle className="h-5 w-5" />}
                color="red"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Очередь модерации</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingMods && pendingMods.length > 0 ? (
                  <div className="space-y-3">
                    {pendingMods.map((mod: any) => (
                      <div
                        key={mod.id}
                        className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                      >
                        <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                          {mod.icon ? (
                            <img src={mod.icon} alt="" className="h-full w-full object-cover" />
                          ) : (
                            <Package className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{mod.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {formatDate(mod.created_at)}
                          </p>
                        </div>
                        <Link to={`/admin/moderation/${mod.id}`}>
                          <Button size="sm">Проверить</Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-500" />
                    <p>Очередь пуста</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        );

      case 'support':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <StatCard
                title="Открытые тикеты"
                value={String(ticketsStats?.open || 0)}
                icon={<Ticket className="h-5 w-5" />}
                color="blue"
              />
              <StatCard
                title="Среднее время ответа"
                value="~2ч"
                icon={<Clock className="h-5 w-5" />}
                color="green"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Ваши тикеты</CardTitle>
                <CardDescription>Тикеты, назначенные на вас</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <Ticket className="h-12 w-12 mx-auto mb-3" />
                  <p>Нет назначенных тикетов</p>
                  <Link to="/admin/tickets">
                    <Button variant="outline" className="mt-4">
                      Смотреть все тикеты
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </>
        );

      default:
        return (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">
                У вас нет доступа к панели администратора
              </p>
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Дашборд</h1>
          <p className="text-muted-foreground">
            Обзор платформы MineMods
          </p>
        </div>

        {getRoleDashboard()}
      </div>
    </AdminLayout>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
  color?: 'default' | 'green' | 'red' | 'orange' | 'blue';
}

function StatCard({ title, value, icon, trend, trendUp, color = 'default' }: StatCardProps) {
  const colorClasses = {
    default: 'text-primary',
    green: 'text-green-500',
    red: 'text-red-500',
    orange: 'text-orange-500',
    blue: 'text-blue-500',
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className={`text-2xl font-bold ${colorClasses[color]}`}>{value}</p>
            {trend && (
              <div className={`flex items-center gap-1 text-sm ${trendUp ? 'text-green-500' : 'text-red-500'}`}>
                <TrendingUp className={`h-4 w-4 ${!trendUp && 'rotate-180'}`} />
                <span>{trend}</span>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-lg bg-muted ${colorClasses[color]}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
