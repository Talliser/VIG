import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { useAuth } from '@/contexts/AuthContext';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/format';
import {
  FileText,
  Plus,
  Edit,
  History,
  Archive,
  Eye,
  MoreHorizontal,
  Shield,
  CheckCircle,
  Clock,
  Bold,
  Italic,
  List,
  ListOrdered,
  Link as LinkIcon,
  Heading1,
  Heading2,
} from 'lucide-react';

type DocumentStatus = 'draft' | 'active' | 'archived';

interface LegalDocument {
  id: string;
  title: string;
  slug: string;
  content: string;
  version: number;
  is_active: boolean;
  effective_date: string;
  created_at: string;
  created_by: string;
}

interface DocumentVersion {
  id: string;
  document_id: string;
  version: number;
  title: string;
  content: string;
  slug: string;
  effective_date: string;
  created_by: string;
  created_at: string;
  change_summary: string | null;
}

const statusConfig: Record<DocumentStatus, { label: string; color: string; icon: any }> = {
  draft: { label: 'Черновик', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30', icon: Clock },
  active: { label: 'Активный', color: 'bg-green-500/20 text-green-400 border-green-500/30', icon: CheckCircle },
  archived: { label: 'Архив', color: 'bg-gray-500/20 text-gray-400 border-gray-500/30', icon: Archive },
};

export default function AdminLegal() {
  const { hasPermission, role } = usePermissions();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<LegalDocument | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    content: '',
    effective_date: new Date().toISOString().split('T')[0],
    is_active: false,
    change_summary: '',
  });

  const canEdit = role === 'super_admin' || role === 'admin';

  // Fetch documents
  const { data: documents, isLoading } = useQuery({
    queryKey: ['legal-documents', statusFilter],
    queryFn: async () => {
      let query = supabase
        .from('legal_documents')
        .select('*')
        .order('is_active', { ascending: false })
        .order('effective_date', { ascending: false });

      const { data, error } = await query;
      if (error) throw error;

      let filtered = data || [];
      if (statusFilter === 'active') {
        filtered = filtered.filter(d => d.is_active);
      } else if (statusFilter === 'archived') {
        filtered = filtered.filter(d => !d.is_active);
      }

      return filtered as LegalDocument[];
    },
  });

  // Fetch document versions
  const { data: versions } = useQuery({
    queryKey: ['legal-document-versions', selectedDocument?.id],
    queryFn: async () => {
      if (!selectedDocument) return [];
      
      const { data, error } = await supabase
        .from('legal_document_versions')
        .select('*')
        .eq('document_id', selectedDocument.id)
        .order('version', { ascending: false });

      if (error) throw error;
      return data as DocumentVersion[];
    },
    enabled: !!selectedDocument && historyDialogOpen,
  });

  // Create/Update document mutation
  const saveMutation = useMutation({
    mutationFn: async (isNew: boolean) => {
      const userId = user?.id;
      if (!userId) throw new Error('User not authenticated');

      if (isNew) {
        // Create new document
        const { data, error } = await supabase
          .from('legal_documents')
          .insert({
            title: formData.title,
            slug: formData.slug,
            content: formData.content,
            effective_date: formData.effective_date,
            is_active: formData.is_active,
            created_by: userId,
            version: 1,
          })
          .select()
          .single();

        if (error) throw error;

        // Create first version entry
        await supabase.from('legal_document_versions').insert({
          document_id: data.id,
          version: 1,
          title: formData.title,
          slug: formData.slug,
          content: formData.content,
          effective_date: formData.effective_date,
          created_by: userId,
          change_summary: 'Initial version',
        });

        // Log action
        await supabase.from('admin_logs').insert({
          admin_id: userId,
          action: 'legal_document_created',
          target_type: 'legal_document',
          target_id: data.id,
          details: { title: formData.title },
        });

        return data;
      } else {
        // Update existing document
        if (!selectedDocument) throw new Error('No document selected');

        const newVersion = selectedDocument.version + 1;

        // If setting as active, deactivate others with same slug
        if (formData.is_active) {
          await supabase
            .from('legal_documents')
            .update({ is_active: false })
            .eq('slug', formData.slug)
            .neq('id', selectedDocument.id);
        }

        const { data, error } = await supabase
          .from('legal_documents')
          .update({
            title: formData.title,
            slug: formData.slug,
            content: formData.content,
            effective_date: formData.effective_date,
            is_active: formData.is_active,
            version: newVersion,
          })
          .eq('id', selectedDocument.id)
          .select()
          .single();

        if (error) throw error;

        // Create version entry
        await supabase.from('legal_document_versions').insert({
          document_id: selectedDocument.id,
          version: newVersion,
          title: formData.title,
          slug: formData.slug,
          content: formData.content,
          effective_date: formData.effective_date,
          created_by: userId,
          change_summary: formData.change_summary || 'Updated',
        });

        // Log action
        await supabase.from('admin_logs').insert({
          admin_id: userId,
          action: 'legal_document_updated',
          target_type: 'legal_document',
          target_id: selectedDocument.id,
          details: { 
            title: formData.title, 
            version: newVersion,
            change_summary: formData.change_summary 
          },
        });

        // If document is now active, notify all users
        if (formData.is_active && !selectedDocument.is_active) {
          // Create broadcast notification for legal update
          await supabase.rpc('create_broadcast_notification', {
            _type: 'legal',
            _priority: 'high',
            _title: `${formData.title} обновлено`,
            _message: `Дата вступления в силу: ${new Date(formData.effective_date).toLocaleDateString('ru-RU')}`,
            _link: `/legal/${formData.slug}`,
            _requires_action: false,
          });
        }

        return data;
      }
    },
    onSuccess: () => {
      toast({ title: selectedDocument ? 'Документ обновлён' : 'Документ создан' });
      setEditDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['legal-documents'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  // Archive mutation
  const archiveMutation = useMutation({
    mutationFn: async (document: LegalDocument) => {
      const { error } = await supabase
        .from('legal_documents')
        .update({ is_active: false })
        .eq('id', document.id);

      if (error) throw error;

      await supabase.from('admin_logs').insert({
        admin_id: user?.id || '',
        action: 'legal_document_archived',
        target_type: 'legal_document',
        target_id: document.id,
        details: { title: document.title },
      });
    },
    onSuccess: () => {
      toast({ title: 'Документ архивирован' });
      queryClient.invalidateQueries({ queryKey: ['legal-documents'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const resetForm = () => {
    setFormData({
      title: '',
      slug: '',
      content: '',
      effective_date: new Date().toISOString().split('T')[0],
      is_active: false,
      change_summary: '',
    });
    setSelectedDocument(null);
  };

  const openEditDialog = (document?: LegalDocument) => {
    if (document) {
      setSelectedDocument(document);
      setFormData({
        title: document.title,
        slug: document.slug,
        content: document.content,
        effective_date: document.effective_date.split('T')[0],
        is_active: document.is_active,
        change_summary: '',
      });
    } else {
      resetForm();
    }
    setEditDialogOpen(true);
  };

  const insertMarkdown = (before: string, after: string = '') => {
    const textarea = document.getElementById('content-textarea') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = formData.content.substring(start, end);
    const newContent = 
      formData.content.substring(0, start) + 
      before + selectedText + after + 
      formData.content.substring(end);
    
    setFormData(prev => ({ ...prev, content: newContent }));
  };

  const getDocumentStatus = (doc: LegalDocument): DocumentStatus => {
    if (doc.is_active) return 'active';
    return 'archived';
  };

  if (!hasPermission('platform.legal')) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к управлению юридическими документами</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Юридические документы</h1>
            <p className="text-muted-foreground">
              Управление правовыми документами платформы
            </p>
          </div>
          {canEdit && (
            <Button onClick={() => openEditDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Добавить документ
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Все статусы" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все документы</SelectItem>
                  <SelectItem value="active">Активные</SelectItem>
                  <SelectItem value="archived">Архив</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Documents Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Документ</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Версия</TableHead>
                  <TableHead>Дата вступления</TableHead>
                  <TableHead>Изменён</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Загрузка...
                    </TableCell>
                  </TableRow>
                ) : documents?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Документы не найдены
                    </TableCell>
                  </TableRow>
                ) : (
                  documents?.map((doc) => {
                    const status = getDocumentStatus(doc);
                    const StatusIcon = statusConfig[status].icon;
                    return (
                      <TableRow key={doc.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">{doc.title}</p>
                              <p className="text-sm text-muted-foreground">/{doc.slug}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={statusConfig[status].color}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {statusConfig[status].label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">v{doc.version}</Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(doc.effective_date)}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(doc.created_at)}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setSelectedDocument(doc);
                                setPreviewDialogOpen(true);
                              }}>
                                <Eye className="h-4 w-4 mr-2" />
                                Предпросмотр
                              </DropdownMenuItem>
                              {canEdit && (
                                <DropdownMenuItem onClick={() => openEditDialog(doc)}>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Редактировать
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem onClick={() => {
                                setSelectedDocument(doc);
                                setHistoryDialogOpen(true);
                              }}>
                                <History className="h-4 w-4 mr-2" />
                                История версий
                              </DropdownMenuItem>
                              {canEdit && doc.is_active && (
                                <DropdownMenuItem 
                                  className="text-yellow-500"
                                  onClick={() => archiveMutation.mutate(doc)}
                                >
                                  <Archive className="h-4 w-4 mr-2" />
                                  Архивировать
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit/Create Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedDocument ? 'Редактирование документа' : 'Новый документ'}
              </DialogTitle>
              <DialogDescription>
                {selectedDocument 
                  ? `Редактирование "${selectedDocument.title}" (версия ${selectedDocument.version})`
                  : 'Создание нового юридического документа'
                }
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Название документа</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Terms of Service"
                  />
                </div>
                <div className="space-y-2">
                  <Label>URL slug</Label>
                  <Input
                    value={formData.slug}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-')
                    }))}
                    placeholder="terms-of-service"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Дата вступления в силу</Label>
                  <Input
                    type="date"
                    value={formData.effective_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, effective_date: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Статус</Label>
                  <Select 
                    value={formData.is_active ? 'active' : 'draft'} 
                    onValueChange={(v) => setFormData(prev => ({ ...prev, is_active: v === 'active' }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Черновик</SelectItem>
                      <SelectItem value="active">Активный</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {selectedDocument && (
                <div className="space-y-2">
                  <Label>Описание изменений</Label>
                  <Input
                    value={formData.change_summary}
                    onChange={(e) => setFormData(prev => ({ ...prev, change_summary: e.target.value }))}
                    placeholder="Краткое описание внесённых изменений..."
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Содержимое (Markdown)</Label>
                <div className="flex gap-1 mb-2 flex-wrap">
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('**', '**')}>
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('*', '*')}>
                    <Italic className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('# ')}>
                    <Heading1 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('## ')}>
                    <Heading2 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('- ')}>
                    <List className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('1. ')}>
                    <ListOrdered className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => insertMarkdown('[', '](url)')}>
                    <LinkIcon className="h-4 w-4" />
                  </Button>
                </div>
                <Textarea
                  id="content-textarea"
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="# Заголовок&#10;&#10;Текст документа..."
                  className="min-h-[300px] font-mono text-sm"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
                Отмена
              </Button>
              <Button 
                onClick={() => saveMutation.mutate(!selectedDocument)}
                disabled={!formData.title || !formData.slug || !formData.content || saveMutation.isPending}
              >
                {saveMutation.isPending ? 'Сохранение...' : (selectedDocument ? 'Сохранить изменения' : 'Создать')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* History Dialog */}
        <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>История версий</DialogTitle>
              <DialogDescription>
                {selectedDocument?.title}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 max-h-[60vh] overflow-y-auto">
              {versions?.map((version) => (
                <Card key={version.id}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">Версия {version.version}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {formatDate(version.created_at)}
                      </span>
                    </div>
                    {version.change_summary && (
                      <p className="text-sm text-muted-foreground mb-2">
                        {version.change_summary}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Дата вступления: {formatDate(version.effective_date)}
                    </p>
                  </CardContent>
                </Card>
              ))}
              {(!versions || versions.length === 0) && (
                <p className="text-center text-muted-foreground py-4">
                  История версий пуста
                </p>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setHistoryDialogOpen(false)}>
                Закрыть
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Preview Dialog */}
        <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedDocument?.title}</DialogTitle>
              <DialogDescription>
                Версия {selectedDocument?.version} • Вступает в силу: {selectedDocument && formatDate(selectedDocument.effective_date)}
              </DialogDescription>
            </DialogHeader>

            <div className="prose prose-sm dark:prose-invert max-w-none">
              <div className="whitespace-pre-wrap font-sans">
                {selectedDocument?.content}
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setPreviewDialogOpen(false)}>
                Закрыть
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
