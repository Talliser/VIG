import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/format';
import {
  Search,
  Package,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  ExternalLink,
} from 'lucide-react';
import { Link } from 'react-router-dom';

type ModStatus = 'pending' | 'published' | 'rejected' | 'draft';

const statusConfig: Record<ModStatus, { label: string; color: string; icon: React.ReactNode }> = {
  pending: { 
    label: 'На модерации', 
    color: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    icon: <Clock className="h-4 w-4" />
  },
  published: { 
    label: 'Опубликован', 
    color: 'bg-green-500/20 text-green-400 border-green-500/30',
    icon: <CheckCircle className="h-4 w-4" />
  },
  rejected: { 
    label: 'Отклонён', 
    color: 'bg-red-500/20 text-red-400 border-red-500/30',
    icon: <XCircle className="h-4 w-4" />
  },
  draft: { 
    label: 'Черновик', 
    color: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
    icon: <Package className="h-4 w-4" />
  },
};

export default function AdminModeration() {
  const { hasPermission } = usePermissions();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState('');
  const [currentTab, setCurrentTab] = useState('pending');
  const [selectedMod, setSelectedMod] = useState<any>(null);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const { data: mods, isLoading } = useQuery({
    queryKey: ['admin-mods', currentTab, search],
    queryFn: async () => {
      let query = supabase
        .from('mods')
        .select(`
          *,
          author:author_id (
            id,
            username,
            display_name,
            avatar
          )
        `)
        .order('created_at', { ascending: currentTab === 'pending' });

      if (currentTab !== 'all') {
        query = query.eq('status', currentTab);
      }

      if (search) {
        query = query.ilike('name', `%${search}%`);
      }

      const { data, error } = await query.limit(50);
      if (error) throw error;
      return data || [];
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (modId: string) => {
      const { error } = await supabase
        .from('mods')
        .update({ status: 'published' })
        .eq('id', modId);

      if (error) throw error;

      // Log action
      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'mod_approved',
        target_type: 'mod',
        target_id: modId,
      });
    },
    onSuccess: () => {
      toast({ title: 'Мод одобрен и опубликован' });
      queryClient.invalidateQueries({ queryKey: ['admin-mods'] });
      queryClient.invalidateQueries({ queryKey: ['admin-moderation-stats'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ modId, reason }: { modId: string; reason: string }) => {
      const { error } = await supabase
        .from('mods')
        .update({ status: 'rejected' })
        .eq('id', modId);

      if (error) throw error;

      // Log action with reason
      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'mod_rejected',
        target_type: 'mod',
        target_id: modId,
        details: { reason },
      });
    },
    onSuccess: () => {
      toast({ title: 'Мод отклонён' });
      setRejectDialogOpen(false);
      setRejectReason('');
      setSelectedMod(null);
      queryClient.invalidateQueries({ queryKey: ['admin-mods'] });
      queryClient.invalidateQueries({ queryKey: ['admin-moderation-stats'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const featureMutation = useMutation({
    mutationFn: async ({ modId, featured }: { modId: string; featured: boolean }) => {
      const { error } = await supabase
        .from('mods')
        .update({ featured })
        .eq('id', modId);

      if (error) throw error;

      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: featured ? 'mod_featured' : 'mod_unfeatured',
        target_type: 'mod',
        target_id: modId,
      });
    },
    onSuccess: () => {
      toast({ title: 'Статус обновлён' });
      queryClient.invalidateQueries({ queryKey: ['admin-mods'] });
    },
  });

  const handleApprove = (modId: string) => {
    approveMutation.mutate(modId);
  };

  const handleReject = () => {
    if (!selectedMod || !rejectReason) return;
    rejectMutation.mutate({ modId: selectedMod.id, reason: rejectReason });
  };

  const stats = {
    pending: mods?.filter(m => m.status === 'pending').length || 0,
    published: mods?.filter(m => m.status === 'published').length || 0,
    rejected: mods?.filter(m => m.status === 'rejected').length || 0,
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Модерация контента</h1>
          <p className="text-muted-foreground">
            Проверка и одобрение проектов
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="cursor-pointer" onClick={() => setCurrentTab('pending')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/20 text-orange-500">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.pending}</p>
                  <p className="text-sm text-muted-foreground">На модерации</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer" onClick={() => setCurrentTab('published')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/20 text-green-500">
                  <CheckCircle className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.published}</p>
                  <p className="text-sm text-muted-foreground">Опубликовано</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer" onClick={() => setCurrentTab('rejected')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/20 text-red-500">
                  <XCircle className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.rejected}</p>
                  <p className="text-sm text-muted-foreground">Отклонено</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск по названию..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Tabs */}
        <Tabs value={currentTab} onValueChange={setCurrentTab}>
          <TabsList>
            <TabsTrigger value="pending">На модерации</TabsTrigger>
            <TabsTrigger value="published">Опубликовано</TabsTrigger>
            <TabsTrigger value="rejected">Отклонено</TabsTrigger>
            <TabsTrigger value="all">Все</TabsTrigger>
          </TabsList>

          <TabsContent value={currentTab} className="mt-6">
            {isLoading ? (
              <div className="text-center py-8">Загрузка...</div>
            ) : mods?.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Package className="h-12 w-12 mx-auto mb-3" />
                  <p>Проекты не найдены</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {mods?.map((mod: any) => (
                  <Card key={mod.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        {/* Icon */}
                        <div className="h-16 w-16 rounded-lg bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                          {mod.icon ? (
                            <img src={mod.icon} alt="" className="h-full w-full object-cover" />
                          ) : (
                            <Package className="h-8 w-8 text-muted-foreground" />
                          )}
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h3 className="font-semibold">{mod.name}</h3>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {mod.summary}
                              </p>
                              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                                <span>от {mod.author?.display_name || mod.author?.username}</span>
                                <span>{formatDate(mod.created_at)}</span>
                              </div>
                            </div>
                            <Badge 
                              variant="outline" 
                              className={statusConfig[mod.status as ModStatus]?.color}
                            >
                              {statusConfig[mod.status as ModStatus]?.icon}
                              <span className="ml-1">{statusConfig[mod.status as ModStatus]?.label}</span>
                            </Badge>
                          </div>

                          {/* Categories & Tags */}
                          <div className="flex flex-wrap gap-2 mt-3">
                            {mod.categories?.slice(0, 3).map((cat: string) => (
                              <Badge key={cat} variant="secondary" className="text-xs">
                                {cat}
                              </Badge>
                            ))}
                            {mod.loaders?.slice(0, 2).map((loader: string) => (
                              <Badge key={loader} variant="outline" className="text-xs">
                                {loader}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-2">
                          <Link to={`/mod/${mod.slug}`} target="_blank">
                            <Button variant="outline" size="sm" className="w-full">
                              <Eye className="h-4 w-4 mr-1" />
                              Просмотр
                            </Button>
                          </Link>

                          {mod.status === 'pending' && hasPermission('mods.approve') && (
                            <>
                              <Button 
                                size="sm" 
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => handleApprove(mod.id)}
                                disabled={approveMutation.isPending}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Одобрить
                              </Button>
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => {
                                  setSelectedMod(mod);
                                  setRejectDialogOpen(true);
                                }}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Отклонить
                              </Button>
                            </>
                          )}

                          {mod.status === 'published' && hasPermission('mods.feature') && (
                            <Button 
                              variant={mod.featured ? 'secondary' : 'outline'}
                              size="sm"
                              onClick={() => featureMutation.mutate({ 
                                modId: mod.id, 
                                featured: !mod.featured 
                              })}
                            >
                              {mod.featured ? 'Убрать из Featured' : 'Featured'}
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Reject Dialog */}
        <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Отклонить проект</DialogTitle>
              <DialogDescription>
                Проект "{selectedMod?.name}" будет отклонён. Укажите причину.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Причина отклонения</Label>
                <Textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="Опишите причину отклонения..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
                Отмена
              </Button>
              <Button 
                variant="destructive" 
                onClick={handleReject}
                disabled={!rejectReason || rejectMutation.isPending}
              >
                Отклонить
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
