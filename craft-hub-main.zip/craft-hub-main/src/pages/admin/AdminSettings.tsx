import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { GeneralTab } from '@/components/admin/settings/GeneralTab';
import { SecurityTab } from '@/components/admin/settings/SecurityTab';
import { ModerationTab } from '@/components/admin/settings/ModerationTab';
import { FeatureFlagsTab } from '@/components/admin/settings/FeatureFlagsTab';
import { ChangeHistoryTab } from '@/components/admin/settings/ChangeHistoryTab';
import { SiteControlTab } from '@/components/admin/settings/SiteControlTab';
import { CategoriesTab } from '@/components/admin/settings/CategoriesTab';
import {
  Globe,
  Shield,
  Settings,
  ToggleLeft,
  History,
  LayoutDashboard,
  FileText,
} from 'lucide-react';

export default function AdminSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { hasPermission, hasAnyPermission } = usePermissions();

  const { data: settings, isLoading } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_settings')
        .select('*');
      if (error) throw error;
      const settingsObj: Record<string, any> = {};
      data?.forEach((s) => {
        settingsObj[s.key] = s.value;
      });
      return settingsObj;
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: any }) => {
      const { error } = await supabase
        .from('site_settings')
        .upsert(
          {
            key,
            value,
            category: 'general',
            updated_by: (await supabase.auth.getUser()).data.user?.id,
          },
          { onConflict: 'key' }
        );
      if (error) throw error;

      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'settings_updated',
        target_type: 'setting',
        details: { key, value },
      });
    },
    onSuccess: () => {
      toast({ title: 'Настройки сохранены' });
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const handleSave = (key: string, value: any) => {
    updateMutation.mutate({ key, value });
  };

  if (!hasAnyPermission(['platform.settings', 'platform.features', 'platform.categories'])) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к настройкам платформы</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Управление платформой</h1>
          <p className="text-muted-foreground">
            Редактор сайта, Feature Flags, категории и конфигурация MineMods
          </p>
        </div>

        <Tabs defaultValue="site-control">
          <TabsList className="flex-wrap h-auto">
            {hasPermission('platform.settings') && (
              <TabsTrigger value="site-control">
                <LayoutDashboard className="h-4 w-4 mr-2" />
                Редактор сайта
              </TabsTrigger>
            )}
            {hasPermission('platform.features') && (
              <TabsTrigger value="features">
                <ToggleLeft className="h-4 w-4 mr-2" />
                Feature Flags
              </TabsTrigger>
            )}
            {hasPermission('platform.categories') && (
              <TabsTrigger value="categories">
                <FileText className="h-4 w-4 mr-2" />
                Категории
              </TabsTrigger>
            )}
            {hasPermission('platform.settings') && (
              <TabsTrigger value="general">
                <Globe className="h-4 w-4 mr-2" />
                Общие
              </TabsTrigger>
            )}
            {hasPermission('platform.settings') && (
              <TabsTrigger value="security">
                <Shield className="h-4 w-4 mr-2" />
                Безопасность
              </TabsTrigger>
            )}
            {hasPermission('platform.settings') && (
              <TabsTrigger value="moderation">
                <Settings className="h-4 w-4 mr-2" />
                Модерация
              </TabsTrigger>
            )}
            {hasPermission('platform.features') && (
              <TabsTrigger value="history">
                <History className="h-4 w-4 mr-2" />
                История
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="site-control" className="mt-6">
            <SiteControlTab />
          </TabsContent>

          <TabsContent value="features" className="mt-6">
            <FeatureFlagsTab />
          </TabsContent>

          <TabsContent value="categories" className="mt-6">
            <CategoriesTab />
          </TabsContent>

          <TabsContent value="general" className="mt-6">
            <GeneralTab
              settings={settings}
              isLoading={isLoading}
              onSave={handleSave}
              isSaving={updateMutation.isPending}
            />
          </TabsContent>

          <TabsContent value="security" className="mt-6">
            <SecurityTab
              settings={settings}
              isLoading={isLoading}
              onSave={handleSave}
              isSaving={updateMutation.isPending}
            />
          </TabsContent>

          <TabsContent value="moderation" className="mt-6">
            <ModerationTab
              settings={settings}
              isLoading={isLoading}
              onSave={handleSave}
            />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <ChangeHistoryTab />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
