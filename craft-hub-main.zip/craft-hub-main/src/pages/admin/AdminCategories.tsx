import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import {
  Plus,
  Edit,
  Trash,
  GripVertical,
  Shield,
} from 'lucide-react';

export default function AdminCategories() {
  const { hasPermission } = usePermissions();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    name_plural: '',
    slug: '',
    description: '',
    icon: '',
    enabled: true,
  });

  const { data: projectTypes, isLoading } = useQuery({
    queryKey: ['project-types-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_types')
        .select('*')
        .order('sort_order', { ascending: true });

      if (error) throw error;
      return data || [];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (selectedType) {
        // Update
        const { error } = await supabase
          .from('project_types')
          .update(data)
          .eq('id', selectedType.id);
        if (error) throw error;
      } else {
        // Insert
        const { error } = await supabase
          .from('project_types')
          .insert({
            ...data,
            sort_order: (projectTypes?.length || 0) + 1,
          });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: 'Сохранено' });
      setEditDialogOpen(false);
      setSelectedType(null);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['project-types-admin'] });
      queryClient.invalidateQueries({ queryKey: ['project-types'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('project_types').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Удалено' });
      queryClient.invalidateQueries({ queryKey: ['project-types-admin'] });
      queryClient.invalidateQueries({ queryKey: ['project-types'] });
    },
  });

  const resetForm = () => {
    setFormData({
      name: '',
      name_plural: '',
      slug: '',
      description: '',
      icon: '',
      enabled: true,
    });
  };

  const openEditDialog = (type?: any) => {
    if (type) {
      setSelectedType(type);
      setFormData({
        name: type.name,
        name_plural: type.name_plural,
        slug: type.slug,
        description: type.description || '',
        icon: type.icon || '',
        enabled: type.enabled,
      });
    } else {
      setSelectedType(null);
      resetForm();
    }
    setEditDialogOpen(true);
  };

  const handleSave = () => {
    saveMutation.mutate(formData);
  };

  if (!hasPermission('platform.categories')) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к управлению категориями</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Типы проектов</h1>
            <p className="text-muted-foreground">
              Управление категориями контента
            </p>
          </div>
          <Button onClick={() => openEditDialog()}>
            <Plus className="h-4 w-4 mr-2" />
            Добавить
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10"></TableHead>
                  <TableHead>Название</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead>Описание</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead className="w-20"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Загрузка...
                    </TableCell>
                  </TableRow>
                ) : projectTypes?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Типы проектов не найдены
                    </TableCell>
                  </TableRow>
                ) : (
                  projectTypes?.map((type: any) => (
                    <TableRow key={type.id}>
                      <TableCell>
                        <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {type.icon && <span>{type.icon}</span>}
                          <div>
                            <p className="font-medium">{type.name}</p>
                            <p className="text-sm text-muted-foreground">{type.name_plural}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{type.slug}</TableCell>
                      <TableCell className="text-muted-foreground max-w-xs truncate">
                        {type.description || '—'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={type.enabled ? 'default' : 'secondary'}>
                          {type.enabled ? 'Активен' : 'Отключен'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => openEditDialog(type)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              if (confirm('Удалить этот тип проекта?')) {
                                deleteMutation.mutate(type.id);
                              }
                            }}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {selectedType ? 'Редактировать тип' : 'Новый тип проекта'}
              </DialogTitle>
              <DialogDescription>
                {selectedType ? 'Измените параметры типа проекта' : 'Добавьте новый тип проекта'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Название (ед.ч.)</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData(f => ({ ...f, name: e.target.value }))}
                    placeholder="Мод"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Название (мн.ч.)</Label>
                  <Input
                    value={formData.name_plural}
                    onChange={(e) => setFormData(f => ({ ...f, name_plural: e.target.value }))}
                    placeholder="Моды"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Slug</Label>
                <Input
                  value={formData.slug}
                  onChange={(e) => setFormData(f => ({ ...f, slug: e.target.value }))}
                  placeholder="mods"
                />
              </div>

              <div className="space-y-2">
                <Label>Описание</Label>
                <Input
                  value={formData.description}
                  onChange={(e) => setFormData(f => ({ ...f, description: e.target.value }))}
                  placeholder="Модификации для Minecraft"
                />
              </div>

              <div className="space-y-2">
                <Label>Иконка (emoji)</Label>
                <Input
                  value={formData.icon}
                  onChange={(e) => setFormData(f => ({ ...f, icon: e.target.value }))}
                  placeholder="📦"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Активен</Label>
                <Switch
                  checked={formData.enabled}
                  onCheckedChange={(checked) => setFormData(f => ({ ...f, enabled: checked }))}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleSave} disabled={saveMutation.isPending}>
                Сохранить
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
