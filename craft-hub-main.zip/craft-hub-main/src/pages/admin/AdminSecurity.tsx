import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatDate } from '@/lib/format';
import {
  Shield,
  AlertTriangle,
  Activity,
  Lock,
  Unlock,
  User,
} from 'lucide-react';

const severityConfig = {
  info: { label: 'Инфо', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  warning: { label: 'Предупреждение', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  critical: { label: 'Критическое', color: 'bg-red-500/20 text-red-400 border-red-500/30' },
};

const eventTypeIcons: Record<string, React.ReactNode> = {
  login_success: <Unlock className="h-4 w-4 text-green-400" />,
  login_failed: <Lock className="h-4 w-4 text-red-400" />,
  rate_limit: <AlertTriangle className="h-4 w-4 text-orange-400" />,
  suspicious_activity: <AlertTriangle className="h-4 w-4 text-red-400" />,
};

export default function AdminSecurity() {
  const { hasPermission } = usePermissions();

  const { data: events, isLoading } = useQuery({
    queryKey: ['security-events'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('security_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      return data || [];
    },
    enabled: hasPermission('security.view'),
  });

  const { data: stats } = useQuery({
    queryKey: ['security-stats'],
    queryFn: async () => {
      const [warningsRes, criticalRes, bansRes] = await Promise.all([
        supabase.from('security_events').select('id', { count: 'exact', head: true }).eq('severity', 'warning'),
        supabase.from('security_events').select('id', { count: 'exact', head: true }).eq('severity', 'critical'),
        supabase.from('user_bans').select('id', { count: 'exact', head: true }).eq('is_active', true),
      ]);

      return {
        warnings: warningsRes.count || 0,
        critical: criticalRes.count || 0,
        activeBans: bansRes.count || 0,
      };
    },
    enabled: hasPermission('security.view'),
  });

  if (!hasPermission('security.view')) {
    return (
      <AdminLayout>
        <div className="p-6">
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-3" />
              <p>У вас нет доступа к разделу безопасности</p>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Безопасность</h1>
          <p className="text-muted-foreground">
            Мониторинг безопасности платформы
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/20 text-orange-500">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.warnings || 0}</p>
                  <p className="text-sm text-muted-foreground">Предупреждения</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/20 text-red-500">
                  <Shield className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.critical || 0}</p>
                  <p className="text-sm text-muted-foreground">Критические</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/20 text-red-500">
                  <User className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats?.activeBans || 0}</p>
                  <p className="text-sm text-muted-foreground">Активных банов</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Events */}
        <Card>
          <CardHeader>
            <CardTitle>События безопасности</CardTitle>
            <CardDescription>
              Последние события, требующие внимания
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Событие</TableHead>
                  <TableHead>Уровень</TableHead>
                  <TableHead>IP</TableHead>
                  <TableHead>Детали</TableHead>
                  <TableHead>Дата</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      Загрузка...
                    </TableCell>
                  </TableRow>
                ) : events?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      <Activity className="h-12 w-12 mx-auto mb-3" />
                      <p>Нет событий безопасности</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  events?.map((event: any) => (
                    <TableRow key={event.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {eventTypeIcons[event.event_type] || <Activity className="h-4 w-4" />}
                          <span>{event.event_type}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={severityConfig[event.severity as keyof typeof severityConfig]?.color}
                        >
                          {severityConfig[event.severity as keyof typeof severityConfig]?.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground font-mono text-sm">
                        {event.ip_address || '—'}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">
                        {event.details ? JSON.stringify(event.details) : '—'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(event.created_at)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
