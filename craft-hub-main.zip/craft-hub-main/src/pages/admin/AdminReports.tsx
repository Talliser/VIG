import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/format';
import {
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  MessageSquare,
  Package,
  User,
} from 'lucide-react';

const statusConfig = {
  pending: { label: 'Ожидает', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  resolved: { label: 'Решено', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  dismissed: { label: 'Отклонено', color: 'bg-gray-500/20 text-gray-400 border-gray-500/30' },
};

const targetTypeIcons = {
  mod: <Package className="h-4 w-4" />,
  comment: <MessageSquare className="h-4 w-4" />,
  user: <User className="h-4 w-4" />,
};

export default function AdminReports() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentTab, setCurrentTab] = useState('pending');
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [resolveDialogOpen, setResolveDialogOpen] = useState(false);
  const [resolution, setResolution] = useState('');

  const { data: reports, isLoading } = useQuery({
    queryKey: ['admin-reports', currentTab],
    queryFn: async () => {
      let query = supabase
        .from('reports')
        .select(`
          *,
          reporter:reporter_id (
            username,
            display_name
          )
        `)
        .order('created_at', { ascending: false });

      if (currentTab !== 'all') {
        query = query.eq('status', currentTab);
      }

      const { data, error } = await query.limit(50);
      if (error) throw error;
      return data || [];
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async ({ reportId, status }: { reportId: string; status: string }) => {
      const { error } = await supabase
        .from('reports')
        .update({ 
          status,
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq('id', reportId);

      if (error) throw error;

      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: `report_${status}`,
        target_type: 'report',
        target_id: reportId,
        details: { resolution },
      });
    },
    onSuccess: () => {
      toast({ title: 'Жалоба обработана' });
      setResolveDialogOpen(false);
      setSelectedReport(null);
      setResolution('');
      queryClient.invalidateQueries({ queryKey: ['admin-reports'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const handleResolve = (status: 'resolved' | 'dismissed') => {
    if (!selectedReport) return;
    resolveMutation.mutate({ reportId: selectedReport.id, status });
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Жалобы</h1>
          <p className="text-muted-foreground">
            Обработка жалоб пользователей
          </p>
        </div>

        <Tabs value={currentTab} onValueChange={setCurrentTab}>
          <TabsList>
            <TabsTrigger value="pending">Ожидают</TabsTrigger>
            <TabsTrigger value="resolved">Решено</TabsTrigger>
            <TabsTrigger value="dismissed">Отклонено</TabsTrigger>
            <TabsTrigger value="all">Все</TabsTrigger>
          </TabsList>

          <TabsContent value={currentTab} className="mt-6">
            {isLoading ? (
              <div className="text-center py-8">Загрузка...</div>
            ) : reports?.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <AlertTriangle className="h-12 w-12 mx-auto mb-3" />
                  <p>Жалобы не найдены</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {reports?.map((report: any) => (
                  <Card key={report.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="flex items-center gap-1">
                              {targetTypeIcons[report.target_type as keyof typeof targetTypeIcons]}
                              {report.target_type}
                            </Badge>
                            <Badge 
                              variant="outline" 
                              className={statusConfig[report.status as keyof typeof statusConfig]?.color}
                            >
                              {statusConfig[report.status as keyof typeof statusConfig]?.label}
                            </Badge>
                          </div>

                          <h3 className="font-semibold mb-1">{report.reason}</h3>
                          {report.description && (
                            <p className="text-sm text-muted-foreground mb-2">
                              {report.description}
                            </p>
                          )}

                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>от {report.reporter?.display_name || report.reporter?.username || 'Аноним'}</span>
                            <span>{formatDate(report.created_at)}</span>
                          </div>
                        </div>

                        {report.status === 'pending' && (
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => {
                                setSelectedReport(report);
                                setResolveDialogOpen(true);
                              }}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Решить
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedReport(report);
                                handleResolve('dismissed');
                              }}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Отклонить
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Resolve Dialog */}
        <Dialog open={resolveDialogOpen} onOpenChange={setResolveDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Решить жалобу</DialogTitle>
              <DialogDescription>
                Опишите принятые меры по данной жалобе
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Принятые меры</Label>
                <Textarea
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value)}
                  placeholder="Опишите что было сделано..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setResolveDialogOpen(false)}>
                Отмена
              </Button>
              <Button 
                onClick={() => handleResolve('resolved')}
                disabled={resolveMutation.isPending}
              >
                Подтвердить
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
