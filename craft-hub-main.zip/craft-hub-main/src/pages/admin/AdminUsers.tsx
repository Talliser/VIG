import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { UserDetailPanel } from '@/components/admin/UserDetailPanel';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/format';
import {
  Search,
  MoreHorizontal,
  Shield,
  Ban,
  AlertTriangle,
  Eye,
  UserCheck,
  UserX,
} from 'lucide-react';

type AppRole = 'user' | 'author' | 'moderator' | 'admin' | 'super_admin' | 'support';

const roleLabels: Record<AppRole, { label: string; color: string }> = {
  super_admin: { label: 'Super Admin', color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  admin: { label: 'Admin', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  moderator: { label: 'Moderator', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  support: { label: 'Support', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  author: { label: 'Author', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
  user: { label: 'User', color: 'bg-gray-500/20 text-gray-400 border-gray-500/30' },
};

export default function AdminUsers() {
  const { hasPermission, role: currentRole } = usePermissions();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [banDialogOpen, setBanDialogOpen] = useState(false);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [banType, setBanType] = useState<'temporary' | 'permanent'>('temporary');
  const [banDuration, setBanDuration] = useState('7');
  const [newRole, setNewRole] = useState<AppRole>('user');
  const [detailUser, setDetailUser] = useState<any>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const { data: users, isLoading } = useQuery({
    queryKey: ['admin-users', search, roleFilter],
    queryFn: async () => {
      let query = supabase
        .from('profiles')
        .select(`
          *,
          user_roles (role)
        `)
        .order('created_at', { ascending: false });

      if (search) {
        query = query.or(`username.ilike.%${search}%,display_name.ilike.%${search}%`);
      }

      const { data, error } = await query.limit(50);

      if (error) throw error;

      let filteredData = data || [];

      if (roleFilter !== 'all') {
        filteredData = filteredData.filter((user: any) => 
          user.user_roles?.some((r: any) => r.role === roleFilter)
        );
      }

      return filteredData;
    },
  });

  const banMutation = useMutation({
    mutationFn: async ({ userId, reason, type, expiresAt }: { 
      userId: string; 
      reason: string; 
      type: string;
      expiresAt?: string;
    }) => {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (!profile) throw new Error('Profile not found');

      const { error } = await supabase.from('user_bans').insert({
        user_id: profile.id,
        banned_by: (await supabase.auth.getUser()).data.user?.id || '',
        reason,
        ban_type: type,
        expires_at: expiresAt,
      });

      if (error) throw error;

      // Log action
      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'user_banned',
        target_type: 'user',
        target_id: userId,
        details: { reason, type, expiresAt },
      });
    },
    onSuccess: () => {
      toast({ title: 'Пользователь заблокирован' });
      setBanDialogOpen(false);
      setBanReason('');
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const roleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: AppRole }) => {
      // First, remove existing role
      await supabase.from('user_roles').delete().eq('user_id', userId);

      // Then insert new role
      const { error } = await supabase.from('user_roles').insert({
        user_id: userId,
        role,
      });

      if (error) throw error;

      // Log action
      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'role_changed',
        target_type: 'user',
        target_id: userId,
        details: { new_role: role },
      });
    },
    onSuccess: () => {
      toast({ title: 'Роль изменена' });
      setRoleDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const handleBan = () => {
    if (!selectedUser || !banReason) return;

    const expiresAt = banType === 'temporary' 
      ? new Date(Date.now() + parseInt(banDuration) * 24 * 60 * 60 * 1000).toISOString()
      : undefined;

    banMutation.mutate({
      userId: selectedUser.user_id,
      reason: banReason,
      type: banType,
      expiresAt,
    });
  };

  const handleRoleChange = () => {
    if (!selectedUser || !newRole) return;
    roleMutation.mutate({ userId: selectedUser.user_id, role: newRole });
  };

  const getUserRole = (user: any): AppRole => {
    return user.user_roles?.[0]?.role || 'user';
  };

  return (
    <AdminLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Пользователи</h1>
          <p className="text-muted-foreground">
            Управление пользователями платформы
          </p>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по имени или username..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="Все роли" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все роли</SelectItem>
                  <SelectItem value="super_admin">Super Admin</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="moderator">Moderator</SelectItem>
                  <SelectItem value="support">Support</SelectItem>
                  <SelectItem value="author">Author</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Пользователь</TableHead>
                  <TableHead>Роль</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Регистрация</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      Загрузка...
                    </TableCell>
                  </TableRow>
                ) : users?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Пользователи не найдены
                    </TableCell>
                  </TableRow>
                ) : (
                  users?.map((user: any) => {
                    const userRole = getUserRole(user);
                    return (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={user.avatar || undefined} />
                              <AvatarFallback>
                                {user.display_name?.[0] || user.username?.[0] || 'U'}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{user.display_name || user.username}</p>
                              <p className="text-sm text-muted-foreground">@{user.username}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={roleLabels[userRole]?.color}>
                            {roleLabels[userRole]?.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.verified ? (
                            <Badge className="bg-green-500/20 text-green-500 border-green-500/30">
                              <UserCheck className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          ) : (
                            <Badge variant="outline">Обычный</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(user.created_at)}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => { setDetailUser(user); setDetailOpen(true); }}>
                                <Eye className="h-4 w-4 mr-2" />
                                Просмотр профиля
                              </DropdownMenuItem>
                              {hasPermission('users.roles') && userRole !== 'super_admin' && (
                                <DropdownMenuItem onClick={() => {
                                  setSelectedUser(user);
                                  setNewRole(userRole);
                                  setRoleDialogOpen(true);
                                }}>
                                  <Shield className="h-4 w-4 mr-2" />
                                  Изменить роль
                                </DropdownMenuItem>
                              )}
                              {hasPermission('users.edit') && (
                                <DropdownMenuItem>
                                  <AlertTriangle className="h-4 w-4 mr-2" />
                                  Предупреждение
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {hasPermission('users.ban') && userRole !== 'super_admin' && userRole !== 'admin' && (
                                <DropdownMenuItem 
                                  className="text-red-500"
                                  onClick={() => {
                                    setSelectedUser(user);
                                    setBanDialogOpen(true);
                                  }}
                                >
                                  <Ban className="h-4 w-4 mr-2" />
                                  Заблокировать
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Ban Dialog */}
        <Dialog open={banDialogOpen} onOpenChange={setBanDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Заблокировать пользователя</DialogTitle>
              <DialogDescription>
                Блокировка пользователя {selectedUser?.display_name || selectedUser?.username}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Тип блокировки</Label>
                <Select value={banType} onValueChange={(v: 'temporary' | 'permanent') => setBanType(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="temporary">Временная</SelectItem>
                    <SelectItem value="permanent">Постоянная</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {banType === 'temporary' && (
                <div className="space-y-2">
                  <Label>Длительность (дней)</Label>
                  <Input
                    type="number"
                    value={banDuration}
                    onChange={(e) => setBanDuration(e.target.value)}
                    min="1"
                    max="365"
                  />
                </div>
              )}
              <div className="space-y-2">
                <Label>Причина</Label>
                <Textarea
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="Укажите причину блокировки..."
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBanDialogOpen(false)}>
                Отмена
              </Button>
              <Button 
                variant="destructive" 
                onClick={handleBan}
                disabled={!banReason || banMutation.isPending}
              >
                Заблокировать
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Role Change Dialog */}
        <Dialog open={roleDialogOpen} onOpenChange={setRoleDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Изменить роль</DialogTitle>
              <DialogDescription>
                Изменение роли для {selectedUser?.display_name || selectedUser?.username}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Новая роль</Label>
                <Select value={newRole} onValueChange={(v: AppRole) => setNewRole(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currentRole === 'super_admin' && (
                      <>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="moderator">Moderator</SelectItem>
                        <SelectItem value="support">Support</SelectItem>
                      </>
                    )}
                    <SelectItem value="author">Author</SelectItem>
                    <SelectItem value="user">User</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRoleDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleRoleChange} disabled={roleMutation.isPending}>
                Сохранить
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* User Detail Panel */}
        <UserDetailPanel open={detailOpen} onOpenChange={setDetailOpen} user={detailUser} />
      </div>
    </AdminLayout>
  );
}
