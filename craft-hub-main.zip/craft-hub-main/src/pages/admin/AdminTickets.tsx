import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/format';
import {
  Ticket,
  Clock,
  CheckCircle,
  MessageSquare,
  Send,
  User,
} from 'lucide-react';

const statusConfig = {
  open: { label: 'Открыт', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  in_progress: { label: 'В работе', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  resolved: { label: 'Решён', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  closed: { label: 'Закрыт', color: 'bg-gray-500/20 text-gray-400 border-gray-500/30' },
};

const priorityConfig = {
  low: { label: 'Низкий', color: 'text-gray-400' },
  normal: { label: 'Обычный', color: 'text-blue-400' },
  high: { label: 'Высокий', color: 'text-orange-400' },
  urgent: { label: 'Срочный', color: 'text-red-400' },
};

export default function AdminTickets() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentTab, setCurrentTab] = useState('open');
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [replyMessage, setReplyMessage] = useState('');

  const { data: tickets, isLoading } = useQuery({
    queryKey: ['admin-tickets', currentTab],
    queryFn: async () => {
      let query = supabase
        .from('tickets')
        .select('*')
        .order('created_at', { ascending: false });

      if (currentTab !== 'all') {
        query = query.eq('status', currentTab);
      }

      const { data, error } = await query.limit(50);
      if (error) throw error;
      return data || [];
    },
  });

  const { data: messages } = useQuery({
    queryKey: ['ticket-messages', selectedTicket?.id],
    queryFn: async () => {
      if (!selectedTicket) return [];

      const { data, error } = await supabase
        .from('ticket_messages')
        .select('*')
        .eq('ticket_id', selectedTicket.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedTicket,
  });

  const replyMutation = useMutation({
    mutationFn: async ({ ticketId, message }: { ticketId: string; message: string }) => {
      const user = (await supabase.auth.getUser()).data.user;
      
      const { error } = await supabase.from('ticket_messages').insert({
        ticket_id: ticketId,
        user_id: user?.id || '',
        message,
        is_internal: false,
      });

      if (error) throw error;

      // Update ticket status to in_progress
      await supabase
        .from('tickets')
        .update({ status: 'in_progress' })
        .eq('id', ticketId);
    },
    onSuccess: () => {
      toast({ title: 'Ответ отправлен' });
      setReplyMessage('');
      queryClient.invalidateQueries({ queryKey: ['ticket-messages'] });
      queryClient.invalidateQueries({ queryKey: ['admin-tickets'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ ticketId, status }: { ticketId: string; status: string }) => {
      const { error } = await supabase
        .from('tickets')
        .update({ 
          status,
          resolved_at: status === 'resolved' ? new Date().toISOString() : null,
        })
        .eq('id', ticketId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Статус обновлён' });
      queryClient.invalidateQueries({ queryKey: ['admin-tickets'] });
    },
  });

  const handleReply = () => {
    if (!selectedTicket || !replyMessage.trim()) return;
    replyMutation.mutate({ ticketId: selectedTicket.id, message: replyMessage });
  };

  return (
    <AdminLayout>
      <div className="p-6 h-[calc(100vh-4rem)] flex flex-col">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Тикеты поддержки</h1>
          <p className="text-muted-foreground">
            Обработка обращений пользователей
          </p>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
          {/* Tickets List */}
          <div className="lg:col-span-1 flex flex-col">
            <Tabs value={currentTab} onValueChange={setCurrentTab}>
              <TabsList className="w-full">
                <TabsTrigger value="open" className="flex-1">Открытые</TabsTrigger>
                <TabsTrigger value="in_progress" className="flex-1">В работе</TabsTrigger>
                <TabsTrigger value="resolved" className="flex-1">Решено</TabsTrigger>
              </TabsList>
            </Tabs>

            <Card className="flex-1 mt-4 overflow-hidden">
              <ScrollArea className="h-full">
                <div className="p-2 space-y-2">
                  {isLoading ? (
                    <div className="text-center py-8">Загрузка...</div>
                  ) : tickets?.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Ticket className="h-12 w-12 mx-auto mb-3" />
                      <p>Тикеты не найдены</p>
                    </div>
                  ) : (
                    tickets?.map((ticket: any) => (
                      <div
                        key={ticket.id}
                        onClick={() => setSelectedTicket(ticket)}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedTicket?.id === ticket.id
                            ? 'bg-primary/10 border border-primary/30'
                            : 'bg-muted/50 hover:bg-muted'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <h4 className="font-medium text-sm line-clamp-1">{ticket.subject}</h4>
                          <Badge 
                            variant="outline" 
                            className={`text-xs shrink-0 ${statusConfig[ticket.status as keyof typeof statusConfig]?.color}`}
                          >
                            {statusConfig[ticket.status as keyof typeof statusConfig]?.label}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                          {ticket.description}
                        </p>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span className={priorityConfig[ticket.priority as keyof typeof priorityConfig]?.color}>
                            {priorityConfig[ticket.priority as keyof typeof priorityConfig]?.label}
                          </span>
                          <span>{formatDate(ticket.created_at)}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </Card>
          </div>

          {/* Ticket Detail */}
          <Card className="lg:col-span-2 flex flex-col overflow-hidden">
            {selectedTicket ? (
              <>
                <CardHeader className="border-b shrink-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{selectedTicket.subject}</CardTitle>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge 
                          variant="outline" 
                          className={statusConfig[selectedTicket.status as keyof typeof statusConfig]?.color}
                        >
                          {statusConfig[selectedTicket.status as keyof typeof statusConfig]?.label}
                        </Badge>
                        <Badge variant="outline">
                          {selectedTicket.category}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {selectedTicket.status !== 'resolved' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => statusMutation.mutate({ 
                            ticketId: selectedTicket.id, 
                            status: 'resolved' 
                          })}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Решить
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>

                <ScrollArea className="flex-1">
                  <div className="p-4 space-y-4">
                    {/* Original Message */}
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-2">
                        <User className="h-4 w-4" />
                        <span className="text-sm font-medium">Пользователь</span>
                        <span className="text-xs text-muted-foreground">
                          {formatDate(selectedTicket.created_at)}
                        </span>
                      </div>
                      <p className="text-sm">{selectedTicket.description}</p>
                    </div>

                    {/* Messages */}
                    {messages?.map((msg: any) => (
                      <div 
                        key={msg.id} 
                        className={`p-4 rounded-lg ${
                          msg.is_internal 
                            ? 'bg-yellow-500/10 border border-yellow-500/30' 
                            : 'bg-primary/10'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <MessageSquare className="h-4 w-4" />
                          <span className="text-sm font-medium">
                            {msg.is_internal ? 'Заметка' : 'Ответ'}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {formatDate(msg.created_at)}
                          </span>
                        </div>
                        <p className="text-sm">{msg.message}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Reply Form */}
                {selectedTicket.status !== 'resolved' && selectedTicket.status !== 'closed' && (
                  <div className="p-4 border-t shrink-0">
                    <div className="flex gap-2">
                      <Textarea
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        placeholder="Напишите ответ..."
                        className="resize-none"
                        rows={2}
                      />
                      <Button 
                        onClick={handleReply}
                        disabled={!replyMessage.trim() || replyMutation.isPending}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <Ticket className="h-12 w-12 mx-auto mb-3" />
                  <p>Выберите тикет для просмотра</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
