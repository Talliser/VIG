import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Grid3X3, List, Search, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Layout } from '@/components/layout/Layout';
import { ModCard } from '@/components/mods/ModCard';
import { ModFilters, FiltersState } from '@/components/mods/ModFilters';
import { useMods } from '@/hooks/useMods';
import { cn } from '@/lib/utils';
import type { Edition, Category, Loader, SortOption } from '@/lib/types';

export default function ModsPage() {
  const [searchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Get initial values from URL
  const initialEdition = searchParams.get('edition') as Edition | null;
  const initialSort = searchParams.get('sort') as SortOption | null;
  const initialType = searchParams.get('type'); // Project type (mods, resourcepacks, etc.)
  
  const [filters, setFilters] = useState<FiltersState>({
    search: '',
    edition: initialEdition,
    categories: [] as Category[],
    loaders: [] as Loader[],
    versions: [] as string[],
    sort: initialSort || 'downloads' as SortOption,
    projectType: initialType,
  });

  // Update filters when URL changes
  useEffect(() => {
    const urlEdition = searchParams.get('edition') as Edition | null;
    const urlSort = searchParams.get('sort') as SortOption | null;
    const urlType = searchParams.get('type');
    
    setFilters(prev => ({
      ...prev,
      edition: urlEdition || prev.edition,
      sort: urlSort || prev.sort,
      projectType: urlType || prev.projectType,
    }));
  }, [searchParams]);

  const { data: mods, isLoading, error } = useMods({
    edition: filters.edition,
    categories: filters.categories,
    loaders: filters.loaders,
    minecraftVersions: filters.versions,
    search: filters.search,
    sort: filters.sort,
    projectType: filters.projectType,
    limit: 50,
  });

  const filteredMods = mods || [];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            {filters.projectType === 'resourcepacks' && '🎨 Ресурс-паки'}
            {filters.projectType === 'mods' && '📦 Моды'}
            {filters.projectType === 'maps' && '🗺️ Карты'}
            {filters.projectType === 'shaders' && '✨ Шейдеры'}
            {filters.projectType === 'modpacks' && '📚 Сборки модов'}
            {!filters.projectType && filters.edition === 'java' && '☕ Java Edition'}
            {!filters.projectType && filters.edition === 'bedrock' && '🪨 Bedrock Edition'}
            {!filters.projectType && !filters.edition && '📦 Весь контент'}
          </h1>
          <p className="text-muted-foreground">
            {isLoading ? 'Загрузка...' : `${filteredMods.length} проектов найдено`}
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-80 flex-shrink-0">
            <ModFilters 
              filters={filters}
              onFiltersChange={setFilters}
            />
          </div>

          {/* Mods Grid */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              {/* Search */}
              <div className="relative w-full sm:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Быстрый поиск..."
                  value={filters.search}
                  onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                  className="pl-10 rounded-xl bg-secondary/50"
                />
              </div>

              {/* View Toggle */}
              <div className="flex items-center gap-2 bg-secondary/50 p-1 rounded-xl">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="icon-sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="icon-sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <span className="ml-3 text-muted-foreground">Загрузка модов...</span>
              </div>
            )}

            {/* Error State */}
            {error && (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-destructive/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-destructive" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Ошибка загрузки
                </h3>
                <p className="text-muted-foreground">
                  Не удалось загрузить моды. Попробуйте обновить страницу.
                </p>
              </div>
            )}

            {/* Mods Grid */}
            {!isLoading && !error && filteredMods.length > 0 && (
              <div className={cn(
                'grid gap-6',
                viewMode === 'grid' 
                  ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' 
                  : 'grid-cols-1'
              )}>
                {filteredMods.map((mod) => (
                  <ModCard 
                    key={mod.id} 
                    mod={mod}
                    className="animate-fade-in"
                  />
                ))}
              </div>
            )}

            {/* Empty State */}
            {!isLoading && !error && filteredMods.length === 0 && (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Моды не найдены
                </h3>
                <p className="text-muted-foreground">
                  Попробуйте изменить фильтры или поисковый запрос
                </p>
              </div>
            )}

            {/* Load More */}
            {!isLoading && filteredMods.length > 0 && filteredMods.length >= 20 && (
              <div className="mt-8 text-center">
                <Button variant="outline" size="lg" className="rounded-xl">
                  Загрузить ещё
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
