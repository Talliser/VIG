import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Download, 
  Eye, 
  Star, 
  Clock, 
  Heart,
  Share2,
  Flag,
  ChevronLeft,
  ChevronRight,
  Check,
  Copy,
  Calendar,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Layout } from '@/components/layout/Layout';
import { ModCard } from '@/components/mods/ModCard';
import { CommentSection } from '@/components/comments/CommentSection';
import { useMod, useSimilarMods, useIncrementViewCount } from '@/hooks/useMod';
import { CATEGORIES, LOADERS } from '@/lib/constants';
import { formatDownloads, formatTimeAgo } from '@/lib/format';
import { cn } from '@/lib/utils';
import type { Category, Loader, Edition } from '@/lib/types';

export default function ModDetailPage() {
  const { slug } = useParams();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [copied, setCopied] = useState(false);
  const [hasIncrementedView, setHasIncrementedView] = useState(false);

  const { data: mod, isLoading, error } = useMod(slug || '');
  const incrementViewCount = useIncrementViewCount();
  
  const categories = (mod?.categories || []) as Category[];
  const { data: similarMods } = useSimilarMods(mod?.id || '', categories, 4);

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  // Increment view count once per page load
  useEffect(() => {
    if (mod?.id && !hasIncrementedView) {
      incrementViewCount.mutate(mod.id);
      setHasIncrementedView(true);
    }
  }, [mod?.id, hasIncrementedView, incrementViewCount]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Loading state
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground mt-4">Загрузка мода...</p>
        </div>
      </Layout>
    );
  }

  // Error state
  if (error || !mod) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Мод не найден</h1>
          <p className="text-muted-foreground mb-6">Возможно, мод был удалён или ссылка неверна.</p>
          <Button asChild>
            <Link to="/mods">Вернуться к модам</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const gallery = (mod.gallery || []) as string[];
  const allImages = gallery.length > 0 ? gallery : (mod.icon ? [mod.icon] : []);
  const loaders = (mod.loaders || []) as Loader[];
  const edition = mod.edition as Edition;
  const minecraftVersions = (mod.minecraft_versions || []) as string[];
  const tags = (mod.tags || []) as string[];
  const versions = mod.versions || [];

  const categoryData = categories.map(c => CATEGORIES.find(cat => cat.id === c)).filter(Boolean);
  const loaderData = loaders.map(l => LOADERS.find(loader => loader.id === l)).filter(Boolean);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-foreground transition-colors">Главная</Link>
          <span>/</span>
          <Link to="/mods" className="hover:text-foreground transition-colors">Моды</Link>
          <span>/</span>
          <span className="text-foreground">{mod.name}</span>
        </nav>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8">
          {/* Left Column - Main Content */}
          <div className="space-y-8">
            {/* Header Card */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <div className="flex flex-col sm:flex-row gap-6">
                {/* Icon */}
                <div className="flex-shrink-0">
                  <img
                    src={mod.icon || `https://api.dicebear.com/7.x/shapes/svg?seed=${mod.slug}`}
                    alt={mod.name}
                    className="w-24 h-24 sm:w-32 sm:h-32 rounded-2xl object-cover bg-secondary"
                    onError={(e) => {
                      e.currentTarget.src = `https://api.dicebear.com/7.x/shapes/svg?seed=${mod.slug}`;
                    }}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-start gap-2 mb-2">
                    <Badge variant={edition} size="lg">
                      {edition === 'java' ? 'Java Edition' : 'Bedrock Edition'}
                    </Badge>
                    {mod.featured && (
                      <Badge variant="warning" size="lg">
                        <Star className="w-3.5 h-3.5 mr-1 fill-current" />
                        Рекомендуемый
                      </Badge>
                    )}
                  </div>

                  <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
                    {mod.name}
                  </h1>

                  <p className="text-muted-foreground mb-4">
                    by{' '}
                    <Link 
                      to={`/author/${mod.author?.id}`}
                      className="text-foreground hover:text-primary transition-colors font-medium"
                    >
                      {mod.author?.username || 'Unknown'}
                    </Link>
                    {mod.author?.verified && (
                      <Check className="inline w-4 h-4 ml-1 text-primary" />
                    )}
                  </p>

                  <p className="text-muted-foreground line-clamp-2 sm:line-clamp-none">
                    {mod.summary}
                  </p>
                </div>
              </div>

              {/* Badges Row */}
              <div className="flex flex-wrap gap-2 mt-6 pt-6 border-t border-border">
                {/* Loaders */}
                {loaderData.map((loader) => (
                  <Badge key={loader!.id} variant={loader!.id as any} size="lg">
                    {loader!.name}
                  </Badge>
                ))}
                
                {/* Categories */}
                {categoryData.map((cat) => (
                  <Badge key={cat!.id} variant="category" size="lg">
                    {cat!.icon} {cat!.name}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Gallery */}
            {allImages.length > 0 && (
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="relative aspect-video bg-secondary">
                  <img
                    src={allImages[currentImageIndex]}
                    alt={`${mod.name} screenshot ${currentImageIndex + 1}`}
                    className="w-full h-full object-cover"
                  />
                  
                  {allImages.length > 1 && (
                    <>
                      <Button
                        variant="glass"
                        size="icon"
                        className="absolute left-4 top-1/2 -translate-y-1/2"
                        onClick={() => setCurrentImageIndex(i => i > 0 ? i - 1 : allImages.length - 1)}
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </Button>
                      <Button
                        variant="glass"
                        size="icon"
                        className="absolute right-4 top-1/2 -translate-y-1/2"
                        onClick={() => setCurrentImageIndex(i => i < allImages.length - 1 ? i + 1 : 0)}
                      >
                        <ChevronRight className="w-5 h-5" />
                      </Button>
                    </>
                  )}
                </div>

                {/* Thumbnails */}
                {allImages.length > 1 && (
                  <div className="flex gap-2 p-4 overflow-x-auto">
                    {allImages.map((img, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={cn(
                          'flex-shrink-0 w-20 h-14 rounded-lg overflow-hidden border-2 transition-all',
                          currentImageIndex === index
                            ? 'border-primary'
                            : 'border-transparent opacity-60 hover:opacity-100'
                        )}
                      >
                        <img
                          src={img}
                          alt={`Thumbnail ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tabs Content */}
            <Tabs defaultValue="description" className="bg-card rounded-2xl border border-border">
              <TabsList className="w-full justify-start border-b border-border rounded-none bg-transparent p-0">
                <TabsTrigger 
                  value="description"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-4"
                >
                  Описание
                </TabsTrigger>
                <TabsTrigger 
                  value="versions"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-4"
                >
                  Версии
                </TabsTrigger>
                <TabsTrigger 
                  value="comments"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-4"
                >
                  Комментарии
                </TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="p-6">
                <div className="prose prose-invert max-w-none">
                  <div 
                    className="text-foreground"
                    dangerouslySetInnerHTML={{ 
                      __html: mod.description.replace(/\n/g, '<br>').replace(/# /g, '<h2>').replace(/## /g, '<h3>')
                    }} 
                  />
                </div>
              </TabsContent>

              <TabsContent value="versions" className="p-6">
                <div className="space-y-4">
                  {versions.length > 0 ? (
                    versions.map((version) => (
                      <div 
                        key={version.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-secondary/50 rounded-xl"
                      >
                        <div>
                          <div className="font-semibold text-foreground mb-1">
                            v{version.version}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {(version.minecraft_versions || []).slice(0, 3).map((v: string) => (
                              <Badge key={v} variant="category" size="sm">{v}</Badge>
                            ))}
                            {(version.minecraft_versions || []).length > 3 && (
                              <Badge variant="category" size="sm">
                                +{(version.minecraft_versions || []).length - 3}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-sm text-muted-foreground">
                            {formatTimeAgo(version.release_date)}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            {version.file_size || 'N/A'}
                          </span>
                          <Button size="sm" variant="glow">
                            <Download className="w-4 h-4 mr-1" />
                            Скачать
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">
                      Версии будут доступны позже
                    </p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="comments" className="p-6">
                <CommentSection modId={mod.id} />
              </TabsContent>
            </Tabs>

            {/* Ad Placeholder */}
            <div className="bg-secondary/50 rounded-2xl border border-border p-8 text-center">
              <p className="text-muted-foreground text-sm">Реклама</p>
            </div>

            {/* Similar Mods */}
            {similarMods && similarMods.length > 0 && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-4">
                  Похожие моды
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {similarMods.map((m) => (
                    <ModCard key={m.id} mod={m} />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Download Card */}
            <div className="bg-card rounded-2xl border border-border p-6 sticky top-24">
              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center p-3 bg-secondary/50 rounded-xl">
                  <Download className="w-5 h-5 text-primary mx-auto mb-1" />
                  <div className="font-bold text-foreground">{formatDownloads(mod.downloads || 0)}</div>
                  <div className="text-xs text-muted-foreground">Загрузок</div>
                </div>
                <div className="text-center p-3 bg-secondary/50 rounded-xl">
                  <Eye className="w-5 h-5 text-primary mx-auto mb-1" />
                  <div className="font-bold text-foreground">{formatDownloads(mod.views || 0)}</div>
                  <div className="text-xs text-muted-foreground">Просмотров</div>
                </div>
                <div className="text-center p-3 bg-secondary/50 rounded-xl">
                  <Star className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                  <div className="font-bold text-foreground">{Number(mod.rating || 0).toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">{formatDownloads(mod.rating_count || 0)} оценок</div>
                </div>
                <div className="text-center p-3 bg-secondary/50 rounded-xl">
                  <Clock className="w-5 h-5 text-primary mx-auto mb-1" />
                  <div className="font-bold text-foreground text-sm">{formatTimeAgo(mod.updated_at)}</div>
                  <div className="text-xs text-muted-foreground">Обновлено</div>
                </div>
              </div>

              {/* Download Button */}
              <Button variant="glow" size="xl" className="w-full mb-4">
                <Download className="w-5 h-5 mr-2" />
                Скачать мод
              </Button>

              {/* Secondary Actions */}
              <div className="flex gap-2">
                <Button
                  variant={isLiked ? 'default' : 'outline'}
                  className="flex-1"
                  onClick={() => setIsLiked(!isLiked)}
                >
                  <Heart className={cn('w-4 h-4 mr-2', isLiked && 'fill-current')} />
                  {isLiked ? 'В избранном' : 'В избранное'}
                </Button>
                <Button variant="outline" size="icon" onClick={handleCopyLink}>
                  {copied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                </Button>
                <Button variant="outline" size="icon">
                  <Flag className="w-4 h-4" />
                </Button>
              </div>

              {/* Divider */}
              <div className="border-t border-border my-6" />

              {/* Info */}
              <div className="space-y-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Создан</span>
                  <span className="text-foreground flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {new Date(mod.created_at).toLocaleDateString('ru-RU')}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Обновлён</span>
                  <span className="text-foreground">{formatTimeAgo(mod.updated_at)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Minecraft</span>
                  <span className="text-foreground">{minecraftVersions[0] || 'N/A'}</span>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-border my-6" />

              {/* Author */}
              {mod.author && (
                <Link 
                  to={`/author/${mod.author.id}`}
                  className="flex items-center gap-3 p-3 bg-secondary/50 rounded-xl hover:bg-secondary transition-colors"
                >
                  <img
                    src={mod.author.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${mod.author.username}`}
                    alt={mod.author.username}
                    className="w-10 h-10 rounded-full bg-secondary"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-foreground flex items-center gap-1">
                      {mod.author.username}
                      {mod.author.verified && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">Автор</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </Link>
              )}

              {/* Tags */}
              {tags.length > 0 && (
                <>
                  <div className="border-t border-border my-6" />
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag) => (
                      <Badge key={tag} variant="category" size="sm">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
