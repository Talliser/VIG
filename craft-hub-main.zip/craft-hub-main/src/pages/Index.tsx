import { Link } from 'react-router-dom';
import { ArrowRight, Download, Users, Package, Sparkles, Shield, Zap, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Layout } from '@/components/layout/Layout';
import { ModCard } from '@/components/mods/ModCard';
import { useFeaturedMods, usePopularMods, useRecentMods, useModsStats } from '@/hooks/useMods';
import { formatDownloads } from '@/lib/format';

const Index = () => {
  const { data: featuredMods, isLoading: loadingFeatured } = useFeaturedMods(6);
  const { data: popularMods, isLoading: loadingPopular } = usePopularMods(6);
  const { data: recentMods, isLoading: loadingRecent } = useRecentMods(6);
  const { data: stats, isLoading: loadingStats } = useModsStats();

  const isLoading = loadingFeatured || loadingPopular || loadingRecent;

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-hero-pattern">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-background" />
        <div className="container mx-auto px-4 py-16 md:py-24 lg:py-32 relative">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <Badge variant="outline" className="mb-6 px-4 py-1.5 text-sm border-primary/30 bg-primary/5">
              <Sparkles className="w-4 h-4 mr-2 text-primary" />
              Безопасная платформа для модов
            </Badge>

            {/* Title */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Откройте мир{' '}
              <span className="text-gradient">модификаций</span>
              <br />
              для Minecraft
            </h1>

            {/* Description */}
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Тысячи модов для Java и Bedrock Edition. Скачивайте безопасно, 
              делитесь своими творениями и станьте частью сообщества.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="xl" variant="glow" asChild>
                <Link to="/mods">
                  Смотреть моды
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button size="xl" variant="outline" asChild>
                <Link to="/mods?edition=java">
                  Java Edition
                </Link>
              </Button>
              <Button size="xl" variant="outline" asChild>
                <Link to="/mods?edition=bedrock">
                  Bedrock Edition
                </Link>
              </Button>
            </div>

            {/* Stats */}
            <div className="mt-16 grid grid-cols-3 gap-8 max-w-lg mx-auto">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-foreground">
                  {loadingStats ? '...' : formatDownloads(stats?.mods || 0)}+
                </div>
                <div className="text-sm text-muted-foreground mt-1">Модов</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-foreground">
                  {loadingStats ? '...' : formatDownloads(stats?.downloads || 0)}+
                </div>
                <div className="text-sm text-muted-foreground mt-1">Загрузок</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-foreground">
                  {loadingStats ? '...' : formatDownloads(stats?.authors || 0)}+
                </div>
                <div className="text-sm text-muted-foreground mt-1">Авторов</div>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-primary/10 rounded-2xl rotate-12 blur-xl" />
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-accent/10 rounded-full blur-2xl" />
      </section>

      {/* Features Section */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Безопасность</h3>
              <p className="text-muted-foreground text-sm">
                Все файлы проверяются на вирусы и вредоносный код перед публикацией
              </p>
            </div>
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Быстрая загрузка</h3>
              <p className="text-muted-foreground text-sm">
                Высокоскоростные серверы для мгновенного скачивания ваших любимых модов
              </p>
            </div>
            <div className="bg-card rounded-2xl p-6 border border-border">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-purple-500" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Сообщество</h3>
              <p className="text-muted-foreground text-sm">
                Комментарии, оценки и обсуждения для каждого мода
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Loading State */}
      {isLoading ? (
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
            <p className="text-muted-foreground mt-4">Загрузка модов...</p>
          </div>
        </section>
      ) : (
        <>
          {/* Featured Mods */}
          {featuredMods && featuredMods.length > 0 && (
            <section className="py-16">
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                      ⭐ Рекомендуемые моды
                    </h2>
                    <p className="text-muted-foreground mt-1">Лучшие моды, выбранные редакцией</p>
                  </div>
                  <Button variant="ghost" asChild>
                    <Link to="/mods?featured=true">
                      Все рекомендуемые
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {featuredMods.map((mod, index) => (
                    <ModCard 
                      key={mod.id} 
                      mod={mod} 
                      className={`animate-fade-in stagger-${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Popular Mods */}
          {popularMods && popularMods.length > 0 && (
            <section className="py-16 bg-secondary/30">
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                      🔥 Популярные моды
                    </h2>
                    <p className="text-muted-foreground mt-1">Самые скачиваемые за всё время</p>
                  </div>
                  <Button variant="ghost" asChild>
                    <Link to="/mods?sort=downloads">
                      Все популярные
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {popularMods.map((mod, index) => (
                    <ModCard 
                      key={mod.id} 
                      mod={mod} 
                      className={`animate-fade-in stagger-${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Recent Updates */}
          {recentMods && recentMods.length > 0 && (
            <section className="py-16">
              <div className="container mx-auto px-4">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                      🆕 Недавно обновлённые
                    </h2>
                    <p className="text-muted-foreground mt-1">Свежие обновления от авторов</p>
                  </div>
                  <Button variant="ghost" asChild>
                    <Link to="/mods?sort=updated">
                      Все обновлённые
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recentMods.map((mod, index) => (
                    <ModCard 
                      key={mod.id} 
                      mod={mod} 
                      className={`animate-fade-in stagger-${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Empty State */}
          {(!featuredMods?.length && !popularMods?.length && !recentMods?.length) && (
            <section className="py-16">
              <div className="container mx-auto px-4 text-center">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-foreground mb-2">Моды ещё не добавлены</h2>
                <p className="text-muted-foreground mb-6">Будьте первым, кто загрузит мод!</p>
                <Button size="lg" variant="glow">
                  <Package className="w-5 h-5 mr-2" />
                  Загрузить мод
                </Button>
              </div>
            </section>
          )}
        </>
      )}

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Создаёте моды? Присоединяйтесь к нам!
            </h2>
            <p className="text-muted-foreground mb-8">
              Загружайте свои моды, получайте отзывы от сообщества и делитесь своими творениями с миллионами игроков.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" variant="glow">
                <Package className="w-5 h-5 mr-2" />
                Загрузить мод
              </Button>
              <Button size="lg" variant="outline">
                Узнать больше
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
