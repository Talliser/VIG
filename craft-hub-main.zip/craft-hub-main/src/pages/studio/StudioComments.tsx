import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { StudioLayout } from '@/components/studio/StudioLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDate } from '@/lib/format';
import { Link } from 'react-router-dom';
import { MessageSquare, Star, ExternalLink } from 'lucide-react';

export default function StudioComments() {
  const { profile } = useAuth();

  const { data: comments, isLoading } = useQuery({
    queryKey: ['author-comments', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return [];

      // First get author's mods
      const { data: mods } = await supabase
        .from('mods')
        .select('id, name, slug')
        .eq('author_id', profile.id);

      if (!mods || mods.length === 0) return [];

      const modIds = mods.map(m => m.id);
      const modMap = Object.fromEntries(mods.map(m => [m.id, m]));

      // Get comments on those mods
      const { data: commentsData } = await supabase
        .from('comments')
        .select(`
          *,
          user:profiles!comments_user_id_fkey(username, display_name, avatar)
        `)
        .in('mod_id', modIds)
        .order('created_at', { ascending: false })
        .limit(50);

      return (commentsData || []).map(comment => ({
        ...comment,
        mod: modMap[comment.mod_id],
      }));
    },
    enabled: !!profile?.id,
  });

  return (
    <StudioLayout>
      <div className="p-4 lg:p-8 pb-24 lg:pb-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Комментарии</h1>
          <p className="text-muted-foreground">
            Комментарии к вашим модам
          </p>
        </div>

        {/* Comments List */}
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))}
          </div>
        ) : !comments || comments.length === 0 ? (
          <Card className="border-border/50">
            <CardContent className="py-16 text-center">
              <MessageSquare className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Комментариев пока нет</h3>
              <p className="text-muted-foreground">
                Когда пользователи оставят комментарии к вашим модам, они появятся здесь
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {comments.map((comment: any) => (
              <Card key={comment.id} className="border-border/50">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Avatar className="h-10 w-10 flex-shrink-0">
                      <AvatarImage src={comment.user?.avatar || undefined} />
                      <AvatarFallback>
                        {comment.user?.username?.charAt(0).toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-medium">
                          {comment.user?.display_name || comment.user?.username || 'Пользователь'}
                        </span>
                        {comment.rating && (
                          <div className="flex items-center gap-0.5">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < comment.rating
                                    ? 'fill-yellow-500 text-yellow-500'
                                    : 'text-muted-foreground'
                                }`}
                              />
                            ))}
                          </div>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {formatDate(comment.created_at)}
                        </span>
                      </div>

                      <p className="text-sm text-foreground mb-2">{comment.content}</p>

                      <Link
                        to={`/mod/${comment.mod?.slug}`}
                        className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                      >
                        <ExternalLink className="w-3 h-3" />
                        {comment.mod?.name}
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </StudioLayout>
  );
}
