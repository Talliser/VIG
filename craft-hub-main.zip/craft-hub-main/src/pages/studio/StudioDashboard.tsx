import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { StudioLayout } from '@/components/studio/StudioLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { formatNumber } from '@/lib/format';
import {
  Package,
  Download,
  Eye,
  MessageSquare,
  Star,
  TrendingUp,
  PlusCircle,
} from 'lucide-react';

export default function StudioDashboard() {
  const { profile } = useAuth();

  const { data: stats, isLoading } = useQuery({
    queryKey: ['author-stats', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return null;

      // Get mods by this author
      const { data: mods } = await supabase
        .from('mods')
        .select('id, downloads, views, rating, rating_count')
        .eq('author_id', profile.id);

      if (!mods) return null;

      const totalMods = mods.length;
      const totalDownloads = mods.reduce((sum, mod) => sum + (mod.downloads || 0), 0);
      const totalViews = mods.reduce((sum, mod) => sum + (mod.views || 0), 0);
      
      const ratedMods = mods.filter(m => m.rating_count && m.rating_count > 0);
      const averageRating = ratedMods.length > 0
        ? ratedMods.reduce((sum, m) => sum + (m.rating || 0), 0) / ratedMods.length
        : 0;

      // Get comments on author's mods
      const modIds = mods.map(m => m.id);
      const { count: commentsCount } = await supabase
        .from('comments')
        .select('*', { count: 'exact', head: true })
        .in('mod_id', modIds);

      return {
        totalMods,
        totalDownloads,
        totalViews,
        averageRating,
        totalComments: commentsCount || 0,
      };
    },
    enabled: !!profile?.id,
  });

  const { data: recentMods } = useQuery({
    queryKey: ['author-recent-mods', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return [];

      const { data } = await supabase
        .from('mods')
        .select('id, slug, name, icon, downloads, views, status, updated_at')
        .eq('author_id', profile.id)
        .order('updated_at', { ascending: false })
        .limit(5);

      return data || [];
    },
    enabled: !!profile?.id,
  });

  const statCards = [
    {
      label: 'Всего модов',
      value: stats?.totalMods || 0,
      icon: Package,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      label: 'Загрузок',
      value: formatNumber(stats?.totalDownloads || 0),
      icon: Download,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      label: 'Просмотров',
      value: formatNumber(stats?.totalViews || 0),
      icon: Eye,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
    {
      label: 'Комментариев',
      value: stats?.totalComments || 0,
      icon: MessageSquare,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10',
    },
    {
      label: 'Средний рейтинг',
      value: stats?.averageRating?.toFixed(1) || '0.0',
      icon: Star,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
    },
  ];

  return (
    <StudioLayout>
      <div className="p-4 lg:p-8 pb-24 lg:pb-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">
              Привет, {profile?.display_name || profile?.username}! 👋
            </h1>
            <p className="text-muted-foreground mt-1">
              Вот статистика ваших модов
            </p>
          </div>
          <Button asChild className="gap-2">
            <Link to="/studio/upload">
              <PlusCircle className="w-4 h-4" />
              Загрузить мод
            </Link>
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {statCards.map((stat) => (
            <Card key={stat.label} className="border-border/50">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${stat.bgColor}`}>
                    <stat.icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                  <div>
                    {isLoading ? (
                      <Skeleton className="h-6 w-16" />
                    ) : (
                      <p className="text-xl lg:text-2xl font-bold">{stat.value}</p>
                    )}
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Mods */}
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Последние моды</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/studio/mods">Все моды</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {!recentMods || recentMods.length === 0 ? (
              <div className="text-center py-12">
                <Package className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="font-semibold mb-2">Моды ещё не добавлены</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Будьте первым, кто загрузит мод!
                </p>
                <Button asChild>
                  <Link to="/studio/upload">Загрузить мод</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentMods.map((mod) => (
                  <Link
                    key={mod.id}
                    to={`/studio/mods/${mod.id}`}
                    className="flex items-center gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors"
                  >
                    <div className="w-12 h-12 rounded-xl bg-secondary overflow-hidden flex-shrink-0">
                      {mod.icon ? (
                        <img src={mod.icon} alt={mod.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-6 h-6 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{mod.name}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          {formatNumber(mod.downloads)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {formatNumber(mod.views)}
                        </span>
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      mod.status === 'published' 
                        ? 'bg-primary/10 text-primary' 
                        : mod.status === 'pending'
                        ? 'bg-yellow-500/10 text-yellow-500'
                        : mod.status === 'rejected'
                        ? 'bg-destructive/10 text-destructive'
                        : 'bg-secondary text-muted-foreground'
                    }`}>
                      {mod.status === 'published' ? 'Опубликован' :
                       mod.status === 'pending' ? 'На модерации' :
                       mod.status === 'rejected' ? 'Отклонён' : 'Черновик'}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </StudioLayout>
  );
}
