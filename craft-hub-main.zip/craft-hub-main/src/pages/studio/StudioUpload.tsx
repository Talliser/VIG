import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { StudioLayout } from '@/components/studio/StudioLayout';
import { FileUpload } from '@/components/studio/FileUpload';
import { useFileUpload } from '@/hooks/useFileUpload';
import { useProjectTypes } from '@/hooks/useProjectTypes';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { CATEGORIES, LOADERS, MINECRAFT_VERSIONS } from '@/lib/constants';
import { z } from 'zod';
import {
  ChevronLeft,
  ChevronRight,
  FileText,
  Settings,
  Image,
  Check,
  Loader2,
  Upload,
  AlertCircle,
  File,
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const modSchema = z.object({
  name: z.string().min(3, 'Название должно быть не менее 3 символов').max(100),
  summary: z.string().min(10, 'Краткое описание должно быть не менее 10 символов').max(300),
  description: z.string().min(50, 'Описание должно быть не менее 50 символов'),
  edition: z.enum(['java', 'bedrock']),
  categories: z.array(z.string()).min(1, 'Выберите хотя бы одну категорию'),
  loaders: z.array(z.string()).min(1, 'Выберите хотя бы один загрузчик'),
  minecraftVersions: z.array(z.string()).min(1, 'Выберите хотя бы одну версию'),
});

type Step = 'info' | 'compatibility' | 'media' | 'files' | 'publish';

const steps: { id: Step; label: string; icon: typeof FileText }[] = [
  { id: 'info', label: 'Основное', icon: FileText },
  { id: 'compatibility', label: 'Совместимость', icon: Settings },
  { id: 'media', label: 'Медиа', icon: Image },
  { id: 'files', label: 'Файлы', icon: Upload },
  { id: 'publish', label: 'Публикация', icon: Check },
];

// Generate URL-safe slug from name
function generateSlug(name: string): string {
  const translitMap: Record<string, string> = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
    'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
    'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '',
    'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya',
  };

  return name
    .toLowerCase()
    .split('')
    .map(char => translitMap[char] || char)
    .join('')
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
    .substring(0, 50);
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function StudioUpload() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { uploadFile, isUploading } = useFileUpload();
  const { data: projectTypes } = useProjectTypes();
  
  const [currentStep, setCurrentStep] = useState<Step>('info');
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Form state
  const [name, setName] = useState('');
  const [projectType, setProjectType] = useState('mods');
  const [summary, setSummary] = useState('');
  const [description, setDescription] = useState('');
  const [edition, setEdition] = useState<'java' | 'bedrock'>('java');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedLoaders, setSelectedLoaders] = useState<string[]>([]);
  const [selectedVersions, setSelectedVersions] = useState<string[]>([]);
  const [iconUrl, setIconUrl] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [tags, setTags] = useState('');
  const [publishAsDraft, setPublishAsDraft] = useState(false);
  
  // File upload state
  const [modFile, setModFile] = useState<File | null>(null);
  const [modFileUrl, setModFileUrl] = useState('');
  const [modFileSize, setModFileSize] = useState('');
  const [modVersion, setModVersion] = useState('1.0.0');
  const [changelog, setChangelog] = useState('');

  const currentStepIndex = steps.findIndex(s => s.id === currentStep);

  const handleIconUpload = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    
    const url = await uploadFile(file, 'mod-icons');
    if (url) {
      setIconUrl(url);
      toast.success('Иконка загружена');
    } else {
      toast.error('Ошибка загрузки иконки');
    }
  };

  const handleBannerUpload = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    
    const url = await uploadFile(file, 'mod-banners');
    if (url) {
      setBannerUrl(url);
      toast.success('Баннер загружен');
    } else {
      toast.error('Ошибка загрузки баннера');
    }
  };

  const handleModFileUpload = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    
    // Validate file type
    const allowedTypes = ['.jar', '.zip', '.mcpack', '.mcworld', '.mcaddon'];
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!allowedTypes.includes(ext)) {
      toast.error(`Неверный тип файла. Разрешены: ${allowedTypes.join(', ')}`);
      return;
    }
    
    setModFile(file);
    setModFileSize(formatFileSize(file.size));
    
    const url = await uploadFile(file, 'mod-files');
    if (url) {
      setModFileUrl(url);
      toast.success('Файл мода загружен');
    } else {
      toast.error('Ошибка загрузки файла');
      setModFile(null);
      setModFileSize('');
    }
  };

  const createMutation = useMutation({
    mutationFn: async () => {
      // Check auth session first
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) throw new Error('Сессия истекла. Пожалуйста, войдите снова.');
      if (!profile?.id) throw new Error('Профиль не загружен. Попробуйте обновить страницу.');

      // Validate that file is uploaded if not draft
      if (!publishAsDraft && !modFileUrl) {
        throw new Error('Загрузите файл мода для отправки на модерацию');
      }

      // Auto-generate slug with unique ID suffix
      const baseSlug = generateSlug(name);
      const uniqueId = uuidv4().split('-')[0];
      const slug = `${baseSlug}-${uniqueId}`;

      // Determine status based on action
      // draft = черновик (не публикуется)
      // pending = ожидает модерации
      // published = одобрено модератором
      // rejected = отклонено
      const status = publishAsDraft ? 'draft' : 'pending';

      const modData = {
        name,
        slug,
        summary,
        description,
        project_type: projectType,
        edition: edition as 'java' | 'bedrock',
        categories: selectedCategories as ('adventure' | 'decoration' | 'economy' | 'equipment' | 'food' | 'library' | 'magic' | 'management' | 'minigame' | 'mobs' | 'optimization' | 'social' | 'storage' | 'technology' | 'transportation' | 'utility' | 'worldgen')[],
        loaders: selectedLoaders as ('fabric' | 'forge' | 'neoforge' | 'quilt' | 'liteloader' | 'rift' | 'modloader')[],
        minecraft_versions: selectedVersions,
        icon: iconUrl || null,
        banner: bannerUrl || null,
        tags: tags.split(',').map(t => t.trim()).filter(Boolean),
        author_id: profile.id,
        status,
        primary_file_url: modFileUrl || null,
        primary_file_size: modFileSize || null,
      };

      // Validate
      const result = modSchema.safeParse({
        ...modData,
        minecraftVersions: selectedVersions,
      });

      if (!result.success) {
        const fieldErrors: Record<string, string> = {};
        result.error.errors.forEach(err => {
          const path = err.path[0] as string;
          fieldErrors[path] = err.message;
        });
        setErrors(fieldErrors);
        throw new Error('Проверьте заполнение формы');
      }

      const { data, error } = await supabase
        .from('mods')
        .insert(modData)
        .select()
        .single();

      if (error) throw error;

      // Create initial version if file was uploaded
      if (modFileUrl && data) {
        await supabase.from('mod_versions').insert({
          mod_id: data.id,
          version: modVersion,
          file_url: modFileUrl,
          file_size: modFileSize,
          changelog: changelog || null,
          loaders: selectedLoaders as ('fabric' | 'forge' | 'neoforge' | 'quilt' | 'liteloader' | 'rift' | 'modloader')[],
          minecraft_versions: selectedVersions,
        });
      }

      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['author-mods'] });
      if (publishAsDraft) {
        toast.success('Мод сохранён как черновик');
      } else {
        toast.success('Мод отправлен на модерацию! Ожидайте проверки.');
      }
      navigate('/studio/mods');
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const validateStep = (step: Step): boolean => {
    const newErrors: Record<string, string> = {};

    if (step === 'info') {
      if (!name || name.length < 3) newErrors.name = 'Название должно быть не менее 3 символов';
      if (!summary || summary.length < 10) newErrors.summary = 'Минимум 10 символов';
      if (!description || description.length < 50) newErrors.description = 'Минимум 50 символов';
    }

    if (step === 'compatibility') {
      if (selectedCategories.length === 0) newErrors.categories = 'Выберите хотя бы одну категорию';
      if (selectedLoaders.length === 0) newErrors.loaders = 'Выберите хотя бы один загрузчик';
      if (selectedVersions.length === 0) newErrors.versions = 'Выберите хотя бы одну версию';
    }

    if (step === 'files' && !publishAsDraft) {
      if (!modFileUrl) newErrors.file = 'Загрузите файл мода';
      if (!modVersion) newErrors.version = 'Укажите версию мода';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const goToNext = () => {
    if (validateStep(currentStep)) {
      const nextIndex = currentStepIndex + 1;
      if (nextIndex < steps.length) {
        setCurrentStep(steps[nextIndex].id);
      }
    }
  };

  const goToPrev = () => {
    const prevIndex = currentStepIndex - 1;
    if (prevIndex >= 0) {
      setCurrentStep(steps[prevIndex].id);
    }
  };

  const handleSubmit = () => {
    createMutation.mutate();
  };

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev =>
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const toggleLoader = (loader: string) => {
    setSelectedLoaders(prev =>
      prev.includes(loader) ? prev.filter(l => l !== loader) : [...prev, loader]
    );
  };

  const toggleVersion = (version: string) => {
    setSelectedVersions(prev =>
      prev.includes(version) ? prev.filter(v => v !== version) : [...prev, version]
    );
  };

  return (
    <StudioLayout>
      <div className="p-4 lg:p-8 pb-24 lg:pb-8 max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold">Загрузить контент</h1>
          <p className="text-muted-foreground">
            Заполните информацию о вашем проекте
          </p>
        </div>

        {/* Steps */}
        <div className="flex items-center justify-between mb-8 overflow-x-auto">
          {steps.map((step, index) => (
            <div
              key={step.id}
              className={`flex items-center ${index < steps.length - 1 ? 'flex-1' : ''}`}
            >
              <button
                onClick={() => index <= currentStepIndex && setCurrentStep(step.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-colors ${
                  step.id === currentStep
                    ? 'bg-primary text-primary-foreground'
                    : index < currentStepIndex
                    ? 'bg-primary/20 text-primary'
                    : 'bg-secondary text-muted-foreground'
                }`}
              >
                <step.icon className="w-4 h-4" />
                <span className="hidden sm:inline text-sm font-medium">{step.label}</span>
              </button>
              {index < steps.length - 1 && (
                <div className={`flex-1 h-0.5 mx-2 ${
                  index < currentStepIndex ? 'bg-primary' : 'bg-border'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Form */}
        <Card className="border-border/50">
          <CardContent className="p-6">
            {/* Step 1: Basic Info */}
            {currentStep === 'info' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label>Тип контента *</Label>
                  <Select value={projectType} onValueChange={setProjectType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {projectTypes?.map((type) => (
                        <SelectItem key={type.id} value={type.slug}>
                          {type.icon} {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="name">Название *</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Мой крутой мод"
                    className={errors.name ? 'border-destructive' : ''}
                  />
                  {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
                  {name && (
                    <p className="text-xs text-muted-foreground">
                      URL: minemods.com/mod/{generateSlug(name)}-xxx
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary">Краткое описание *</Label>
                  <Textarea
                    id="summary"
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    placeholder="Опишите мод в нескольких предложениях..."
                    rows={2}
                    className={errors.summary ? 'border-destructive' : ''}
                  />
                  <p className="text-xs text-muted-foreground">{summary.length}/300</p>
                  {errors.summary && <p className="text-xs text-destructive">{errors.summary}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Полное описание * (Markdown)</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Подробное описание вашего мода. Поддерживается Markdown..."
                    rows={10}
                    className={errors.description ? 'border-destructive' : ''}
                  />
                  {errors.description && <p className="text-xs text-destructive">{errors.description}</p>}
                </div>

                <div className="space-y-2">
                  <Label>Издание *</Label>
                  <Select value={edition} onValueChange={(v: 'java' | 'bedrock') => setEdition(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="java">Java Edition</SelectItem>
                      <SelectItem value="bedrock">Bedrock Edition</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Step 2: Compatibility */}
            {currentStep === 'compatibility' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label>Категории *</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => toggleCategory(cat.id)}
                        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                          selectedCategories.includes(cat.id)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-secondary hover:bg-secondary/80 text-foreground'
                        }`}
                      >
                        <span>{cat.icon}</span>
                        {cat.name}
                      </button>
                    ))}
                  </div>
                  {errors.categories && <p className="text-xs text-destructive">{errors.categories}</p>}
                </div>

                <div className="space-y-2">
                  <Label>Загрузчики *</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {LOADERS.filter(l => 
                      edition === 'java' 
                        ? ['fabric', 'forge', 'neoforge', 'quilt'].includes(l.id)
                        : ['liteloader', 'rift', 'modloader'].includes(l.id)
                    ).map((loader) => (
                      <button
                        key={loader.id}
                        type="button"
                        onClick={() => toggleLoader(loader.id)}
                        className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                          selectedLoaders.includes(loader.id)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-secondary hover:bg-secondary/80 text-foreground'
                        }`}
                      >
                        {loader.name}
                      </button>
                    ))}
                  </div>
                  {errors.loaders && <p className="text-xs text-destructive">{errors.loaders}</p>}
                </div>

                <div className="space-y-2">
                  <Label>Версии Minecraft *</Label>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 max-h-48 overflow-y-auto p-1">
                    {MINECRAFT_VERSIONS.map((version) => (
                      <button
                        key={version}
                        type="button"
                        onClick={() => toggleVersion(version)}
                        className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                          selectedVersions.includes(version)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-secondary hover:bg-secondary/80 text-foreground'
                        }`}
                      >
                        {version}
                      </button>
                    ))}
                  </div>
                  {errors.versions && <p className="text-xs text-destructive">{errors.versions}</p>}
                </div>
              </div>
            )}

            {/* Step 3: Media */}
            {currentStep === 'media' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label>Иконка</Label>
                  <FileUpload
                    onUpload={handleIconUpload}
                    accept="image/*"
                    maxSize={2}
                    preview={iconUrl}
                    onRemove={() => setIconUrl('')}
                    isUploading={isUploading}
                    className="w-32 h-32"
                    label="Загрузить иконку"
                    hint="512x512, до 2MB"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Баннер</Label>
                  <FileUpload
                    onUpload={handleBannerUpload}
                    accept="image/*"
                    maxSize={5}
                    preview={bannerUrl}
                    onRemove={() => setBannerUrl('')}
                    isUploading={isUploading}
                    className="w-full h-48"
                    label="Загрузить баннер"
                    hint="1920x1080, до 5MB"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Теги</Label>
                  <Input
                    id="tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="технологии, машины, автоматизация"
                  />
                  <p className="text-xs text-muted-foreground">
                    Введите теги через запятую
                  </p>
                </div>
              </div>
            )}

            {/* Step 4: Files */}
            {currentStep === 'files' && (
              <div className="space-y-6">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Загрузите файл вашего мода. Разрешённые форматы: .jar, .zip, .mcpack, .mcworld, .mcaddon
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label>Файл мода *</Label>
                  {modFile ? (
                    <div className="flex items-center gap-4 p-4 bg-secondary/50 rounded-xl">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <File className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{modFile.name}</p>
                        <p className="text-sm text-muted-foreground">{modFileSize}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setModFile(null);
                          setModFileUrl('');
                          setModFileSize('');
                        }}
                      >
                        Удалить
                      </Button>
                    </div>
                  ) : (
                    <FileUpload
                      onUpload={handleModFileUpload}
                      accept=".jar,.zip,.mcpack,.mcworld,.mcaddon"
                      maxSize={50}
                      isUploading={isUploading}
                      className="w-full h-32"
                      label="Загрузить файл мода"
                      hint="До 50MB"
                    />
                  )}
                  {errors.file && <p className="text-xs text-destructive">{errors.file}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="version">Версия мода *</Label>
                  <Input
                    id="version"
                    value={modVersion}
                    onChange={(e) => setModVersion(e.target.value)}
                    placeholder="1.0.0"
                    className={errors.version ? 'border-destructive' : ''}
                  />
                  {errors.version && <p className="text-xs text-destructive">{errors.version}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="changelog">Список изменений</Label>
                  <Textarea
                    id="changelog"
                    value={changelog}
                    onChange={(e) => setChangelog(e.target.value)}
                    placeholder="Опишите изменения в этой версии..."
                    rows={4}
                  />
                </div>
              </div>
            )}

            {/* Step 5: Publish */}
            {currentStep === 'publish' && (
              <div className="space-y-6">
                <div className="bg-secondary/50 rounded-xl p-6">
                  <h3 className="font-semibold text-lg mb-4">Предпросмотр</h3>
                  
                  <div className="flex gap-4">
                    {iconUrl ? (
                      <img src={iconUrl} alt="Icon" className="w-20 h-20 rounded-xl object-cover" />
                    ) : (
                      <div className="w-20 h-20 rounded-xl bg-secondary flex items-center justify-center">
                        <Image className="w-8 h-8 text-muted-foreground" />
                      </div>
                    )}
                    
                    <div>
                      <h4 className="font-bold text-lg">{name || 'Название мода'}</h4>
                      <p className="text-sm text-muted-foreground mb-2">{summary || 'Краткое описание'}</p>
                      <div className="flex gap-2 flex-wrap">
                        {selectedCategories.slice(0, 3).map(cat => (
                          <span key={cat} className="px-2 py-1 bg-secondary rounded text-xs">
                            {CATEGORIES.find(c => c.id === cat)?.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {modFile && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-sm">
                        <span className="text-muted-foreground">Файл:</span> {modFile.name} ({modFileSize})
                      </p>
                      <p className="text-sm">
                        <span className="text-muted-foreground">Версия:</span> {modVersion}
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="draft"
                    checked={publishAsDraft}
                    onCheckedChange={(checked) => setPublishAsDraft(checked as boolean)}
                  />
                  <Label htmlFor="draft" className="cursor-pointer">
                    Сохранить как черновик (не отправлять на модерацию)
                  </Label>
                </div>

                {!publishAsDraft && !modFileUrl && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Для отправки на модерацию необходимо загрузить файл мода
                    </AlertDescription>
                  </Alert>
                )}

                <div className="bg-primary/10 rounded-xl p-4">
                  <p className="text-sm text-foreground">
                    <strong>Важно:</strong> {publishAsDraft 
                      ? 'Черновик будет сохранён и доступен только вам. Вы сможете отправить его на модерацию позже.' 
                      : 'После отправки ваш контент будет проверен модераторами. Это может занять до 24 часов. Вы получите уведомление о результате проверки.'}
                  </p>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between mt-8 pt-6 border-t border-border">
              <Button
                variant="outline"
                onClick={goToPrev}
                disabled={currentStepIndex === 0}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Назад
              </Button>

              {currentStep === 'publish' ? (
                <Button
                  variant="glow"
                  onClick={handleSubmit}
                  disabled={createMutation.isPending || (!publishAsDraft && !modFileUrl)}
                >
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Отправка...
                    </>
                  ) : publishAsDraft ? (
                    'Сохранить черновик'
                  ) : (
                    'Отправить на модерацию'
                  )}
                </Button>
              ) : (
                <Button onClick={goToNext}>
                  Далее
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudioLayout>
  );
}