import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { StudioLayout } from '@/components/studio/StudioLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { formatNumber } from '@/lib/format';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from 'recharts';
import { Download, Eye, TrendingUp, Calendar } from 'lucide-react';

type Period = '7d' | '28d' | '90d';
type Metric = 'downloads' | 'views';

export default function StudioAnalytics() {
  const { profile } = useAuth();
  const [period, setPeriod] = useState<Period>('28d');
  const [metric, setMetric] = useState<Metric>('downloads');

  const { data: stats, isLoading } = useQuery({
    queryKey: ['author-analytics', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return null;

      const { data: mods } = await supabase
        .from('mods')
        .select('id, name, downloads, views, rating')
        .eq('author_id', profile.id)
        .order('downloads', { ascending: false });

      if (!mods) return null;

      const totalDownloads = mods.reduce((sum, m) => sum + (m.downloads || 0), 0);
      const totalViews = mods.reduce((sum, m) => sum + (m.views || 0), 0);

      // Mock trend data (in real app, would come from analytics table)
      const days = period === '7d' ? 7 : period === '28d' ? 28 : 90;
      const trendData = Array.from({ length: days }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (days - 1 - i));
        return {
          date: date.toLocaleDateString('ru', { day: 'numeric', month: 'short' }),
          downloads: Math.floor(Math.random() * (totalDownloads / days) * 2),
          views: Math.floor(Math.random() * (totalViews / days) * 2),
        };
      });

      return {
        mods,
        totalDownloads,
        totalViews,
        trendData,
      };
    },
    enabled: !!profile?.id,
  });

  return (
    <StudioLayout>
      <div className="p-4 lg:p-8 pb-24 lg:pb-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Аналитика</h1>
            <p className="text-muted-foreground">
              Статистика ваших модов
            </p>
          </div>
          <div className="flex items-center gap-2">
            {(['7d', '28d', '90d'] as Period[]).map((p) => (
              <Button
                key={p}
                variant={period === p ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPeriod(p)}
              >
                {p === '7d' ? '7 дней' : p === '28d' ? '28 дней' : '90 дней'}
              </Button>
            ))}
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-blue-500/10">
                  <Download className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  {isLoading ? (
                    <Skeleton className="h-8 w-20" />
                  ) : (
                    <p className="text-2xl font-bold">
                      {formatNumber(stats?.totalDownloads || 0)}
                    </p>
                  )}
                  <p className="text-sm text-muted-foreground">Всего загрузок</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-purple-500/10">
                  <Eye className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  {isLoading ? (
                    <Skeleton className="h-8 w-20" />
                  ) : (
                    <p className="text-2xl font-bold">
                      {formatNumber(stats?.totalViews || 0)}
                    </p>
                  )}
                  <p className="text-sm text-muted-foreground">Всего просмотров</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-primary/10">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  {isLoading ? (
                    <Skeleton className="h-8 w-20" />
                  ) : (
                    <p className="text-2xl font-bold">
                      {stats?.mods?.length || 0}
                    </p>
                  )}
                  <p className="text-sm text-muted-foreground">Модов</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-orange-500/10">
                  <Calendar className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">
                    {period === '7d' ? '7' : period === '28d' ? '28' : '90'}
                  </p>
                  <p className="text-sm text-muted-foreground">Дней</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        <Card className="border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Динамика за период</CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant={metric === 'downloads' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setMetric('downloads')}
                >
                  Загрузки
                </Button>
                <Button
                  variant={metric === 'views' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setMetric('views')}
                >
                  Просмотры
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px]" />
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats?.trendData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis
                      dataKey="date"
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey={metric}
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Mods */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle>Топ модов по загрузкам</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12" />
                ))}
              </div>
            ) : !stats?.mods || stats.mods.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Нет данных для отображения
              </p>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats.mods.slice(0, 10)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis
                      type="category"
                      dataKey="name"
                      width={150}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="downloads" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </StudioLayout>
  );
}
