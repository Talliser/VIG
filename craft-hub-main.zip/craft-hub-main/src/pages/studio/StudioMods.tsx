import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { StudioLayout } from '@/components/studio/StudioLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Link } from 'react-router-dom';
import { formatNumber, formatDate } from '@/lib/format';
import { toast } from 'sonner';
import {
  Package,
  Download,
  Eye,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  ExternalLink,
  PlusCircle,
  Upload,
  Send,
  Clock,
  CheckCircle,
  XCircle,
  FileEdit,
} from 'lucide-react';

export default function StudioMods() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [deleteModId, setDeleteModId] = useState<string | null>(null);

  const { data: mods, isLoading } = useQuery({
    queryKey: ['author-mods', profile?.id, search],
    queryFn: async () => {
      if (!profile?.id) return [];

      let query = supabase
        .from('mods')
        .select('*')
        .eq('author_id', profile.id)
        .order('updated_at', { ascending: false });

      if (search) {
        query = query.ilike('name', `%${search}%`);
      }

      const { data } = await query;
      return data || [];
    },
    enabled: !!profile?.id,
  });

  const deleteMutation = useMutation({
    mutationFn: async (modId: string) => {
      const { error } = await supabase
        .from('mods')
        .delete()
        .eq('id', modId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['author-mods'] });
      toast.success('Мод удалён');
      setDeleteModId(null);
    },
    onError: (error) => {
      toast.error('Ошибка при удалении мода');
      console.error(error);
    },
  });

  const submitForModerationMutation = useMutation({
    mutationFn: async (modId: string) => {
      // Check if mod has a file
      const mod = mods?.find(m => m.id === modId);
      if (!mod?.primary_file_url) {
        throw new Error('Загрузите файл мода перед отправкой на модерацию');
      }

      const { error } = await supabase
        .from('mods')
        .update({ status: 'pending' })
        .eq('id', modId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['author-mods'] });
      toast.success('Мод отправлен на модерацию');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Ошибка при отправке на модерацию');
    },
  });

  const handleDelete = () => {
    if (deleteModId) {
      deleteMutation.mutate(deleteModId);
    }
  };

  return (
    <StudioLayout>
      <div className="p-4 lg:p-8 pb-24 lg:pb-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">Мои моды</h1>
            <p className="text-muted-foreground">
              {mods?.length || 0} модов
            </p>
          </div>
          <Button asChild className="gap-2">
            <Link to="/studio/upload">
              <PlusCircle className="w-4 h-4" />
              Загрузить мод
            </Link>
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Поиск модов..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Mods List */}
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-xl" />
            ))}
          </div>
        ) : !mods || mods.length === 0 ? (
          <Card className="border-border/50">
            <CardContent className="py-16 text-center">
              <Package className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {search ? 'Моды не найдены' : 'У вас пока нет модов'}
              </h3>
              <p className="text-muted-foreground mb-6">
                {search 
                  ? 'Попробуйте изменить поисковый запрос'
                  : 'Загрузите свой первый мод и поделитесь им с сообществом'
                }
              </p>
              {!search && (
                <Button asChild>
                  <Link to="/studio/upload">
                    <Upload className="w-4 h-4 mr-2" />
                    Загрузить мод
                  </Link>
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {mods.map((mod) => (
              <Card key={mod.id} className="border-border/50 hover:border-border transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Icon */}
                    <div className="w-16 h-16 rounded-xl bg-secondary overflow-hidden flex-shrink-0">
                      {mod.icon ? (
                        <img src={mod.icon} alt={mod.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-8 h-8 text-muted-foreground" />
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate">{mod.name}</h3>
                        <span className={`px-2 py-0.5 rounded-md text-xs font-medium flex items-center gap-1 ${
                          mod.status === 'published' 
                            ? 'bg-primary/10 text-primary' 
                            : mod.status === 'pending'
                            ? 'bg-yellow-500/10 text-yellow-500'
                            : mod.status === 'rejected'
                            ? 'bg-destructive/10 text-destructive'
                            : 'bg-secondary text-muted-foreground'
                        }`}>
                          {mod.status === 'published' && <CheckCircle className="w-3 h-3" />}
                          {mod.status === 'pending' && <Clock className="w-3 h-3" />}
                          {mod.status === 'rejected' && <XCircle className="w-3 h-3" />}
                          {mod.status === 'draft' && <FileEdit className="w-3 h-3" />}
                          {mod.status === 'published' ? 'Опубликован' :
                           mod.status === 'pending' ? 'На модерации' :
                           mod.status === 'rejected' ? 'Отклонён' : 'Черновик'}
                        </span>
                      </div>
                      {mod.status === 'rejected' && mod.rejection_reason && (
                        <p className="text-xs text-destructive mb-1">
                          Причина: {mod.rejection_reason}
                        </p>
                      )}
                      <p className="text-sm text-muted-foreground line-clamp-1 mb-2">
                        {mod.summary}
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          {formatNumber(mod.downloads)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {formatNumber(mod.views)}
                        </span>
                        <span>Обновлён {formatDate(mod.updated_at)}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/studio/mods/${mod.id}`} className="flex items-center gap-2">
                            <Edit className="w-4 h-4" />
                            Редактировать
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link to={`/studio/mods/${mod.id}/versions`} className="flex items-center gap-2">
                            <Upload className="w-4 h-4" />
                            Версии
                          </Link>
                        </DropdownMenuItem>
                        {mod.status === 'published' && (
                          <DropdownMenuItem asChild>
                            <Link to={`/mod/${mod.slug}`} className="flex items-center gap-2">
                              <ExternalLink className="w-4 h-4" />
                              Открыть страницу
                            </Link>
                          </DropdownMenuItem>
                        )}
                        {(mod.status === 'draft' || mod.status === 'rejected') && (
                          <DropdownMenuItem
                            onClick={() => submitForModerationMutation.mutate(mod.id)}
                            disabled={!mod.primary_file_url}
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Отправить на модерацию
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive"
                          onClick={() => setDeleteModId(mod.id)}
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Удалить
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Delete Confirmation */}
        <AlertDialog open={!!deleteModId} onOpenChange={() => setDeleteModId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить мод?</AlertDialogTitle>
              <AlertDialogDescription>
                Это действие нельзя отменить. Мод будет удалён вместе со всеми версиями и комментариями.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отмена</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </StudioLayout>
  );
}
