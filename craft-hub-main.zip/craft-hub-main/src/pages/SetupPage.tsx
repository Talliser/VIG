import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Loader2, CheckCircle, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const SetupPage = () => {
  const { user, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [bootstrapToken, setBootstrapToken] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [canBootstrap, setCanBootstrap] = useState<boolean | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if bootstrap is available
  useEffect(() => {
    const checkBootstrapStatus = async () => {
      try {
        const { data, error } = await supabase.rpc("can_bootstrap_super_admin");
        
        if (error) {
          console.error("Failed to check bootstrap status:", error);
          setError("Failed to check system status");
          setCanBootstrap(false);
        } else {
          setCanBootstrap(data);
          if (!data) {
            // Super Admin already exists, redirect
            toast({
              title: "System already configured",
              description: "A Super Admin already exists. Redirecting...",
            });
            setTimeout(() => navigate("/"), 2000);
          }
        }
      } catch (err) {
        console.error("Error checking bootstrap:", err);
        setError("Failed to check system status");
        setCanBootstrap(false);
      } finally {
        setCheckingStatus(false);
      }
    };

    checkBootstrapStatus();
  }, [navigate, toast]);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user && canBootstrap) {
      toast({
        title: "Authentication required",
        description: "Please sign in to continue setup",
      });
      navigate("/auth", { state: { from: "/setup" } });
    }
  }, [user, authLoading, canBootstrap, navigate, toast]);

  const handleBootstrap = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bootstrapToken.trim()) {
      setError("Bootstrap token is required");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData?.session?.access_token;

      if (!accessToken) {
        setError("Session expired. Please sign in again.");
        navigate("/auth", { state: { returnTo: "/setup" } });
        return;
      }

      const response = await supabase.functions.invoke("bootstrap-super-admin", {
        body: { bootstrap_token: bootstrapToken },
      });

      if (response.error) {
        console.error("Bootstrap error:", response.error);
        setError(response.error.message || "Bootstrap failed");
        return;
      }

      if (response.data?.success) {
        toast({
          title: "Success!",
          description: "You are now the Super Admin. Redirecting to Admin Studio...",
        });
        
        // Short delay to show success message
        setTimeout(() => {
          navigate("/admin");
        }, 1500);
      } else {
        setError(response.data?.error || "Bootstrap failed");
      }
    } catch (err: any) {
      console.error("Bootstrap exception:", err);
      setError(err.message || "An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading state
  if (checkingStatus || authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Checking system status...</p>
        </div>
      </div>
    );
  }

  // Bootstrap not available (Super Admin exists)
  if (canBootstrap === false && !error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
            <CardTitle>System Configured</CardTitle>
            <CardDescription>
              A Super Admin already exists. This setup page is no longer available.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/")} className="w-full">
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Not authenticated
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <AlertTriangle className="h-12 w-12 mx-auto text-yellow-500 mb-4" />
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Please sign in to complete the system setup.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/auth", { state: { from: "/setup" } })} className="w-full">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main bootstrap form
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Shield className="h-12 w-12 mx-auto text-primary mb-4" />
          <CardTitle>System Setup</CardTitle>
          <CardDescription>
            Initialize the platform by becoming the first Super Admin.
            This action can only be performed once.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleBootstrap} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <label htmlFor="token" className="text-sm font-medium">
                Bootstrap Token
              </label>
              <Input
                id="token"
                type="password"
                value={bootstrapToken}
                onChange={(e) => setBootstrapToken(e.target.value)}
                placeholder="Enter the bootstrap secret token"
                disabled={isSubmitting}
                autoComplete="off"
              />
              <p className="text-xs text-muted-foreground">
                This token was configured during system deployment.
              </p>
            </div>

            <div className="bg-muted/50 rounded-lg p-3 text-sm">
              <p className="font-medium mb-1">Signed in as:</p>
              <p className="text-muted-foreground">{user.email}</p>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Activating...
                </>
              ) : (
                <>
                  <Shield className="mr-2 h-4 w-4" />
                  Activate Super Admin
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default SetupPage;
