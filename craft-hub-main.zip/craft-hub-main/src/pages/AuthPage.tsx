import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Loader2, Mail, Lock, User, AlertCircle, ArrowLeft, CheckCircle, Timer } from 'lucide-react';
import { z } from 'zod';
import TurnstileCaptcha, { TurnstileCaptchaRef } from '@/components/auth/TurnstileCaptcha';

const loginSchema = z.object({
  email: z.string().email('Введите корректный email'),
  password: z.string().min(6, 'Пароль должен быть не менее 6 символов'),
});

const signupSchema = z.object({
  username: z.string()
    .min(3, 'Имя пользователя должно быть не менее 3 символов')
    .max(20, 'Имя пользователя должно быть не более 20 символов')
    .regex(/^[a-zA-Z0-9_]+$/, 'Только латинские буквы, цифры и подчёркивание'),
  email: z.string().email('Введите корректный email'),
  password: z.string()
    .min(8, 'Пароль должен быть не менее 8 символов')
    .regex(/[A-Z]/, 'Пароль должен содержать заглавную букву')
    .regex(/[a-z]/, 'Пароль должен содержать строчную букву')
    .regex(/[0-9]/, 'Пароль должен содержать цифру'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Пароли не совпадают',
  path: ['confirmPassword'],
});

const forgotPasswordSchema = z.object({
  email: z.string().email('Введите корректный email'),
});

const newPasswordSchema = z.object({
  password: z.string()
    .min(8, 'Пароль должен быть не менее 8 символов')
    .regex(/[A-Z]/, 'Пароль должен содержать заглавную букву')
    .regex(/[a-z]/, 'Пароль должен содержать строчную букву')
    .regex(/[0-9]/, 'Пароль должен содержать цифру'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Пароли не совпадают',
  path: ['confirmPassword'],
});

type AuthMode = 'login' | 'signup' | 'forgot-password' | 'enter-code' | 'new-password' | 'reset-success';

export default function AuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  
  const [mode, setMode] = useState<AuthMode>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // CAPTCHA
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const captchaRef = useRef<TurnstileCaptchaRef>(null);
  
  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Signup form
  const [signupUsername, setSignupUsername] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');

  // Forgot password
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [codeExpiry, setCodeExpiry] = useState<number>(0);

  const from = (location.state as { from?: string })?.from || '/';

  // Timer for code expiry
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (mode === 'enter-code' && codeExpiry > 0) {
      interval = setInterval(() => {
        setCodeExpiry(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [mode, codeExpiry]);

  useEffect(() => {
    if (user && !authLoading) {
      navigate(from, { replace: true });
    }
  }, [user, authLoading, navigate, from]);

  // Reset CAPTCHA when changing modes
  useEffect(() => {
    setCaptchaToken(null);
    captchaRef.current?.reset();
  }, [mode]);

  const handleCaptchaSuccess = (token: string) => {
    setCaptchaToken(token);
  };

  const handleCaptchaError = () => {
    setCaptchaToken(null);
    setError('CAPTCHA ошибка. Попробуйте снова.');
  };

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    
    if (!captchaToken) {
      setError('Пожалуйста, подтвердите что вы не робот');
      return;
    }

    try {
      loginSchema.parse({ email: loginEmail, password: loginPassword });
    } catch (err) {
      if (err instanceof z.ZodError) {
        setError(err.errors[0].message);
        return;
      }
    }

    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('auth-with-captcha', {
        body: {
          action: 'login',
          email: loginEmail,
          password: loginPassword,
          captchaToken,
        }
      });

      if (error || !data?.success) {
        setError(data?.error || 'Ошибка входа');
        captchaRef.current?.reset();
        setCaptchaToken(null);
      } else if (data.session) {
        // Set session manually
        await supabase.auth.setSession(data.session);
      }
    } catch (err: any) {
      setError(err.message || 'Ошибка соединения');
      captchaRef.current?.reset();
      setCaptchaToken(null);
    }

    setIsLoading(false);
  }

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    
    if (!captchaToken) {
      setError('Пожалуйста, подтвердите что вы не робот');
      return;
    }

    try {
      signupSchema.parse({
        username: signupUsername,
        email: signupEmail,
        password: signupPassword,
        confirmPassword: signupConfirmPassword,
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        setError(err.errors[0].message);
        return;
      }
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('auth-with-captcha', {
        body: {
          action: 'signup',
          email: signupEmail,
          password: signupPassword,
          captchaToken,
          username: signupUsername,
        }
      });

      if (error || !data?.success) {
        setError(data?.error || 'Ошибка регистрации');
        captchaRef.current?.reset();
        setCaptchaToken(null);
      } else {
        setSuccess('Регистрация успешна! Проверьте email для подтверждения аккаунта.');
      }
    } catch (err: any) {
      setError(err.message || 'Ошибка соединения');
      captchaRef.current?.reset();
      setCaptchaToken(null);
    }

    setIsLoading(false);
  }

  async function handleSendResetCode(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    
    if (!captchaToken) {
      setError('Пожалуйста, подтвердите что вы не робот');
      return;
    }

    try {
      forgotPasswordSchema.parse({ email: forgotEmail });
    } catch (err) {
      if (err instanceof z.ZodError) {
        setError(err.errors[0].message);
        return;
      }
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('send-reset-code', {
        body: {
          email: forgotEmail,
          captchaToken,
        }
      });

      if (error) {
        setError('Ошибка отправки кода');
        captchaRef.current?.reset();
        setCaptchaToken(null);
      } else {
        setCodeExpiry(120);
        setMode('enter-code');
      }
    } catch (err: any) {
      setError(err.message || 'Ошибка соединения');
      captchaRef.current?.reset();
      setCaptchaToken(null);
    }

    setIsLoading(false);
  }

  async function handleVerifyCode(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (resetCode.length !== 6) {
      setError('Введите 6-значный код');
      return;
    }

    if (codeExpiry <= 0) {
      setError('Код истёк. Запросите новый.');
      return;
    }

    setMode('new-password');
  }

  async function handleResetPassword(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    
    if (!captchaToken) {
      setError('Пожалуйста, подтвердите что вы не робот');
      return;
    }

    try {
      newPasswordSchema.parse({ 
        password: newPassword, 
        confirmPassword: confirmNewPassword 
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        setError(err.errors[0].message);
        return;
      }
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('verify-reset-code', {
        body: {
          email: forgotEmail,
          code: resetCode,
          newPassword: newPassword,
          captchaToken,
        }
      });

      if (error || !data?.success) {
        setError(data?.error || 'Ошибка сброса пароля');
        captchaRef.current?.reset();
        setCaptchaToken(null);
      } else {
        setMode('reset-success');
      }
    } catch (err: any) {
      setError(err.message || 'Ошибка соединения');
      captchaRef.current?.reset();
      setCaptchaToken(null);
    }

    setIsLoading(false);
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-glow">
              <span className="text-primary-foreground font-bold text-2xl">M</span>
            </div>
            <div>
              <span className="font-bold text-2xl text-foreground">Mine</span>
              <span className="font-bold text-2xl text-primary">Mods</span>
            </div>
          </div>
        </div>

        <Card className="border-border/50 shadow-lg">
          {/* Forgot Password - Enter Email */}
          {mode === 'forgot-password' && (
            <>
              <CardHeader className="pb-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setMode('login')}
                  className="w-fit -ml-2"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Назад к входу
                </Button>
                <h2 className="text-xl font-semibold mt-2">Восстановление пароля</h2>
                <p className="text-sm text-muted-foreground">
                  Введите email, на который зарегистрирован аккаунт
                </p>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <form onSubmit={handleSendResetCode} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="forgot-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="forgot-email"
                        type="email"
                        placeholder="your@email.com"
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                  
                  <TurnstileCaptcha
                    ref={captchaRef}
                    onSuccess={handleCaptchaSuccess}
                    onError={handleCaptchaError}
                    onExpire={handleCaptchaError}
                  />
                  
                  <Button type="submit" className="w-full" disabled={isLoading || !captchaToken}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Отправка...
                      </>
                    ) : (
                      'Отправить код'
                    )}
                  </Button>
                </form>
              </CardContent>
            </>
          )}

          {/* Enter OTP Code */}
          {mode === 'enter-code' && (
            <>
              <CardHeader className="pb-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setMode('forgot-password')}
                  className="w-fit -ml-2"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Назад
                </Button>
                <h2 className="text-xl font-semibold mt-2">Введите код</h2>
                <p className="text-sm text-muted-foreground">
                  Код отправлен на {forgotEmail}
                </p>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <form onSubmit={handleVerifyCode} className="space-y-4">
                  <div className="flex flex-col items-center space-y-4">
                    <InputOTP
                      maxLength={6}
                      value={resetCode}
                      onChange={setResetCode}
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                    
                    <div className={`flex items-center gap-2 text-sm ${codeExpiry <= 30 ? 'text-destructive' : 'text-muted-foreground'}`}>
                      <Timer className="w-4 h-4" />
                      <span>
                        {codeExpiry > 0 
                          ? `Код действителен: ${formatTime(codeExpiry)}`
                          : 'Код истёк'}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={resetCode.length !== 6 || codeExpiry <= 0}
                  >
                    Подтвердить код
                  </Button>
                  
                  {codeExpiry <= 0 && (
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        setResetCode('');
                        setMode('forgot-password');
                      }}
                    >
                      Запросить новый код
                    </Button>
                  )}
                </form>
              </CardContent>
            </>
          )}

          {/* New Password */}
          {mode === 'new-password' && (
            <>
              <CardHeader className="pb-4">
                <h2 className="text-xl font-semibold">Новый пароль</h2>
                <p className="text-sm text-muted-foreground">
                  Создайте новый надёжный пароль
                </p>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="new-password">Новый пароль</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="new-password"
                        type="password"
                        placeholder="••••••••"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="pl-10"
                        required
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Минимум 8 символов, заглавная и строчная буквы, цифра
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-new-password">Подтвердите пароль</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="confirm-new-password"
                        type="password"
                        placeholder="••••••••"
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                  
                  <TurnstileCaptcha
                    ref={captchaRef}
                    onSuccess={handleCaptchaSuccess}
                    onError={handleCaptchaError}
                    onExpire={handleCaptchaError}
                  />
                  
                  <Button type="submit" className="w-full" disabled={isLoading || !captchaToken}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Сохранение...
                      </>
                    ) : (
                      'Сохранить пароль'
                    )}
                  </Button>
                </form>
              </CardContent>
            </>
          )}

          {/* Reset Success */}
          {mode === 'reset-success' && (
            <>
              <CardHeader className="pb-4 text-center">
                <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-xl font-semibold">Пароль изменён</h2>
                <p className="text-sm text-muted-foreground">
                  Теперь вы можете войти с новым паролем
                </p>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full"
                  onClick={() => {
                    setMode('login');
                    setForgotEmail('');
                    setResetCode('');
                    setNewPassword('');
                    setConfirmNewPassword('');
                  }}
                >
                  Войти в аккаунт
                </Button>
              </CardContent>
            </>
          )}

          {/* Login/Signup Tabs */}
          {(mode === 'login' || mode === 'signup') && (
            <Tabs value={mode} onValueChange={(v) => setMode(v as AuthMode)} className="w-full">
              <CardHeader className="pb-4">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login">Вход</TabsTrigger>
                  <TabsTrigger value="signup">Регистрация</TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="mb-4 border-primary/50 bg-primary/10">
                    <CheckCircle className="h-4 w-4 text-primary" />
                    <AlertDescription className="text-primary">{success}</AlertDescription>
                  </Alert>
                )}

                <TabsContent value="login" className="mt-0">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="your@email.com"
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label htmlFor="login-password">Пароль</Label>
                        <Button
                          type="button"
                          variant="link"
                          size="sm"
                          className="px-0 text-xs text-muted-foreground hover:text-primary"
                          onClick={() => {
                            setError(null);
                            setMode('forgot-password');
                          }}
                        >
                          Забыли пароль?
                        </Button>
                      </div>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="login-password"
                          type="password"
                          placeholder="••••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <TurnstileCaptcha
                      ref={captchaRef}
                      onSuccess={handleCaptchaSuccess}
                      onError={handleCaptchaError}
                      onExpire={handleCaptchaError}
                    />

                    <Button type="submit" className="w-full" disabled={isLoading || !captchaToken}>
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Вход...
                        </>
                      ) : (
                        'Войти'
                      )}
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup" className="mt-0">
                  <form onSubmit={handleSignup} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-username">Имя пользователя</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-username"
                          type="text"
                          placeholder="username"
                          value={signupUsername}
                          onChange={(e) => setSignupUsername(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-email"
                          type="email"
                          placeholder="your@email.com"
                          value={signupEmail}
                          onChange={(e) => setSignupEmail(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Пароль</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-password"
                          type="password"
                          placeholder="••••••••"
                          value={signupPassword}
                          onChange={(e) => setSignupPassword(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Минимум 8 символов, заглавная и строчная буквы, цифра
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-confirm-password">Подтвердите пароль</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-confirm-password"
                          type="password"
                          placeholder="••••••••"
                          value={signupConfirmPassword}
                          onChange={(e) => setSignupConfirmPassword(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <TurnstileCaptcha
                      ref={captchaRef}
                      onSuccess={handleCaptchaSuccess}
                      onError={handleCaptchaError}
                      onExpire={handleCaptchaError}
                    />

                    <Button type="submit" className="w-full" disabled={isLoading || !captchaToken}>
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Регистрация...
                        </>
                      ) : (
                        'Создать аккаунт'
                      )}
                    </Button>
                  </form>
                </TabsContent>
              </CardContent>
            </Tabs>
          )}
        </Card>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Продолжая, вы соглашаетесь с условиями использования MineMods
        </p>
      </div>
    </div>
  );
}
