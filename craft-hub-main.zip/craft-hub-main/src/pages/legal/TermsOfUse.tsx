import { Layout } from '@/components/layout/Layout';

const TermsOfUse = () => {
  return (
    <Layout>
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">

          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            Условия использования
          </h1>

          <p className="text-sm text-muted-foreground mb-8">
            Последнее обновление: 01 января 2026
          </p>

          <div className="space-y-10 text-sm md:text-base leading-relaxed">

            <section>
              <h2 className="text-xl font-semibold mb-2">
                Принятие условий
              </h2>
              <p>
                Настоящие Условия использования регулируют доступ и использование
                платформы MineMods, включая веб-сайт, API и связанные сервисы.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-2">
                Требования к пользователям
              </h2>
              <p>
                Сервис доступен пользователям старше 13 лет. Используя платформу,
                вы подтверждаете свою правоспособность.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-2">
                Учётная запись и безопасность
              </h2>
              <p>
                Вы несёте ответственность за безопасность своей учётной записи
                и за все действия, совершённые под ней.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-2">
                Контент пользователей
              </h2>
              <p>
                Пользователи сохраняют права на загружаемый контент, но предоставляют
                MineMods лицензию на его отображение и распространение.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-2">
                Ограничение ответственности
              </h2>
              <p>
                Сервис предоставляется «как есть». MineMods не несёт ответственности
                за пользовательский контент или сторонние сервисы.
              </p>
            </section>

          </div>
        </div>
      </section>
    </Layout>
  );
};

export default TermsOfUse;
