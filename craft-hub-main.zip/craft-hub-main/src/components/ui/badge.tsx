import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "text-foreground border-border",
        // MineMods specific variants
        java: "border-orange-500/30 bg-orange-500/10 text-orange-500 dark:text-orange-400",
        bedrock: "border-purple-500/30 bg-purple-500/10 text-purple-500 dark:text-purple-400",
        fabric: "border-blue-500/30 bg-blue-500/10 text-blue-500 dark:text-blue-400",
        forge: "border-orange-600/30 bg-orange-600/10 text-orange-600 dark:text-orange-500",
        neoforge: "border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400",
        quilt: "border-pink-500/30 bg-pink-500/10 text-pink-500 dark:text-pink-400",
        category: "border-muted-foreground/20 bg-muted text-muted-foreground hover:bg-muted/80",
        success: "border-green-500/30 bg-green-500/10 text-green-600 dark:text-green-400",
        warning: "border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400",
        info: "border-blue-400/30 bg-blue-400/10 text-blue-500 dark:text-blue-400",
      },
      size: {
        default: "px-2.5 py-0.5 text-xs",
        sm: "px-2 py-0.5 text-[10px]",
        lg: "px-3 py-1 text-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, size, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant, size }), className)} {...props} />;
}

export { Badge, badgeVariants };
