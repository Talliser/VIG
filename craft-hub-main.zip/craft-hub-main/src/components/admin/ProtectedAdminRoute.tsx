import { ReactNode, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions, PermissionCode } from '@/hooks/usePermissions';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProtectedAdminRouteProps {
  children: ReactNode;
  /** Required permission code(s) - user must have at least one */
  requiredPermission?: PermissionCode | PermissionCode[];
  /** If true, user must have ALL permissions instead of ANY */
  requireAll?: boolean;
}

/**
 * Protected route wrapper for Admin Studio pages
 * - Checks authentication
 * - Checks staff role
 * - Checks specific permissions
 * - Logs unauthorized access attempts
 * - Returns 403 page for unauthorized users
 */
export function ProtectedAdminRoute({ 
  children, 
  requiredPermission,
  requireAll = false 
}: ProtectedAdminRouteProps) {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth();
  const { 
    isLoading: permissionsLoading, 
    canAccessAdminStudio, 
    hasPermission, 
    hasAnyPermission,
    hasAllPermissions,
    role 
  } = usePermissions();

  const isLoading = authLoading || permissionsLoading;

  // Check permission based on requirements
  const checkPermission = (): boolean => {
    // First check if user can access admin studio at all
    if (!canAccessAdminStudio()) return false;
    
    // If no specific permission required, just admin access is enough
    if (!requiredPermission) return true;
    
    // Check specific permission(s)
    const permissions = Array.isArray(requiredPermission) 
      ? requiredPermission 
      : [requiredPermission];
    
    return requireAll 
      ? hasAllPermissions(permissions) 
      : hasAnyPermission(permissions);
  };

  const hasAccess = !isLoading && user && checkPermission();
  const isUnauthorized = !isLoading && (!user || !checkPermission());

  // Log unauthorized access attempts
  useEffect(() => {
    if (isUnauthorized && user) {
      // User is logged in but doesn't have permission - log this
      const logUnauthorizedAccess = async () => {
        try {
          await supabase.from('security_events').insert({
            event_type: 'unauthorized_access_attempt',
            severity: 'warning',
            user_id: user.id,
            details: {
              path: window.location.pathname,
              required_permission: requiredPermission,
              user_role: role,
            },
          });
        } catch (error) {
          console.error('Failed to log unauthorized access:', error);
        }
      };
      logUnauthorizedAccess();
    }
  }, [isUnauthorized, user, requiredPermission, role]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Проверка доступа...</p>
        </div>
      </div>
    );
  }

  // Not logged in - redirect to auth
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-6 max-w-md px-4">
          <ShieldAlert className="h-16 w-16 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Требуется авторизация</h1>
          <p className="text-muted-foreground">
            Для доступа к этой странице необходимо войти в аккаунт.
          </p>
          <Button onClick={() => navigate('/auth')}>
            Войти
          </Button>
        </div>
      </div>
    );
  }

  // 403 - Forbidden
  if (isUnauthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-6 max-w-md px-4">
          <div className="relative">
            <ShieldAlert className="h-16 w-16 mx-auto text-destructive" />
            <span className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground text-xs font-bold px-2 py-1 rounded">
              403
            </span>
          </div>
          <h1 className="text-2xl font-bold">Доступ запрещён</h1>
          <p className="text-muted-foreground">
            У вас нет прав для доступа к этой странице. 
            Эта попытка была зафиксирована.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={() => navigate(-1)}>
              Назад
            </Button>
            <Button onClick={() => navigate('/')}>
              На главную
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // User has access
  return <>{children}</>;
}
