import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { usePermissions } from '@/hooks/usePermissions';
import { useToast } from '@/hooks/use-toast';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { XPProgressBar } from '@/components/profile/XPProgressBar';
import { BadgeDisplay } from '@/components/profile/BadgeDisplay';
import { formatDate } from '@/lib/format';
import {
  Snowflake, Award, Star, Shield, AlertTriangle, Ban, UserCheck,
  Plus, Minus,
} from 'lucide-react';

interface UserDetailPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: any;
}

export function UserDetailPanel({ open, onOpenChange, user }: UserDetailPanelProps) {
  const { hasPermission, role: currentRole } = usePermissions();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [xpAmount, setXpAmount] = useState('10');
  const [xpReason, setXpReason] = useState('');
  const [badgeName, setBadgeName] = useState('');
  const [badgeKey, setBadgeKey] = useState('');
  const [badgeIcon, setBadgeIcon] = useState('🎖️');
  const [badgeDesc, setBadgeDesc] = useState('');
  const [freezeReason, setFreezeReason] = useState('');

  // Fetch extended profile data
  const { data: profileData } = useQuery({
    queryKey: ['admin-user-detail', user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      return data;
    },
    enabled: open && !!user?.id,
  });

  const { data: badges = [] } = useQuery({
    queryKey: ['admin-user-badges', user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('user_badges')
        .select('*')
        .eq('profile_id', user.id)
        .order('awarded_at', { ascending: false });
      return data || [];
    },
    enabled: open && !!user?.id,
  });

  const { data: xpLogs = [] } = useQuery({
    queryKey: ['admin-user-xp-logs', user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('user_xp_log')
        .select('*')
        .eq('profile_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);
      return data || [];
    },
    enabled: open && !!user?.id,
  });

  // Award XP mutation
  const awardXpMutation = useMutation({
    mutationFn: async ({ amount, reason }: { amount: number; reason: string }) => {
      const { error } = await supabase.rpc('award_xp', {
        _profile_id: user.id,
        _amount: amount,
        _reason: reason,
        _source_type: 'admin',
      });
      if (error) throw error;
      // Log admin action
      await supabase.from('admin_logs').insert({
        admin_id: (await supabase.auth.getUser()).data.user?.id || '',
        action: 'xp_modified',
        target_type: 'user',
        target_id: user.user_id,
        details: { amount, reason },
      });
    },
    onSuccess: () => {
      toast({ title: 'XP обновлён' });
      setXpReason('');
      queryClient.invalidateQueries({ queryKey: ['admin-user-detail', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['admin-user-xp-logs', user?.id] });
    },
    onError: (e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }),
  });

  // Award Badge mutation
  const awardBadgeMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from('user_badges').insert({
        profile_id: user.id,
        badge_key: badgeKey,
        badge_name: badgeName,
        badge_description: badgeDesc || null,
        badge_icon: badgeIcon,
        awarded_by: (await supabase.auth.getUser()).data.user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Бейдж выдан' });
      setBadgeName('');
      setBadgeKey('');
      setBadgeDesc('');
      queryClient.invalidateQueries({ queryKey: ['admin-user-badges', user?.id] });
    },
    onError: (e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }),
  });

  // Remove badge
  const removeBadgeMutation = useMutation({
    mutationFn: async (badgeId: string) => {
      const { error } = await supabase.from('user_badges').delete().eq('id', badgeId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Бейдж удалён' });
      queryClient.invalidateQueries({ queryKey: ['admin-user-badges', user?.id] });
    },
  });

  // Freeze/Unfreeze
  const freezeMutation = useMutation({
    mutationFn: async (freeze: boolean) => {
      const adminUser = (await supabase.auth.getUser()).data.user;
      const updates: Record<string, any> = {
        is_frozen: freeze,
        frozen_at: freeze ? new Date().toISOString() : null,
        frozen_by: freeze ? adminUser?.id : null,
        freeze_reason: freeze ? freezeReason : null,
      };
      const { error } = await supabase.from('profiles').update(updates).eq('id', user.id);
      if (error) throw error;
      await supabase.from('admin_logs').insert({
        admin_id: adminUser?.id || '',
        action: freeze ? 'profile_frozen' : 'profile_unfrozen',
        target_type: 'user',
        target_id: user.user_id,
        details: { reason: freezeReason },
      });
    },
    onSuccess: () => {
      toast({ title: profileData?.is_frozen ? 'Профиль разморожен' : 'Профиль заморожен' });
      setFreezeReason('');
      queryClient.invalidateQueries({ queryKey: ['admin-user-detail', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
  });

  // Verify author
  const verifyMutation = useMutation({
    mutationFn: async (verified: boolean) => {
      const { error } = await supabase.from('profiles').update({ verified }).eq('id', user.id);
      if (error) throw error;
      // Award verified badge automatically
      if (verified) {
        await supabase.from('user_badges').insert({
          profile_id: user.id,
          badge_key: 'verified_modder',
          badge_name: 'Верифицированный автор',
          badge_description: 'Автор прошёл проверку модераторами',
          badge_icon: '✅',
          awarded_by: (await supabase.auth.getUser()).data.user?.id,
          is_auto: true,
        });
      }
    },
    onSuccess: () => {
      toast({ title: 'Статус верификации обновлён' });
      queryClient.invalidateQueries({ queryKey: ['admin-user-detail', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
  });

  if (!user) return null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={user.avatar || undefined} />
              <AvatarFallback>{user.display_name?.[0] || user.username?.[0]}</AvatarFallback>
            </Avatar>
            <div>
              <span>{user.display_name || user.username}</span>
              <p className="text-sm font-normal text-muted-foreground">@{user.username}</p>
            </div>
          </SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="overview" className="mt-4">
          <TabsList className="w-full">
            <TabsTrigger value="overview">Обзор</TabsTrigger>
            <TabsTrigger value="xp">XP</TabsTrigger>
            <TabsTrigger value="badges">Бейджи</TabsTrigger>
            <TabsTrigger value="actions">Действия</TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="space-y-4">
            {profileData && (
              <>
                <XPProgressBar
                  xp={profileData.xp ?? 0}
                  level={profileData.level ?? 0}
                  levelName={profileData.level_name ?? 'Новичок'}
                />
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="p-2 bg-secondary/50 rounded">
                    <span className="text-muted-foreground">Заморожен:</span>{' '}
                    <Badge variant={profileData.is_frozen ? 'destructive' : 'outline'}>
                      {profileData.is_frozen ? 'Да' : 'Нет'}
                    </Badge>
                  </div>
                  <div className="p-2 bg-secondary/50 rounded">
                    <span className="text-muted-foreground">Верифицирован:</span>{' '}
                    <Badge variant={profileData.verified ? 'default' : 'outline'}>
                      {profileData.verified ? 'Да' : 'Нет'}
                    </Badge>
                  </div>
                  <div className="p-2 bg-secondary/50 rounded col-span-2">
                    <span className="text-muted-foreground">Регистрация:</span>{' '}
                    {formatDate(profileData.created_at)}
                  </div>
                </div>
              </>
            )}
          </TabsContent>

          {/* XP Management */}
          <TabsContent value="xp" className="space-y-4">
            {hasPermission('users.xp') && (
              <Card>
                <CardHeader><CardTitle className="text-base">Изменить XP</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={xpAmount}
                      onChange={(e) => setXpAmount(e.target.value)}
                      className="w-24"
                    />
                    <Button
                      size="sm"
                      onClick={() => awardXpMutation.mutate({ amount: parseInt(xpAmount), reason: xpReason || 'Admin adjustment' })}
                      disabled={!xpReason || awardXpMutation.isPending}
                    >
                      <Plus className="w-4 h-4 mr-1" />Добавить
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => awardXpMutation.mutate({ amount: -parseInt(xpAmount), reason: xpReason || 'Admin penalty' })}
                      disabled={!xpReason || awardXpMutation.isPending}
                    >
                      <Minus className="w-4 h-4 mr-1" />Снять
                    </Button>
                  </div>
                  <Input
                    placeholder="Причина изменения XP (обязательно)"
                    value={xpReason}
                    onChange={(e) => setXpReason(e.target.value)}
                  />
                </CardContent>
              </Card>
            )}

            {/* XP Log */}
            <Card>
              <CardHeader><CardTitle className="text-base">История XP</CardTitle></CardHeader>
              <CardContent>
                {xpLogs.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Нет записей</p>
                ) : (
                  <div className="space-y-1.5 max-h-60 overflow-y-auto">
                    {xpLogs.map((log: any) => (
                      <div key={log.id} className="flex items-center justify-between text-sm p-2 rounded bg-secondary/30">
                        <div>
                          <span className={log.amount >= 0 ? 'text-primary font-medium' : 'text-destructive font-medium'}>
                            {log.amount >= 0 ? '+' : ''}{log.amount} XP
                          </span>
                          <span className="text-muted-foreground ml-2">{log.reason}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">{formatDate(log.created_at)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Badges */}
          <TabsContent value="badges" className="space-y-4">
            {hasPermission('users.badges') && (
              <Card>
                <CardHeader><CardTitle className="text-base">Выдать бейдж</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex gap-2">
                    <Input placeholder="Ключ (badge_key)" value={badgeKey} onChange={(e) => setBadgeKey(e.target.value)} />
                    <Input placeholder="Иконка" value={badgeIcon} onChange={(e) => setBadgeIcon(e.target.value)} className="w-20" />
                  </div>
                  <Input placeholder="Название бейджа" value={badgeName} onChange={(e) => setBadgeName(e.target.value)} />
                  <Input placeholder="Описание (опц.)" value={badgeDesc} onChange={(e) => setBadgeDesc(e.target.value)} />
                  <Button
                    size="sm"
                    onClick={() => awardBadgeMutation.mutate()}
                    disabled={!badgeKey || !badgeName || awardBadgeMutation.isPending}
                  >
                    <Award className="w-4 h-4 mr-1" />Выдать
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Existing badges */}
            <div className="space-y-2">
              {badges.map((b: any) => (
                <div key={b.id} className="flex items-center justify-between p-2 rounded bg-secondary/30">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{b.badge_icon || '🎖️'}</span>
                    <div>
                      <p className="text-sm font-medium">{b.badge_name}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(b.awarded_at)}</p>
                    </div>
                  </div>
                  {hasPermission('users.badges') && (
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => removeBadgeMutation.mutate(b.id)}>
                      Удалить
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Admin Actions */}
          <TabsContent value="actions" className="space-y-4">
            {/* Freeze */}
            {hasPermission('users.freeze') && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Snowflake className="w-4 h-4" />
                    Заморозка профиля
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {!profileData?.is_frozen ? (
                    <>
                      <Textarea
                        placeholder="Причина заморозки..."
                        value={freezeReason}
                        onChange={(e) => setFreezeReason(e.target.value)}
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => freezeMutation.mutate(true)}
                        disabled={!freezeReason || freezeMutation.isPending}
                      >
                        <Snowflake className="w-4 h-4 mr-1" />Заморозить
                      </Button>
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-muted-foreground">
                        Причина: {profileData.freeze_reason || 'Не указана'}
                      </p>
                      <Button
                        size="sm"
                        onClick={() => freezeMutation.mutate(false)}
                        disabled={freezeMutation.isPending}
                      >
                        Разморозить
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Verify */}
            {hasPermission('users.verify') && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <UserCheck className="w-4 h-4" />
                    Верификация автора
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Label>Верифицированный автор</Label>
                    <Switch
                      checked={profileData?.verified ?? false}
                      onCheckedChange={(v) => verifyMutation.mutate(v)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
