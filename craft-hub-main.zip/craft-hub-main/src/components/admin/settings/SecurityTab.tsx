import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Loader2 } from 'lucide-react';

interface SecurityTabProps {
  settings: Record<string, any> | undefined;
  isLoading: boolean;
  onSave: (key: string, value: any) => void;
  isSaving: boolean;
}

export function SecurityTab({ settings, isLoading, onSave, isSaving }: SecurityTabProps) {
  const [registrationEnabled, setRegistrationEnabled] = useState(true);
  const [emailVerification, setEmailVerification] = useState(false);
  const [maxUploadSize, setMaxUploadSize] = useState(100);

  useEffect(() => {
    if (settings) {
      if (settings.registration_enabled !== undefined) setRegistrationEnabled(settings.registration_enabled);
      if (settings.email_verification_required !== undefined) setEmailVerification(settings.email_verification_required);
      if (settings.max_upload_size !== undefined) setMaxUploadSize(settings.max_upload_size);
    }
  }, [settings]);

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Регистрация</CardTitle>
          <CardDescription>Настройки регистрации пользователей</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label>Регистрация включена</Label>
              <p className="text-sm text-muted-foreground">
                Разрешить новым пользователям регистрироваться
              </p>
            </div>
            <Switch
              checked={registrationEnabled}
              onCheckedChange={(checked) => {
                setRegistrationEnabled(checked);
                onSave('registration_enabled', checked);
              }}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Подтверждение email</Label>
              <p className="text-sm text-muted-foreground">
                Требовать подтверждение email при регистрации
              </p>
            </div>
            <Switch
              checked={emailVerification}
              onCheckedChange={(checked) => {
                setEmailVerification(checked);
                onSave('email_verification_required', checked);
              }}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Лимиты</CardTitle>
          <CardDescription>Ограничения платформы</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Максимальный размер загрузки (МБ)</Label>
            <Input
              type="number"
              value={maxUploadSize}
              onChange={(e) => setMaxUploadSize(parseInt(e.target.value) || 0)}
              min="1"
              max="500"
            />
          </div>

          <Button
            onClick={() => onSave('max_upload_size', maxUploadSize)}
            disabled={isSaving}
          >
            {isSaving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Сохранить
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
