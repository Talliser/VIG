import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Plus, Edit, Trash, GripVertical, Loader2 } from 'lucide-react';

export function CategoriesTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    name_plural: '',
    slug: '',
    description: '',
    icon: '',
    enabled: true,
  });

  const { data: projectTypes, isLoading } = useQuery({
    queryKey: ['project-types-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_types')
        .select('*')
        .order('sort_order', { ascending: true });
      if (error) throw error;
      return data || [];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (selectedType) {
        const { error } = await supabase.from('project_types').update(data).eq('id', selectedType.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('project_types').insert({
          ...data,
          sort_order: (projectTypes?.length || 0) + 1,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: 'Сохранено' });
      setEditDialogOpen(false);
      setSelectedType(null);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['project-types-admin'] });
      queryClient.invalidateQueries({ queryKey: ['project-types'] });
    },
    onError: (e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('project_types').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Удалено' });
      queryClient.invalidateQueries({ queryKey: ['project-types-admin'] });
      queryClient.invalidateQueries({ queryKey: ['project-types'] });
    },
  });

  const resetForm = () => setFormData({ name: '', name_plural: '', slug: '', description: '', icon: '', enabled: true });

  const openEditDialog = (type?: any) => {
    if (type) {
      setSelectedType(type);
      setFormData({
        name: type.name,
        name_plural: type.name_plural,
        slug: type.slug,
        description: type.description || '',
        icon: type.icon || '',
        enabled: type.enabled,
      });
    } else {
      setSelectedType(null);
      resetForm();
    }
    setEditDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Управление типами проектов (моды, ресурс-паки и т.д.)
        </p>
        <Button size="sm" onClick={() => openEditDialog()}>
          <Plus className="h-4 w-4 mr-2" />
          Добавить
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10"></TableHead>
                <TableHead>Название</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Статус</TableHead>
                <TableHead className="w-20"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">
                    <Loader2 className="h-5 w-5 animate-spin mx-auto" />
                  </TableCell>
                </TableRow>
              ) : projectTypes?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    Типы проектов не найдены
                  </TableCell>
                </TableRow>
              ) : (
                projectTypes?.map((type: any) => (
                  <TableRow key={type.id}>
                    <TableCell>
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {type.icon && <span>{type.icon}</span>}
                        <div>
                          <p className="font-medium">{type.name}</p>
                          <p className="text-xs text-muted-foreground">{type.name_plural}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{type.slug}</TableCell>
                    <TableCell>
                      <Badge variant={type.enabled ? 'default' : 'secondary'}>
                        {type.enabled ? 'Активен' : 'Отключен'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEditDialog(type)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm('Удалить этот тип проекта?')) deleteMutation.mutate(type.id);
                          }}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedType ? 'Редактировать тип' : 'Новый тип проекта'}</DialogTitle>
            <DialogDescription>
              {selectedType ? 'Измените параметры типа проекта' : 'Добавьте новый тип проекта'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Название (ед.ч.)</Label>
                <Input value={formData.name} onChange={(e) => setFormData(f => ({ ...f, name: e.target.value }))} placeholder="Мод" />
              </div>
              <div className="space-y-2">
                <Label>Название (мн.ч.)</Label>
                <Input value={formData.name_plural} onChange={(e) => setFormData(f => ({ ...f, name_plural: e.target.value }))} placeholder="Моды" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Slug</Label>
              <Input value={formData.slug} onChange={(e) => setFormData(f => ({ ...f, slug: e.target.value }))} placeholder="mods" />
            </div>
            <div className="space-y-2">
              <Label>Описание</Label>
              <Input value={formData.description} onChange={(e) => setFormData(f => ({ ...f, description: e.target.value }))} placeholder="Модификации для Minecraft" />
            </div>
            <div className="space-y-2">
              <Label>Иконка (emoji)</Label>
              <Input value={formData.icon} onChange={(e) => setFormData(f => ({ ...f, icon: e.target.value }))} placeholder="📦" />
            </div>
            <div className="flex items-center justify-between">
              <Label>Активен</Label>
              <Switch checked={formData.enabled} onCheckedChange={(c) => setFormData(f => ({ ...f, enabled: c }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Отмена</Button>
            <Button onClick={() => saveMutation.mutate(formData)} disabled={saveMutation.isPending}>Сохранить</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
