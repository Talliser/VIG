import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { usePermissions } from '@/hooks/usePermissions';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { History, Undo2, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

interface FeatureHistory {
  id: string;
  feature_key: string;
  old_value: boolean;
  new_value: boolean;
  changed_by: string;
  change_reason: string | null;
  created_at: string;
}

export function ChangeHistoryTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { hasPermission } = usePermissions();

  const { data: history = [], isLoading } = useQuery({
    queryKey: ['platform-feature-history'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('platform_feature_history')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (error) throw error;
      return data as FeatureHistory[];
    },
    enabled: hasPermission('platform.features'),
  });

  const rollbackMutation = useMutation({
    mutationFn: async (historyId: string) => {
      const { error } = await supabase.rpc('rollback_platform_feature', {
        _history_id: historyId,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Откат выполнен' });
      queryClient.invalidateQueries({ queryKey: ['platform-feature-history'] });
      queryClient.invalidateQueries({ queryKey: ['platform-features-admin'] });
      queryClient.invalidateQueries({ queryKey: ['platform-features'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка отката', description: error.message, variant: 'destructive' });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (history.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p>История изменений пуста</p>
          <p className="text-sm mt-1">Изменения Feature Flags будут отображаться здесь</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            История изменений
          </CardTitle>
          <CardDescription>
            Последние {history.length} изменений. Каждое можно откатить.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Функция</TableHead>
                <TableHead>Изменение</TableHead>
                <TableHead>Причина</TableHead>
                <TableHead>Дата</TableHead>
                <TableHead className="w-[80px]">Откат</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell>
                    <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                      {entry.feature_key}
                    </code>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Badge variant={entry.old_value ? 'default' : 'secondary'}>
                        {entry.old_value ? 'ВКЛ' : 'ВЫКЛ'}
                      </Badge>
                      <span className="text-muted-foreground">→</span>
                      <Badge variant={entry.new_value ? 'default' : 'secondary'}>
                        {entry.new_value ? 'ВКЛ' : 'ВЫКЛ'}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                    {entry.change_reason || '—'}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                    {format(new Date(entry.created_at), 'dd MMM yyyy HH:mm', { locale: ru })}
                  </TableCell>
                  <TableCell>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => rollbackMutation.mutate(entry.id)}
                          disabled={rollbackMutation.isPending}
                        >
                          <Undo2 className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Откатить изменение</TooltipContent>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
