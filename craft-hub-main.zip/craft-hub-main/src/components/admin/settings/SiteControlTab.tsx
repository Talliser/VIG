import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { useToast } from '@/hooks/use-toast';
import {
  Eye,
  EyeOff,
  Settings,
  History,
  GripVertical,
  Loader2,
  LayoutDashboard,
  ArrowUpDown,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';

interface SitePage {
  id: string;
  key: string;
  name: string;
  description: string | null;
  icon: string | null;
  sort_order: number;
  enabled: boolean;
}

interface SiteBlock {
  id: string;
  page_id: string;
  key: string;
  name: string;
  block_type: string;
  description: string | null;
  config: Record<string, unknown>;
  visible: boolean;
  sort_order: number;
  status: string;
}

interface BlockHistory {
  id: string;
  block_id: string;
  changed_by: string;
  old_visible: boolean | null;
  new_visible: boolean | null;
  change_reason: string | null;
  created_at: string;
}

export function SiteControlTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPage, setSelectedPage] = useState<string | null>(null);
  const [editBlock, setEditBlock] = useState<SiteBlock | null>(null);
  const [historyBlock, setHistoryBlock] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [editConfig, setEditConfig] = useState('');

  // Fetch pages
  const { data: pages = [], isLoading: pagesLoading } = useQuery({
    queryKey: ['site-pages-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_pages')
        .select('*')
        .order('sort_order');
      if (error) throw error;
      return data as SitePage[];
    },
  });

  // Fetch blocks for selected page
  const { data: blocks = [], isLoading: blocksLoading } = useQuery({
    queryKey: ['site-blocks-admin', selectedPage],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_blocks')
        .select('*')
        .eq('page_id', selectedPage!)
        .order('sort_order');
      if (error) throw error;
      return data as SiteBlock[];
    },
    enabled: !!selectedPage,
  });

  // Fetch history for a block
  const { data: history = [] } = useQuery({
    queryKey: ['block-history-admin', historyBlock],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_block_history')
        .select('*')
        .eq('block_id', historyBlock!)
        .order('created_at', { ascending: false })
        .limit(20);
      if (error) throw error;
      return data as BlockHistory[];
    },
    enabled: !!historyBlock,
  });

  // Toggle block visibility
  const toggleMutation = useMutation({
    mutationFn: async ({ blockId, visible }: { blockId: string; visible: boolean }) => {
      const { error } = await supabase.rpc('update_site_block', {
        _block_id: blockId,
        _visible: visible,
        _reason: `Блок ${visible ? 'показан' : 'скрыт'}`,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Блок обновлён' });
      queryClient.invalidateQueries({ queryKey: ['site-blocks-admin'] });
    },
    onError: (e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }),
  });

  // Save block config
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!editBlock) return;
      let parsedConfig: Record<string, unknown>;
      try {
        parsedConfig = JSON.parse(editConfig);
      } catch {
        throw new Error('Невалидный JSON в конфигурации');
      }

      const { error } = await supabase.rpc('update_site_block', {
        _block_id: editBlock.id,
        _config: parsedConfig as any,
        _reason: reason || 'Обновление конфигурации',
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Конфигурация сохранена' });
      queryClient.invalidateQueries({ queryKey: ['site-blocks-admin'] });
      setEditBlock(null);
      setReason('');
    },
    onError: (e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }),
  });

  const openEdit = (block: SiteBlock) => {
    setEditBlock(block);
    setEditConfig(JSON.stringify(block.config, null, 2));
    setReason('');
  };

  const currentPage = pages.find(p => p.id === selectedPage);

  if (pagesLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Info */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium">Редактор сайта</p>
              <p className="text-sm text-muted-foreground">
                Выберите страницу для управления её блоками. Каждый блок можно показать, скрыть или настроить.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Page selector */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {pages.map((page) => (
          <button
            key={page.id}
            onClick={() => setSelectedPage(page.id)}
            className={`p-4 rounded-xl border text-left transition-all ${
              selectedPage === page.id
                ? 'border-primary bg-primary/10 ring-2 ring-primary/20'
                : 'border-border hover:border-primary/50 hover:bg-accent'
            }`}
          >
            <span className="text-2xl block mb-2">{page.icon || '📄'}</span>
            <p className="font-medium text-sm">{page.name}</p>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{page.description}</p>
          </button>
        ))}
      </div>

      {/* Blocks list */}
      {selectedPage && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <span>{currentPage?.icon}</span>
                  {currentPage?.name}
                </CardTitle>
                <CardDescription>
                  {blocks.length} {blocks.length === 1 ? 'блок' : 'блоков'} на странице
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {blocksLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : blocks.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Блоки не найдены
              </p>
            ) : (
              <div className="space-y-3">
                {blocks.map((block, idx) => (
                  <div
                    key={block.id}
                    className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                      block.visible ? 'border-border bg-card' : 'border-border/50 bg-muted/30 opacity-60'
                    }`}
                  >
                    <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0 cursor-grab" />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{block.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {block.block_type}
                        </Badge>
                        <code className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                          {block.key}
                        </code>
                      </div>
                      {block.description && (
                        <p className="text-sm text-muted-foreground mt-1">{block.description}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setHistoryBlock(block.id)}
                        title="История изменений"
                      >
                        <History className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(block)}
                        title="Настройки блока"
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                      <Switch
                        checked={block.visible}
                        onCheckedChange={(v) => toggleMutation.mutate({ blockId: block.id, visible: v })}
                        disabled={toggleMutation.isPending}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Block edit dialog */}
      <Dialog open={!!editBlock} onOpenChange={() => setEditBlock(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Настройки: {editBlock?.name}</DialogTitle>
            <DialogDescription>
              Редактируйте конфигурацию блока (JSON). Все изменения логируются.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Конфигурация (JSON)</Label>
              <Textarea
                value={editConfig}
                onChange={(e) => setEditConfig(e.target.value)}
                rows={10}
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label>Причина изменения</Label>
              <Input
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Описание изменения..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditBlock(null)}>
              Отмена
            </Button>
            <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
              {saveMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History dialog */}
      <Dialog open={!!historyBlock} onOpenChange={() => setHistoryBlock(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>История изменений</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[400px]">
            {history.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Нет истории изменений
              </p>
            ) : (
              <div className="space-y-3">
                {history.map((h) => (
                  <div key={h.id} className="p-3 rounded-lg border border-border">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="text-xs">
                        {h.new_visible !== h.old_visible
                          ? h.new_visible ? 'Показан' : 'Скрыт'
                          : 'Конфигурация'}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(h.created_at), { addSuffix: true, locale: ru })}
                      </span>
                    </div>
                    {h.change_reason && (
                      <p className="text-sm text-muted-foreground">{h.change_reason}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
