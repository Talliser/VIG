import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Loader2 } from 'lucide-react';

interface ModerationTabProps {
  settings: Record<string, any> | undefined;
  isLoading: boolean;
  onSave: (key: string, value: any) => void;
}

export function ModerationTab({ settings, isLoading, onSave }: ModerationTabProps) {
  const [autoApprove, setAutoApprove] = useState(false);

  useEffect(() => {
    if (settings) {
      if (settings.auto_approve !== undefined) setAutoApprove(settings.auto_approve);
    }
  }, [settings]);

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Настройки модерации</CardTitle>
          <CardDescription>Как обрабатывается новый контент</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label>Автоматическое одобрение</Label>
              <p className="text-sm text-muted-foreground">
                Публиковать моды без ручной модерации
              </p>
            </div>
            <Switch
              checked={autoApprove}
              onCheckedChange={(checked) => {
                setAutoApprove(checked);
                onSave('auto_approve', checked);
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
