import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Loader2 } from 'lucide-react';

interface GeneralTabProps {
  settings: Record<string, any> | undefined;
  isLoading: boolean;
  onSave: (key: string, value: any) => void;
  isSaving: boolean;
}

export function GeneralTab({ settings, isLoading, onSave, isSaving }: GeneralTabProps) {
  const [siteName, setSiteName] = useState('MineMods');
  const [siteDescription, setSiteDescription] = useState('Платформа модов для Minecraft');
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  useEffect(() => {
    if (settings) {
      if (settings.site_name) setSiteName(settings.site_name);
      if (settings.site_description) setSiteDescription(settings.site_description);
      if (settings.maintenance_mode !== undefined) setMaintenanceMode(settings.maintenance_mode);
    }
  }, [settings]);

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Основные настройки</CardTitle>
          <CardDescription>Базовая информация о платформе</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Название сайта</Label>
            <Input
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
              placeholder="MineMods"
            />
          </div>

          <div className="space-y-2">
            <Label>Описание сайта</Label>
            <Input
              value={siteDescription}
              onChange={(e) => setSiteDescription(e.target.value)}
              placeholder="Платформа модов для Minecraft"
            />
          </div>

          <Button
            onClick={() => {
              onSave('site_name', siteName);
              onSave('site_description', siteDescription);
            }}
            disabled={isSaving}
          >
            {isSaving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Сохранить
          </Button>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>Режим обслуживания</Label>
              <p className="text-sm text-muted-foreground">
                Сайт будет недоступен для обычных пользователей
              </p>
            </div>
            <Switch
              checked={maintenanceMode}
              onCheckedChange={(checked) => {
                setMaintenanceMode(checked);
                onSave('maintenance_mode', checked);
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
