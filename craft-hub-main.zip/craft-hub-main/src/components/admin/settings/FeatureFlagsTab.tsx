import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { usePermissions } from '@/hooks/usePermissions';
import {
  AlertTriangle,
  Shield,
  Loader2,
  Search,
  ToggleLeft,
} from 'lucide-react';

interface Feature {
  id: string;
  key: string;
  name: string;
  description: string | null;
  category: string;
  enabled: boolean;
  risk_level: string;
  requires_confirmation: boolean;
  default_value: boolean;
  updated_at: string;
}

const CATEGORY_LABELS: Record<string, string> = {
  content: 'Контент',
  social: 'Социальные',
  moderation: 'Модерация',
  analytics: 'Аналитика',
  system: 'Система',
  general: 'Общие',
};

const RISK_CONFIG: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive'; icon?: typeof AlertTriangle }> = {
  low: { label: 'Низкий', variant: 'secondary' },
  medium: { label: 'Средний', variant: 'default', icon: AlertTriangle },
  high: { label: 'Высокий', variant: 'destructive', icon: Shield },
};

export function FeatureFlagsTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { hasPermission, role } = usePermissions();
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDialog, setConfirmDialog] = useState<{
    feature: Feature;
    newValue: boolean;
  } | null>(null);
  const [reason, setReason] = useState('');

  const canManage = hasPermission('platform.features');
  const isHighRiskAllowed = role === 'super_admin';

  const { data: features = [], isLoading } = useQuery({
    queryKey: ['platform-features-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('platform_features')
        .select('*')
        .order('category')
        .order('name');
      if (error) throw error;
      return data as Feature[];
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ key, value, changeReason }: { key: string; value: boolean; changeReason?: string }) => {
      const { data, error } = await supabase.rpc('toggle_platform_feature', {
        _feature_key: key,
        _new_value: value,
        _reason: changeReason || null,
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      toast({
        title: variables.value ? 'Функция включена' : 'Функция отключена',
        description: `${variables.key} ${variables.value ? 'активирована' : 'деактивирована'}`,
      });
      queryClient.invalidateQueries({ queryKey: ['platform-features-admin'] });
      queryClient.invalidateQueries({ queryKey: ['platform-features'] });
      setConfirmDialog(null);
      setReason('');
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const handleToggle = (feature: Feature, newValue: boolean) => {
    if (feature.risk_level === 'high' && !isHighRiskAllowed) {
      toast({
        title: 'Недостаточно прав',
        description: 'Только Super Admin может изменять функции высокого риска',
        variant: 'destructive',
      });
      return;
    }

    if (feature.requires_confirmation) {
      setConfirmDialog({ feature, newValue });
    } else {
      toggleMutation.mutate({ key: feature.key, value: newValue });
    }
  };

  const confirmToggle = () => {
    if (!confirmDialog) return;
    toggleMutation.mutate({
      key: confirmDialog.feature.key,
      value: confirmDialog.newValue,
      changeReason: reason || undefined,
    });
  };

  const filtered = features.filter(
    (f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.description || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const grouped = filtered.reduce<Record<string, Feature[]>>((acc, f) => {
    if (!acc[f.category]) acc[f.category] = [];
    acc[f.category].push(f);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Поиск функций..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Summary */}
      <div className="flex gap-4 text-sm text-muted-foreground">
        <span className="flex items-center gap-1">
          <ToggleLeft className="h-4 w-4" />
          {features.filter((f) => f.enabled).length} / {features.length} активно
        </span>
      </div>

      {/* Feature groups */}
      {Object.entries(grouped).map(([category, items]) => (
        <Card key={category}>
          <CardHeader>
            <CardTitle className="text-lg">
              {CATEGORY_LABELS[category] || category}
            </CardTitle>
            <CardDescription>
              {items.length} {items.length === 1 ? 'функция' : 'функций'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {items.map((feature, idx) => {
              const risk = RISK_CONFIG[feature.risk_level] || RISK_CONFIG.low;
              const RiskIcon = risk.icon;
              const isDisabledForRole = feature.risk_level === 'high' && !isHighRiskAllowed;

              return (
                <div key={feature.id}>
                  {idx > 0 && <Separator className="mb-4" />}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{feature.name}</span>
                        <Badge variant={risk.variant} className="text-xs">
                          {RiskIcon && <RiskIcon className="h-3 w-3 mr-1" />}
                          {risk.label}
                        </Badge>
                        <code className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                          {feature.key}
                        </code>
                      </div>
                      {feature.description && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {feature.description}
                        </p>
                      )}
                    </div>
                    <Switch
                      checked={feature.enabled}
                      onCheckedChange={(val) => handleToggle(feature, val)}
                      disabled={!canManage || isDisabledForRole || toggleMutation.isPending}
                    />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      ))}

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <ToggleLeft className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Функции не найдены</p>
          </CardContent>
        </Card>
      )}

      {/* Confirmation dialog */}
      <Dialog open={!!confirmDialog} onOpenChange={() => { setConfirmDialog(null); setReason(''); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {confirmDialog?.feature.risk_level === 'high' && (
                <Shield className="h-5 w-5 text-destructive" />
              )}
              Подтверждение изменения
            </DialogTitle>
            <DialogDescription>
              Вы собираетесь{' '}
              <strong>
                {confirmDialog?.newValue ? 'включить' : 'отключить'}
              </strong>{' '}
              функцию <strong>{confirmDialog?.feature.name}</strong>.
              {confirmDialog?.feature.risk_level === 'high' && (
                <span className="block mt-2 text-destructive">
                  ⚠️ Это изменение высокого риска и может повлиять на работу всей платформы.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label>Причина изменения (рекомендуется)</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Опишите причину изменения..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setConfirmDialog(null); setReason(''); }}>
              Отмена
            </Button>
            <Button
              variant={confirmDialog?.feature.risk_level === 'high' ? 'destructive' : 'default'}
              onClick={confirmToggle}
              disabled={toggleMutation.isPending}
            >
              {toggleMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Подтвердить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
