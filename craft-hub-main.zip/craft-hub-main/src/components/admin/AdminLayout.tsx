import { ReactNode, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions, PermissionCode } from '@/hooks/usePermissions';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import {
  LayoutDashboard,
  Users,
  Package,
  Shield,
  Settings,
  FileText,
  MessageSquare,
  AlertTriangle,
  Activity,
  Menu,
  LogOut,
  ChevronRight,
  Moon,
  Sun,
  Ticket,
  Gavel,
  BarChart3,
} from 'lucide-react';

interface AdminLayoutProps {
  children: ReactNode;
}

interface NavItem {
  label: string;
  href: string;
  icon: ReactNode;
  permission?: PermissionCode;
  badge?: number;
}

const navSections: { title: string; items: NavItem[] }[] = [
  {
    title: 'Обзор',
    items: [
      { label: 'Дашборд', href: '/admin', icon: <LayoutDashboard className="h-4 w-4" /> },
      { label: 'Аналитика', href: '/admin/analytics', icon: <BarChart3 className="h-4 w-4" />, permission: 'audit.view' },
    ],
  },
  {
    title: 'Управление',
    items: [
      { label: 'Пользователи', href: '/admin/users', icon: <Users className="h-4 w-4" />, permission: 'users.view' },
      { label: 'Контент', href: '/admin/content', icon: <Package className="h-4 w-4" />, permission: 'mods.view' },
      { label: 'Модерация', href: '/admin/moderation', icon: <Gavel className="h-4 w-4" />, permission: 'mods.approve' },
    ],
  },
  {
    title: 'Поддержка',
    items: [
      { label: 'Тикеты', href: '/admin/tickets', icon: <Ticket className="h-4 w-4" />, permission: 'tickets.view' },
      { label: 'Жалобы', href: '/admin/reports', icon: <AlertTriangle className="h-4 w-4" />, permission: 'reports.view' },
    ],
  },
  {
    title: 'Платформа',
    items: [
      { label: 'Настройки сайта', href: '/admin/settings', icon: <Settings className="h-4 w-4" />, permission: 'platform.settings' },
      { label: 'Юридические', href: '/admin/legal', icon: <FileText className="h-4 w-4" />, permission: 'platform.legal' },
    ],
  },
  {
    title: 'Безопасность',
    items: [
      { label: 'События', href: '/admin/security', icon: <Shield className="h-4 w-4" />, permission: 'security.view' },
      { label: 'Логи', href: '/admin/logs', icon: <Activity className="h-4 w-4" />, permission: 'audit.view' },
    ],
  },
];

const roleLabels: Record<string, { label: string; color: string }> = {
  super_admin: { label: 'Super Admin', color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  admin: { label: 'Admin', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  moderator: { label: 'Moderator', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  support: { label: 'Support', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
};

export function AdminLayout({ children }: AdminLayoutProps) {
  const { user, profile, signOut } = useAuth();
  const { role, hasPermission, canAccessAdminStudio, isLoading } = usePermissions();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('theme') as 'light' | 'dark') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    if (!isLoading && !canAccessAdminStudio()) {
      navigate('/');
    }
  }, [isLoading, canAccessAdminStudio, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!canAccessAdminStudio()) {
    return null;
  }

  const filteredNavSections = navSections
    .map(section => ({
      ...section,
      items: section.items.filter(item => !item.permission || hasPermission(item.permission)),
    }))
    .filter(section => section.items.length > 0);

  const NavContent = () => (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <Link to="/admin" className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center">
            <Shield className="h-4 w-4 text-white" />
          </div>
          <span className="font-bold text-lg">Admin Studio</span>
        </Link>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 p-4">
        <nav className="space-y-6">
          {filteredNavSections.map((section, idx) => (
            <div key={idx}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map(item => {
                  const isActive = location.pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      to={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                        isActive
                          ? 'bg-primary/10 text-primary font-medium'
                          : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                      }`}
                    >
                      {item.icon}
                      <span className="flex-1">{item.label}</span>
                      {item.badge && item.badge > 0 && (
                        <Badge variant="destructive" className="h-5 min-w-5 text-xs">
                          {item.badge}
                        </Badge>
                      )}
                      {isActive && <ChevronRight className="h-4 w-4" />}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </ScrollArea>

      {/* User section */}
      <div className="p-4 border-t border-border space-y-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={profile?.avatar || undefined} />
            <AvatarFallback>
              {profile?.display_name?.[0] || profile?.username?.[0] || 'A'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {profile?.display_name || profile?.username}
            </p>
            {role && roleLabels[role] && (
              <Badge variant="outline" className={`text-xs ${roleLabels[role].color}`}>
                {roleLabels[role].label}
              </Badge>
            )}
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          >
            {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => {
              signOut();
              navigate('/');
            }}
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>

        <Link to="/">
          <Button variant="ghost" size="sm" className="w-full">
            ← Вернуться на сайт
          </Button>
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 border-r border-border flex-col">
        <NavContent />
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Link to="/admin" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center">
              <Shield className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold">Admin</span>
          </Link>

          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <NavContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:max-h-screen lg:overflow-auto">
        <div className="pt-16 lg:pt-0">
          {children}
        </div>
      </main>
    </div>
  );
}
