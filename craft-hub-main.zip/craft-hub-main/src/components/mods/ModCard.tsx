import { Link } from 'react-router-dom';
import { Download, Eye, Star, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { CATEGORIES, LOADERS } from '@/lib/constants';
import { formatDownloads, formatTimeAgo } from '@/lib/format';
import { cn } from '@/lib/utils';
import type { ModWithAuthor } from '@/hooks/useMods';
import type { Category, Loader, Edition } from '@/lib/types';

interface ModCardProps {
  mod: ModWithAuthor;
  className?: string;
}

export function ModCard({ mod, className }: ModCardProps) {
  const categories = (mod.categories || []) as Category[];
  const loaders = (mod.loaders || []) as Loader[];
  const edition = mod.edition as Edition;
  
  const categoryData = CATEGORIES.find(c => c.id === categories[0]);
  
  return (
    <Link
      to={`/mod/${mod.slug}`}
      className={cn(
        'group block bg-card rounded-2xl border border-border overflow-hidden card-hover',
        className
      )}
    >
      {/* Card Header with Icon */}
      <div className="p-4 pb-0 flex gap-4">
        {/* Mod Icon */}
        <div className="relative flex-shrink-0">
          <img
            src={mod.icon || `https://api.dicebear.com/7.x/shapes/svg?seed=${mod.slug}`}
            alt={mod.name}
            className="w-16 h-16 rounded-xl object-cover bg-secondary group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              e.currentTarget.src = `https://api.dicebear.com/7.x/shapes/svg?seed=${mod.slug}`;
            }}
          />
          {mod.featured && (
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-accent rounded-full flex items-center justify-center">
              <Star className="w-3 h-3 text-accent-foreground fill-accent-foreground" />
            </div>
          )}
        </div>

        {/* Title and Author */}
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
            {mod.name}
          </h3>
          <p className="text-sm text-muted-foreground">
            by <span className="text-foreground/80">{mod.author?.username || 'Unknown'}</span>
          </p>
        </div>
      </div>

      {/* Description */}
      <div className="px-4 py-3">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {mod.summary}
        </p>
      </div>

      {/* Tags */}
      <div className="px-4 pb-3 flex flex-wrap gap-1.5">
        {/* Edition Badge */}
        <Badge variant={edition} size="sm">
          {edition === 'java' ? 'Java' : 'Bedrock'}
        </Badge>

        {/* Loaders */}
        {loaders.slice(0, 2).map((loader) => {
          const loaderData = LOADERS.find(l => l.id === loader);
          return (
            <Badge 
              key={loader} 
              variant={loader as any} 
              size="sm"
            >
              {loaderData?.name || loader}
            </Badge>
          );
        })}

        {/* Category */}
        {categoryData && (
          <Badge variant="category" size="sm">
            {categoryData.icon} {categoryData.name}
          </Badge>
        )}
      </div>

      {/* Stats */}
      <div className="px-4 py-3 border-t border-border/50 flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            {formatDownloads(mod.downloads || 0)}
          </span>
          <span className="flex items-center gap-1">
            <Eye className="w-3.5 h-3.5" />
            {formatDownloads(mod.views || 0)}
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-400" />
            {Number(mod.rating || 0).toFixed(1)}
          </span>
        </div>
        <span className="flex items-center gap-1">
          <Clock className="w-3.5 h-3.5" />
          {formatTimeAgo(mod.updated_at)}
        </span>
      </div>
    </Link>
  );
}
