import { useState } from 'react';
import { Search, SlidersHorizontal, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { CATEGORIES, LOADERS, MINECRAFT_VERSIONS, SORT_OPTIONS } from '@/lib/constants';
import { Edition, Category, Loader, SortOption } from '@/lib/types';
import { cn } from '@/lib/utils';

export interface FiltersState {
  search: string;
  edition: Edition | null;
  categories: Category[];
  loaders: Loader[];
  versions: string[];
  sort: SortOption;
  projectType?: string | null;
}

interface FiltersProps {
  className?: string;
  filters: FiltersState;
  onFiltersChange: (filters: FiltersState) => void;
}

export function ModFilters({ className, filters, onFiltersChange }: FiltersProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showAllCategories, setShowAllCategories] = useState(false);
  const [showAllVersions, setShowAllVersions] = useState(false);

  const updateFilters = (updates: Partial<FiltersState>) => {
    onFiltersChange({ ...filters, ...updates });
  };

  const toggleCategory = (cat: Category) => {
    const newCategories = filters.categories.includes(cat)
      ? filters.categories.filter(c => c !== cat)
      : [...filters.categories, cat];
    updateFilters({ categories: newCategories });
  };

  const toggleLoader = (loader: Loader) => {
    const newLoaders = filters.loaders.includes(loader)
      ? filters.loaders.filter(l => l !== loader)
      : [...filters.loaders, loader];
    updateFilters({ loaders: newLoaders });
  };

  const toggleVersion = (version: string) => {
    const newVersions = filters.versions.includes(version)
      ? filters.versions.filter(v => v !== version)
      : [...filters.versions, version];
    updateFilters({ versions: newVersions });
  };

  const clearFilters = () => {
    onFiltersChange({
      search: '',
      edition: null,
      categories: [],
      loaders: [],
      versions: [],
      sort: 'downloads',
      projectType: filters.projectType, // Keep projectType from URL
    });
  };

  const hasActiveFilters = filters.search || filters.edition || filters.categories.length > 0 || 
    filters.loaders.length > 0 || filters.versions.length > 0;

  const visibleCategories = showAllCategories ? CATEGORIES : CATEGORIES.slice(0, 6);
  const visibleVersions = showAllVersions ? MINECRAFT_VERSIONS : MINECRAFT_VERSIONS.slice(0, 8);

  return (
    <aside className={cn('bg-card rounded-2xl border border-border overflow-hidden', className)}>
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Фильтры</h3>
        </div>
        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
              <X className="w-4 h-4 mr-1" />
              Сбросить
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="lg:hidden"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Filters Content */}
      <div className={cn('p-4 space-y-6', !isExpanded && 'hidden lg:block')}>
        {/* Search */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Поиск</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Название мода..."
              value={filters.search}
              onChange={(e) => updateFilters({ search: e.target.value })}
              className="pl-10 rounded-xl bg-secondary/50"
            />
          </div>
        </div>

        {/* Edition */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Издание</label>
          <div className="flex gap-2">
            <Button
              variant={filters.edition === 'java' ? 'java' : 'outline'}
              size="sm"
              onClick={() => updateFilters({ edition: filters.edition === 'java' ? null : 'java' })}
              className="flex-1 rounded-xl"
            >
              Java
            </Button>
            <Button
              variant={filters.edition === 'bedrock' ? 'bedrock' : 'outline'}
              size="sm"
              onClick={() => updateFilters({ edition: filters.edition === 'bedrock' ? null : 'bedrock' })}
              className="flex-1 rounded-xl"
            >
              Bedrock
            </Button>
          </div>
        </div>

        {/* Sort */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Сортировка</label>
          <div className="flex flex-wrap gap-1.5">
            {SORT_OPTIONS.map((option) => (
              <Badge
                key={option.id}
                variant={filters.sort === option.id ? 'default' : 'category'}
                className="cursor-pointer"
                onClick={() => updateFilters({ sort: option.id })}
              >
                {option.label}
              </Badge>
            ))}
          </div>
        </div>

        {/* Loaders */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Загрузчик</label>
          <div className="flex flex-wrap gap-1.5">
            {LOADERS.map((loader) => (
              <Badge
                key={loader.id}
                variant={filters.loaders.includes(loader.id) ? (loader.id as any) : 'category'}
                className="cursor-pointer"
                onClick={() => toggleLoader(loader.id)}
              >
                {loader.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Категории</label>
          <div className="space-y-2">
            {visibleCategories.map((category) => (
              <label
                key={category.id}
                className="flex items-center gap-2 text-sm cursor-pointer group"
              >
                <Checkbox
                  checked={filters.categories.includes(category.id)}
                  onCheckedChange={() => toggleCategory(category.id)}
                  className="rounded"
                />
                <span className="text-muted-foreground group-hover:text-foreground transition-colors">
                  {category.icon} {category.name}
                </span>
              </label>
            ))}
          </div>
          {CATEGORIES.length > 6 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAllCategories(!showAllCategories)}
              className="mt-2 w-full text-muted-foreground"
            >
              {showAllCategories ? 'Свернуть' : `Показать ещё ${CATEGORIES.length - 6}`}
            </Button>
          )}
        </div>

        {/* Minecraft Versions */}
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Версия Minecraft</label>
          <div className="flex flex-wrap gap-1.5">
            {visibleVersions.map((version) => (
              <Badge
                key={version}
                variant={filters.versions.includes(version) ? 'success' : 'category'}
                className="cursor-pointer"
                onClick={() => toggleVersion(version)}
              >
                {version}
              </Badge>
            ))}
          </div>
          {MINECRAFT_VERSIONS.length > 8 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAllVersions(!showAllVersions)}
              className="mt-2 w-full text-muted-foreground"
            >
              {showAllVersions ? 'Свернуть' : `Показать ещё ${MINECRAFT_VERSIONS.length - 8}`}
            </Button>
          )}
        </div>
      </div>
    </aside>
  );
}
