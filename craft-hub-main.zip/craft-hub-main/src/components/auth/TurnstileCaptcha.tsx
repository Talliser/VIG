import { Turnstile } from '@marsidev/react-turnstile';
import { forwardRef, useImperativeHandle, useRef } from 'react';

interface TurnstileCaptchaProps {
  onSuccess: (token: string) => void;
  onError?: () => void;
  onExpire?: () => void;
}

export interface TurnstileCaptchaRef {
  reset: () => void;
}

const TurnstileCaptcha = forwardRef<TurnstileCaptchaRef, TurnstileCaptchaProps>(
  ({ onSuccess, onError, onExpire }, ref) => {
    const turnstileRef = useRef<any>(null);

    useImperativeHandle(ref, () => ({
      reset: () => {
        turnstileRef.current?.reset();
      }
    }));

    // Site key is public and safe to embed in client code
    const siteKey = '0x4AAAAAACXr9dlg7svlXYA2';

    return (
      <div className="flex justify-center">
        <Turnstile
          ref={turnstileRef}
          siteKey={siteKey}
          onSuccess={onSuccess}
          onError={onError}
          onExpire={onExpire}
          options={{
            theme: 'auto',
            size: 'normal',
          }}
        />
      </div>
    );
  }
);

TurnstileCaptcha.displayName = 'TurnstileCaptcha';

export default TurnstileCaptcha;
