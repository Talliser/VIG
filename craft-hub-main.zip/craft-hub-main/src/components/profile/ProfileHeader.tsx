import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { XPProgressBar } from './XPProgressBar';
import { BadgeDisplay } from './BadgeDisplay';
import { useFollow } from '@/hooks/useFollow';
import { useAuth } from '@/contexts/AuthContext';
import type { UserProfile } from '@/hooks/useUserProfile';
import { 
  UserPlus, UserMinus, Edit, Github, Globe, MessageCircle,
  Download, Eye, Users, UserCheck, Snowflake, Calendar, Package
} from 'lucide-react';

interface ProfileHeaderProps {
  profile: UserProfile;
  onEdit?: () => void;
}

function formatDuration(dateStr: string) {
  const created = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - created.getTime();
  const years = Math.floor(diffMs / (365.25 * 24 * 60 * 60 * 1000));
  const months = Math.floor((diffMs % (365.25 * 24 * 60 * 60 * 1000)) / (30.44 * 24 * 60 * 60 * 1000));
  
  const parts = [];
  if (years > 0) parts.push(`${years} ${years === 1 ? 'год' : years < 5 ? 'года' : 'лет'}`);
  if (months > 0) parts.push(`${months} ${months === 1 ? 'месяц' : months < 5 ? 'месяца' : 'месяцев'}`);
  return parts.length ? parts.join(' ') : 'Менее месяца';
}

const SOCIAL_ICONS: Record<string, React.ReactNode> = {
  github: <Github className="w-4 h-4" />,
  discord: <MessageCircle className="w-4 h-4" />,
  website: <Globe className="w-4 h-4" />,
};

export function ProfileHeader({ profile, onEdit }: ProfileHeaderProps) {
  const { profile: currentProfile } = useAuth();
  const isOwner = currentProfile?.id === profile.id;
  const { isFollowing, toggleFollow, isLoading: followLoading } = useFollow(profile.id);

  const hideRegistration = profile.privacy_settings?.hide_registration_date && !isOwner;
  const hideFollowers = profile.privacy_settings?.hide_followers && !isOwner;

  return (
    <div className="relative">
      {/* Banner */}
      <div className="h-48 md:h-64 rounded-2xl overflow-hidden bg-secondary relative">
        {profile.banner ? (
          <img src={profile.banner} alt="Banner" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 via-secondary to-accent/10" />
        )}
        {profile.is_frozen && (
          <div className="absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 bg-info/90 text-primary-foreground rounded-full text-xs font-medium">
            <Snowflake className="w-3.5 h-3.5" />
            Профиль заморожен
          </div>
        )}
      </div>

      {/* Avatar + Info */}
      <div className="relative px-4 md:px-6 -mt-16 md:-mt-20">
        <div className="flex flex-col md:flex-row md:items-end gap-4">
          <Avatar className="w-28 h-28 md:w-36 md:h-36 border-4 border-background shadow-lg">
            <AvatarImage src={profile.avatar || undefined} />
            <AvatarFallback className="text-3xl bg-primary/10 text-primary">
              {profile.display_name?.[0] || profile.username[0]}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 pb-2">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                {profile.display_name || profile.username}
              </h1>
              {profile.verified && (
                <Badge className="bg-primary/20 text-primary border-primary/30">
                  <UserCheck className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-muted-foreground">@{profile.username}</span>
              {profile.nickname && (
                <span className="text-muted-foreground text-sm">• {profile.nickname}</span>
              )}
            </div>
            {profile.bio && (
              <p className="text-muted-foreground mt-2 max-w-2xl">{profile.bio}</p>
            )}

            {/* Social Links */}
            {Object.keys(profile.social_links || {}).length > 0 && (
              <div className="flex items-center gap-2 mt-2">
                {Object.entries(profile.social_links).map(([key, url]) => {
                  if (!url) return null;
                  return (
                    <a
                      key={key}
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-foreground transition-colors p-1.5 rounded-md hover:bg-secondary"
                    >
                      {SOCIAL_ICONS[key] || <Globe className="w-4 h-4" />}
                    </a>
                  );
                })}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 pb-2">
            {isOwner ? (
              <Button variant="outline" onClick={onEdit} className="gap-2">
                <Edit className="w-4 h-4" />
                Редактировать
              </Button>
            ) : currentProfile ? (
              <Button
                variant={isFollowing ? 'outline' : 'default'}
                onClick={toggleFollow}
                disabled={followLoading}
                className="gap-2"
              >
                {isFollowing ? <UserMinus className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                {isFollowing ? 'Отписаться' : 'Подписаться'}
              </Button>
            ) : null}
          </div>
        </div>

        {/* Stats Bar */}
        <div className="mt-4 flex flex-wrap items-center gap-4 md:gap-6 text-sm">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Package className="w-4 h-4" />
            <span className="font-semibold text-foreground">{profile.mods_count}</span> модов
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Download className="w-4 h-4" />
            <span className="font-semibold text-foreground">{profile.total_downloads.toLocaleString()}</span> загрузок
          </div>
          {!hideFollowers && (
            <>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Users className="w-4 h-4" />
                <span className="font-semibold text-foreground">{profile.followers_count}</span> подписчиков
              </div>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Eye className="w-4 h-4" />
                <span className="font-semibold text-foreground">{profile.following_count}</span> подписок
              </div>
            </>
          )}
          {!hideRegistration && (
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              На сайте {formatDuration(profile.created_at)}
            </div>
          )}
        </div>

        {/* XP + Badges Row */}
        <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="w-full sm:max-w-xs">
            <XPProgressBar xp={profile.xp} level={profile.level} levelName={profile.level_name} />
          </div>
          {profile.badges.length > 0 && (
            <BadgeDisplay badges={profile.badges} compact />
          )}
        </div>
      </div>
    </div>
  );
}

export function ProfileHeaderSkeleton() {
  return (
    <div>
      <Skeleton className="h-48 md:h-64 rounded-2xl" />
      <div className="px-4 md:px-6 -mt-16 md:-mt-20">
        <div className="flex flex-col md:flex-row md:items-end gap-4">
          <Skeleton className="w-28 h-28 md:w-36 md:h-36 rounded-full" />
          <div className="flex-1 space-y-2 pb-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-4 w-64" />
          </div>
        </div>
      </div>
    </div>
  );
}
