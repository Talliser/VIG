import { useState, useRef } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Upload, X } from 'lucide-react';
import type { UserProfile } from '@/hooks/useUserProfile';

interface ProfileEditModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: UserProfile;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export function ProfileEditModal({ open, onOpenChange, profile }: ProfileEditModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState(profile.display_name || '');
  const [nickname, setNickname] = useState(profile.nickname || '');
  const [bio, setBio] = useState(profile.bio || '');
  const [username, setUsername] = useState(profile.username);
  const [socialLinks, setSocialLinks] = useState(profile.social_links || {});

  const uploadFile = async (file: File, bucket: string): Promise<string> => {
    if (!ALLOWED_TYPES.includes(file.type)) throw new Error('Формат файла не поддерживается (JPG, PNG, WebP)');
    if (file.size > MAX_FILE_SIZE) throw new Error('Файл слишком большой (макс. 5MB)');

    const ext = file.name.split('.').pop();
    const path = `${user!.id}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(path);
    return publicUrl;
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const updates: Record<string, any> = {
        display_name: displayName || null,
        nickname: nickname || null,
        bio: bio || null,
        social_links: socialLinks,
      };

      // Username change with cooldown check
      if (username !== profile.username) {
        updates.username = username;
      }

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', profile.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Профиль обновлён' });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      const msg = error.message?.includes('7 days')
        ? 'Имя пользователя можно менять раз в 7 дней'
        : error.message;
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    },
  });

  const handleFileUpload = async (file: File, type: 'avatar' | 'banner') => {
    try {
      const bucket = type === 'avatar' ? 'user-avatars' : 'user-banners';
      const url = await uploadFile(file, bucket);
      
      const { error } = await supabase
        .from('profiles')
        .update({ [type === 'avatar' ? 'avatar' : 'banner']: url })
        .eq('id', profile.id);

      if (error) throw error;
      
      toast({ title: `${type === 'avatar' ? 'Аватар' : 'Баннер'} обновлён` });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    } catch (err: any) {
      toast({ title: 'Ошибка загрузки', description: err.message, variant: 'destructive' });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Редактировать профиль</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Avatar Upload */}
          <div className="flex items-center gap-4">
            <Avatar className="w-20 h-20 cursor-pointer" onClick={() => avatarInputRef.current?.click()}>
              <AvatarImage src={profile.avatar || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {profile.display_name?.[0] || profile.username[0]}
              </AvatarFallback>
            </Avatar>
            <div>
              <Button variant="outline" size="sm" onClick={() => avatarInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Загрузить аватар
              </Button>
              <p className="text-xs text-muted-foreground mt-1">JPG, PNG, WebP. Макс. 5MB</p>
            </div>
            <input
              ref={avatarInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'avatar')}
            />
          </div>

          {/* Banner Upload */}
          <div>
            <Label>Баннер профиля</Label>
            <div 
              className="mt-1 h-24 rounded-lg bg-secondary border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:border-primary/50 transition-colors overflow-hidden"
              onClick={() => bannerInputRef.current?.click()}
            >
              {profile.banner ? (
                <img src={profile.banner} alt="Banner" className="w-full h-full object-cover" />
              ) : (
                <span className="text-sm text-muted-foreground">Нажмите для загрузки</span>
              )}
            </div>
            <input
              ref={bannerInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'banner')}
            />
          </div>

          {/* Username */}
          <div className="space-y-1.5">
            <Label>Имя пользователя</Label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} />
            {profile.last_username_change && (
              <p className="text-xs text-muted-foreground">
                Последнее изменение: {new Date(profile.last_username_change).toLocaleDateString('ru')}
              </p>
            )}
          </div>

          {/* Display Name */}
          <div className="space-y-1.5">
            <Label>Отображаемое имя</Label>
            <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          </div>

          {/* Nickname */}
          <div className="space-y-1.5">
            <Label>Никнейм (@)</Label>
            <Input value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="combo" />
          </div>

          {/* Bio */}
          <div className="space-y-1.5">
            <Label>Биография</Label>
            <Textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={500} rows={3} />
          </div>

          {/* Social Links */}
          <div className="space-y-2">
            <Label>Социальные ссылки</Label>
            {['github', 'discord', 'curseforge', 'modrinth', 'website'].map((key) => (
              <Input
                key={key}
                placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                value={socialLinks[key] || ''}
                onChange={(e) => setSocialLinks({ ...socialLinks, [key]: e.target.value })}
              />
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Отмена</Button>
          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
            Сохранить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
