import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield } from 'lucide-react';
import type { UserProfile } from '@/hooks/useUserProfile';

interface PrivacySettingsProps {
  profile: UserProfile;
}

export function PrivacySettings({ profile }: PrivacySettingsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState(profile.privacy_settings);

  const mutation = useMutation({
    mutationFn: async (newSettings: typeof settings) => {
      const { error } = await supabase
        .from('profiles')
        .update({ privacy_settings: newSettings })
        .eq('id', profile.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: 'Настройки приватности обновлены' });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
    onError: (error) => {
      toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    },
  });

  const toggle = (key: keyof typeof settings) => {
    const newSettings = { ...settings, [key]: !settings[key] };
    setSettings(newSettings);
    mutation.mutate(newSettings);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Shield className="w-5 h-5" />
          Приватность
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Скрыть подписчиков</Label>
          <Switch checked={settings.hide_followers} onCheckedChange={() => toggle('hide_followers')} />
        </div>
        <div className="flex items-center justify-between">
          <Label>Скрыть дату регистрации</Label>
          <Switch checked={settings.hide_registration_date} onCheckedChange={() => toggle('hide_registration_date')} />
        </div>
        <div className="flex items-center justify-between">
          <Label>Скрыть активность</Label>
          <Switch checked={settings.hide_activity} onCheckedChange={() => toggle('hide_activity')} />
        </div>
      </CardContent>
    </Card>
  );
}
