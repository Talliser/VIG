import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Star } from 'lucide-react';

const LEVEL_THRESHOLDS = [0, 100, 500, 1000];
const LEVEL_NAMES = ['Новичок', 'Кузнец идей', 'Мастер модов', 'Легенда Майнкрафта'];
const LEVEL_ICONS = ['🌱', '⚒️', '🔧', '👑'];

interface XPProgressBarProps {
  xp: number;
  level: number;
  levelName: string;
  compact?: boolean;
}

export function XPProgressBar({ xp, level, levelName, compact }: XPProgressBarProps) {
  const currentThreshold = LEVEL_THRESHOLDS[level] || 0;
  const nextThreshold = LEVEL_THRESHOLDS[level + 1] || LEVEL_THRESHOLDS[LEVEL_THRESHOLDS.length - 1];
  const isMaxLevel = level >= LEVEL_THRESHOLDS.length - 1;
  
  const progress = isMaxLevel 
    ? 100 
    : ((xp - currentThreshold) / (nextThreshold - currentThreshold)) * 100;

  if (compact) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center gap-2">
            <span className="text-lg">{LEVEL_ICONS[level] || '🌱'}</span>
            <span className="text-sm font-medium text-foreground">{levelName}</span>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{xp} XP • Уровень {level}</p>
          {!isMaxLevel && <p>До {LEVEL_NAMES[level + 1]}: {nextThreshold - xp} XP</p>}
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-lg">{LEVEL_ICONS[level] || '🌱'}</span>
          <span className="text-sm font-semibold text-foreground">{levelName}</span>
        </div>
        <span className="text-xs text-muted-foreground">
          {xp} XP {!isMaxLevel && `/ ${nextThreshold}`}
        </span>
      </div>
      <Progress value={progress} className="h-2" />
      {!isMaxLevel && (
        <p className="text-xs text-muted-foreground">
          До «{LEVEL_NAMES[level + 1]}»: {nextThreshold - xp} XP
        </p>
      )}
    </div>
  );
}
