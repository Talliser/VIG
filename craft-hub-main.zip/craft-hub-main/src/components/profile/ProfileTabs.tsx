import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ModCard } from '@/components/mods/ModCard';
import { BadgeDisplay } from './BadgeDisplay';
import { formatDate, formatTimeAgo } from '@/lib/format';
import type { UserProfile } from '@/hooks/useUserProfile';
import { Package, MessageCircle, Award, Activity } from 'lucide-react';

interface ProfileTabsProps {
  profile: UserProfile;
}

export function ProfileTabs({ profile }: ProfileTabsProps) {
  // Fetch user's published mods
  const { data: mods = [] } = useQuery({
    queryKey: ['user-mods', profile.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('mods')
        .select('*, author:profiles!mods_author_id_fkey(username, display_name, avatar)')
        .eq('author_id', profile.id)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });
      return data || [];
    },
  });

  // Fetch user's comments
  const { data: comments = [] } = useQuery({
    queryKey: ['user-comments', profile.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('comments')
        .select('*, mod:mods!comments_mod_id_fkey(name, slug)')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(20);
      return data || [];
    },
  });

  return (
    <Tabs defaultValue="mods" className="mt-6">
      <TabsList className="w-full justify-start bg-secondary/50 overflow-x-auto">
        <TabsTrigger value="mods" className="gap-1.5">
          <Package className="w-4 h-4" />
          Моды ({profile.mods_count})
        </TabsTrigger>
        <TabsTrigger value="comments" className="gap-1.5">
          <MessageCircle className="w-4 h-4" />
          Комментарии
        </TabsTrigger>
        <TabsTrigger value="badges" className="gap-1.5">
          <Award className="w-4 h-4" />
          Бейджи ({profile.badges.length})
        </TabsTrigger>
        <TabsTrigger value="activity" className="gap-1.5">
          <Activity className="w-4 h-4" />
          Активность
        </TabsTrigger>
      </TabsList>

      <TabsContent value="mods">
        {mods.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Пока нет опубликованных модов</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {mods.map((mod: any) => (
              <ModCard key={mod.id} mod={mod} />
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="comments">
        {comments.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Нет комментариев</p>
          </div>
        ) : (
          <div className="space-y-3 mt-4">
            {comments.map((comment: any) => (
              <div key={comment.id} className="p-4 rounded-lg bg-card border border-border">
                <div className="flex items-center justify-between mb-2">
                  <a href={`/mod/${comment.mod?.slug}`} className="text-sm font-medium text-primary hover:underline">
                    {comment.mod?.name || 'Неизвестный мод'}
                  </a>
                  <span className="text-xs text-muted-foreground">{formatTimeAgo(comment.created_at)}</span>
                </div>
                <p className="text-sm text-foreground">{comment.content}</p>
              </div>
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="badges">
        {profile.badges.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Award className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Нет бейджей</p>
          </div>
        ) : (
          <div className="mt-4">
            <BadgeDisplay badges={profile.badges} />
          </div>
        )}
      </TabsContent>

      <TabsContent value="activity">
        <div className="text-center py-12 text-muted-foreground">
          <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Активность пока недоступна</p>
        </div>
      </TabsContent>
    </Tabs>
  );
}
