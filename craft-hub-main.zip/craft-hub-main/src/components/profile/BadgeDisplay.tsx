import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/format';
import type { Badge as BadgeType } from '@/hooks/useUserProfile';

interface BadgeDisplayProps {
  badges: BadgeType[];
  compact?: boolean;
}

const DEFAULT_ICONS: Record<string, string> = {
  top_creator: '🏆',
  verified_modder: '✅',
  beta_tester: '🧪',
  community_helper: '🤝',
  trusted_author: '⭐',
};

export function BadgeDisplay({ badges, compact }: BadgeDisplayProps) {
  if (!badges.length) return null;

  if (compact) {
    return (
      <div className="flex flex-wrap gap-1">
        {badges.slice(0, 5).map((badge) => (
          <Tooltip key={badge.id}>
            <TooltipTrigger asChild>
              <span className="text-lg cursor-default hover:scale-125 transition-transform">
                {badge.badge_icon || DEFAULT_ICONS[badge.badge_key] || '🎖️'}
              </span>
            </TooltipTrigger>
            <TooltipContent>
              <p className="font-semibold">{badge.badge_name}</p>
              {badge.badge_description && <p className="text-xs">{badge.badge_description}</p>}
              <p className="text-xs text-muted-foreground mt-1">
                Получен {formatDate(badge.awarded_at)}
              </p>
            </TooltipContent>
          </Tooltip>
        ))}
        {badges.length > 5 && (
          <span className="text-xs text-muted-foreground self-center">+{badges.length - 5}</span>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {badges.map((badge) => (
        <div key={badge.id} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50 border border-border">
          <span className="text-2xl">{badge.badge_icon || DEFAULT_ICONS[badge.badge_key] || '🎖️'}</span>
          <div>
            <p className="font-semibold text-sm">{badge.badge_name}</p>
            {badge.badge_description && (
              <p className="text-xs text-muted-foreground">{badge.badge_description}</p>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Получен {formatDate(badge.awarded_at)}
            </p>
            {badge.expires_at && (
              <Badge variant="outline" className="mt-1 text-xs">
                До {formatDate(badge.expires_at)}
              </Badge>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
