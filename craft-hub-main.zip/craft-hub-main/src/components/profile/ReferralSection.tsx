import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Gift, Copy, Users } from 'lucide-react';
import type { UserProfile } from '@/hooks/useUserProfile';

interface ReferralSectionProps {
  profile: UserProfile;
}

export function ReferralSection({ profile }: ReferralSectionProps) {
  const { toast } = useToast();
  const referralLink = `${window.location.origin}/auth?ref=${profile.referral_code}`;

  const { data: referralCount = 0 } = useQuery({
    queryKey: ['referral-count', profile.id],
    queryFn: async () => {
      const { count } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('referred_by', profile.id);
      return count || 0;
    },
  });

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({ title: 'Ссылка скопирована!' });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Gift className="w-5 h-5" />
          Реферальная программа
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input value={referralLink} readOnly className="font-mono text-xs" />
          <Button variant="outline" size="icon" onClick={copyLink}>
            <Copy className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Users className="w-4 h-4" />
          Приглашено: <span className="font-semibold text-foreground">{referralCount}</span>
        </div>
      </CardContent>
    </Card>
  );
}
