import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Star, Send, Loader2, Reply, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useComments, useAddComment, useDeleteComment, type CommentWithUser } from '@/hooks/useComments';
import { formatTimeAgo } from '@/lib/format';
import { cn } from '@/lib/utils';

interface CommentSectionProps {
  modId: string;
}

export function CommentSection({ modId }: CommentSectionProps) {
  const { user, profile } = useAuth();
  const { data: comments, isLoading } = useComments(modId);
  const addComment = useAddComment();
  const deleteComment = useDeleteComment();

  const [newComment, setNewComment] = useState('');
  const [rating, setRating] = useState<number | null>(null);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');

  const handleSubmitComment = async () => {
    if (!newComment.trim() || !profile?.id) return;

    await addComment.mutateAsync({
      modId,
      userId: profile.id,
      content: newComment.trim(),
      rating: rating ?? undefined,
    });

    setNewComment('');
    setRating(null);
  };

  const handleSubmitReply = async (parentId: string) => {
    if (!replyContent.trim() || !profile?.id) return;

    await addComment.mutateAsync({
      modId,
      userId: profile.id,
      content: replyContent.trim(),
      parentId,
    });

    setReplyContent('');
    setReplyTo(null);
  };

  const handleDeleteComment = async (commentId: string) => {
    if (confirm('Удалить комментарий?')) {
      await deleteComment.mutateAsync({ commentId, modId });
    }
  };

  const renderComment = (comment: CommentWithUser, isReply = false) => {
    const isOwner = profile?.id === comment.user_id;

    return (
      <div
        key={comment.id}
        className={cn(
          'flex gap-4',
          isReply && 'ml-12 mt-4'
        )}
      >
        <Avatar className="w-10 h-10 flex-shrink-0">
          <AvatarImage src={comment.user?.avatar || undefined} />
          <AvatarFallback>
            {comment.user?.display_name?.[0] || comment.user?.username?.[0] || '?'}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-foreground">
              {comment.user?.display_name || comment.user?.username || 'Пользователь'}
            </span>
            <span className="text-xs text-muted-foreground">
              {formatTimeAgo(comment.created_at)}
            </span>
            {comment.rating && (
              <div className="flex items-center gap-0.5 text-amber-400">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={cn(
                      'w-3 h-3',
                      i < comment.rating! ? 'fill-current' : 'fill-none opacity-30'
                    )}
                  />
                ))}
              </div>
            )}
          </div>

          <p className="text-foreground/90 whitespace-pre-wrap break-words">
            {comment.content}
          </p>

          <div className="flex items-center gap-2 mt-2">
            {user && !isReply && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
              >
                <Reply className="w-3 h-3 mr-1" />
                Ответить
              </Button>
            )}
            {isOwner && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs text-destructive hover:text-destructive"
                onClick={() => handleDeleteComment(comment.id)}
              >
                <Trash2 className="w-3 h-3 mr-1" />
                Удалить
              </Button>
            )}
          </div>

          {/* Reply form */}
          {replyTo === comment.id && (
            <div className="mt-3 flex gap-2">
              <Textarea
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Написать ответ..."
                rows={2}
                className="flex-1"
              />
              <Button
                size="icon"
                onClick={() => handleSubmitReply(comment.id)}
                disabled={!replyContent.trim() || addComment.isPending}
              >
                {addComment.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          )}

          {/* Replies */}
          {comment.replies && comment.replies.length > 0 && (
            <div className="space-y-4 mt-4">
              {comment.replies.map((reply) => renderComment(reply, true))}
            </div>
          )}
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Comment form - only for authenticated users */}
      {user ? (
        <div className="space-y-4">
          <div className="flex gap-4">
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarImage src={profile?.avatar || undefined} />
              <AvatarFallback>
                {profile?.display_name?.[0] || profile?.username?.[0] || '?'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-3">
              {/* Rating selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Оценка:</span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRating(rating === star ? null : star)}
                      className="p-0.5"
                    >
                      <Star
                        className={cn(
                          'w-5 h-5 transition-colors',
                          rating && star <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-muted-foreground hover:text-amber-400'
                        )}
                      />
                    </button>
                  ))}
                </div>
                {rating && (
                  <button
                    onClick={() => setRating(null)}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Сбросить
                  </button>
                )}
              </div>

              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Написать комментарий..."
                rows={3}
              />

              <div className="flex justify-end">
                <Button
                  onClick={handleSubmitComment}
                  disabled={!newComment.trim() || addComment.isPending}
                >
                  {addComment.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Отправить
                </Button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-8 bg-secondary/30 rounded-xl">
          <MessageCircle className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-foreground font-medium mb-2">
            Войдите, чтобы оставить комментарий
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            Делитесь своим мнением о моде
          </p>
          <Button asChild>
            <Link to="/auth">Войти</Link>
          </Button>
        </div>
      )}

      {/* Comments list */}
      {comments && comments.length > 0 ? (
        <div className="space-y-6">
          {comments.map((comment) => renderComment(comment))}
        </div>
      ) : (
        <div className="text-center py-8">
          <MessageCircle className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-foreground font-medium">Комментариев пока нет</p>
          <p className="text-sm text-muted-foreground">
            Будьте первым, кто оставит отзыв!
          </p>
        </div>
      )}
    </div>
  );
}
