import { useCallback, useState } from 'react';
import { Upload, X, Image, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onUpload: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  maxSize?: number; // in MB
  preview?: string | null;
  onRemove?: () => void;
  className?: string;
  label?: string;
  hint?: string;
  isUploading?: boolean;
}

export function FileUpload({
  onUpload,
  accept = 'image/*',
  multiple = false,
  maxSize = 5,
  preview,
  onRemove,
  className,
  label = 'Загрузить файл',
  hint,
  isUploading = false,
}: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const validateFiles = (files: File[]): File[] => {
    const validFiles: File[] = [];
    
    for (const file of files) {
      if (file.size > maxSize * 1024 * 1024) {
        setError(`Файл ${file.name} превышает ${maxSize}MB`);
        continue;
      }
      validFiles.push(file);
    }

    return validFiles;
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);

    const files = Array.from(e.dataTransfer.files);
    const validFiles = validateFiles(files);
    
    if (validFiles.length > 0) {
      onUpload(multiple ? validFiles : [validFiles[0]]);
    }
  }, [onUpload, multiple, maxSize]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const files = Array.from(e.target.files || []);
    const validFiles = validateFiles(files);
    
    if (validFiles.length > 0) {
      onUpload(multiple ? validFiles : [validFiles[0]]);
    }
    
    // Reset input
    e.target.value = '';
  };

  if (preview) {
    return (
      <div className={cn('relative rounded-xl overflow-hidden', className)}>
        <img
          src={preview}
          alt="Preview"
          className="w-full h-full object-cover"
        />
        {onRemove && (
          <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2"
            onClick={onRemove}
            disabled={isUploading}
          >
            <X className="w-4 h-4" />
          </Button>
        )}
        {isUploading && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-white" />
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={className}>
      <label
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          'flex flex-col items-center justify-center w-full h-full min-h-[120px] rounded-xl border-2 border-dashed cursor-pointer transition-colors',
          isDragging
            ? 'border-primary bg-primary/10'
            : 'border-border hover:border-primary/50 hover:bg-secondary/50',
          isUploading && 'pointer-events-none opacity-50'
        )}
      >
        <input
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleFileSelect}
          className="hidden"
          disabled={isUploading}
        />
        
        {isUploading ? (
          <Loader2 className="w-8 h-8 animate-spin text-primary mb-2" />
        ) : (
          <div className="flex flex-col items-center p-4">
            <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center mb-3">
              <Image className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">{label}</p>
            <p className="text-xs text-muted-foreground text-center">
              {hint || `Перетащите или выберите файл (макс. ${maxSize}MB)`}
            </p>
          </div>
        )}
      </label>
      
      {error && (
        <p className="text-xs text-destructive mt-2">{error}</p>
      )}
    </div>
  );
}
