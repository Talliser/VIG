import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedAdminRoute } from "@/components/admin/ProtectedAdminRoute";
import Index from "./pages/Index";
import ModsPage from "./pages/ModsPage";
import ModDetailPage from "./pages/ModDetailPage";
import AuthPage from "./pages/AuthPage";
import StudioDashboard from "./pages/studio/StudioDashboard";
import StudioMods from "./pages/studio/StudioMods";
import StudioUpload from "./pages/studio/StudioUpload";
import StudioComments from "./pages/studio/StudioComments";
import StudioAnalytics from "./pages/studio/StudioAnalytics";
import StudioSettings from "./pages/studio/StudioSettings";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminModeration from "./pages/admin/AdminModeration";
import AdminReports from "./pages/admin/AdminReports";
import AdminTickets from "./pages/admin/AdminTickets";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminLogs from "./pages/admin/AdminLogs";
import AdminSecurity from "./pages/admin/AdminSecurity";
import AdminLegal from "./pages/admin/AdminLegal";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import NotFound from "./pages/NotFound";
import SetupPage from "./pages/SetupPage";
import UserProfilePage from "./pages/UserProfilePage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Index />} />
            <Route path="/mods" element={<ModsPage />} />
            <Route path="/mod/:slug" element={<ModDetailPage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/setup" element={<SetupPage />} />
            <Route path="/user/:username" element={<UserProfilePage />} />
            
            {/* Author Studio routes */}
            <Route path="/studio" element={<StudioDashboard />} />
            <Route path="/studio/mods" element={<StudioMods />} />
            <Route path="/studio/upload" element={<StudioUpload />} />
            <Route path="/studio/comments" element={<StudioComments />} />
            <Route path="/studio/analytics" element={<StudioAnalytics />} />
            <Route path="/studio/settings" element={<StudioSettings />} />
            
            {/* Admin Studio routes - Protected with permission checks */}
            <Route 
              path="/admin" 
              element={
                <ProtectedAdminRoute requiredPermission="admin.dashboard">
                  <AdminDashboard />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/users" 
              element={
                <ProtectedAdminRoute requiredPermission="users.view">
                  <AdminUsers />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/moderation" 
              element={
                <ProtectedAdminRoute requiredPermission="mods.view">
                  <AdminModeration />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/content" 
              element={
                <ProtectedAdminRoute requiredPermission="mods.view">
                  <AdminModeration />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/reports" 
              element={
                <ProtectedAdminRoute requiredPermission="reports.view">
                  <AdminReports />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/tickets" 
              element={
                <ProtectedAdminRoute requiredPermission="tickets.view">
                  <AdminTickets />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/settings" 
              element={
                <ProtectedAdminRoute requiredPermission="platform.settings">
                  <AdminSettings />
                </ProtectedAdminRoute>
              } 
            />
            {/* Categories moved to Settings tab */}
            <Route 
              path="/admin/logs" 
              element={
                <ProtectedAdminRoute requiredPermission="audit.view">
                  <AdminLogs />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/security" 
              element={
                <ProtectedAdminRoute requiredPermission="security.view">
                  <AdminSecurity />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/legal" 
              element={
                <ProtectedAdminRoute requiredPermission="platform.legal">
                  <AdminLegal />
                </ProtectedAdminRoute>
              } 
            />
            <Route 
              path="/admin/analytics" 
              element={
                <ProtectedAdminRoute requiredPermission="audit.view">
                  <AdminAnalytics />
                </ProtectedAdminRoute>
              } 
            />
            
            {/* 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
