export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      admin_logs: {
        Row: {
          action: string
          admin_id: string
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: []
      }
      auth_rate_limits: {
        Row: {
          action_type: string
          attempt_count: number
          created_at: string
          id: string
          ip_hash: string
          window_start: string
        }
        Insert: {
          action_type: string
          attempt_count?: number
          created_at?: string
          id?: string
          ip_hash: string
          window_start?: string
        }
        Update: {
          action_type?: string
          attempt_count?: number
          created_at?: string
          id?: string
          ip_hash?: string
          window_start?: string
        }
        Relationships: []
      }
      comments: {
        Row: {
          content: string
          created_at: string
          id: string
          likes: number | null
          mod_id: string
          parent_id: string | null
          rating: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          likes?: number | null
          mod_id: string
          parent_id?: string | null
          rating?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          likes?: number | null
          mod_id?: string
          parent_id?: string | null
          rating?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comments_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "comments_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "comments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      download_logs: {
        Row: {
          created_at: string
          id: string
          ip_hash: string | null
          mod_id: string
          user_id: string | null
          version_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          mod_id: string
          user_id?: string | null
          version_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          mod_id?: string
          user_id?: string | null
          version_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "download_logs_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "download_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "download_logs_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "mod_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      favorites: {
        Row: {
          created_at: string
          id: string
          mod_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mod_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mod_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "favorites_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_document_versions: {
        Row: {
          change_summary: string | null
          content: string
          created_at: string
          created_by: string
          document_id: string
          effective_date: string
          id: string
          slug: string
          title: string
          version: number
        }
        Insert: {
          change_summary?: string | null
          content: string
          created_at?: string
          created_by: string
          document_id: string
          effective_date: string
          id?: string
          slug: string
          title: string
          version: number
        }
        Update: {
          change_summary?: string | null
          content?: string
          created_at?: string
          created_by?: string
          document_id?: string
          effective_date?: string
          id?: string
          slug?: string
          title?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "legal_document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "legal_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      legal_documents: {
        Row: {
          content: string
          created_at: string
          created_by: string
          effective_date: string
          id: string
          is_active: boolean
          slug: string
          title: string
          version: number
        }
        Insert: {
          content: string
          created_at?: string
          created_by: string
          effective_date?: string
          id?: string
          is_active?: boolean
          slug: string
          title: string
          version?: number
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          effective_date?: string
          id?: string
          is_active?: boolean
          slug?: string
          title?: string
          version?: number
        }
        Relationships: []
      }
      mod_versions: {
        Row: {
          changelog: string | null
          created_at: string
          downloads: number | null
          file_size: string | null
          file_url: string | null
          id: string
          loaders: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions: string[] | null
          mod_id: string
          release_date: string
          version: string
        }
        Insert: {
          changelog?: string | null
          created_at?: string
          downloads?: number | null
          file_size?: string | null
          file_url?: string | null
          id?: string
          loaders?: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions?: string[] | null
          mod_id: string
          release_date?: string
          version: string
        }
        Update: {
          changelog?: string | null
          created_at?: string
          downloads?: number | null
          file_size?: string | null
          file_url?: string | null
          id?: string
          loaders?: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions?: string[] | null
          mod_id?: string
          release_date?: string
          version?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_versions_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      mods: {
        Row: {
          author_id: string | null
          banner: string | null
          categories: Database["public"]["Enums"]["category"][] | null
          created_at: string
          description: string
          downloads: number
          edition: Database["public"]["Enums"]["edition"]
          featured: boolean | null
          gallery: string[] | null
          icon: string | null
          id: string
          loaders: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions: string[] | null
          name: string
          primary_file_size: string | null
          primary_file_url: string | null
          project_type: string
          rating: number | null
          rating_count: number | null
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          slug: string
          status: string | null
          summary: string
          tags: string[] | null
          updated_at: string
          views: number
        }
        Insert: {
          author_id?: string | null
          banner?: string | null
          categories?: Database["public"]["Enums"]["category"][] | null
          created_at?: string
          description: string
          downloads?: number
          edition?: Database["public"]["Enums"]["edition"]
          featured?: boolean | null
          gallery?: string[] | null
          icon?: string | null
          id?: string
          loaders?: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions?: string[] | null
          name: string
          primary_file_size?: string | null
          primary_file_url?: string | null
          project_type?: string
          rating?: number | null
          rating_count?: number | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          slug: string
          status?: string | null
          summary: string
          tags?: string[] | null
          updated_at?: string
          views?: number
        }
        Update: {
          author_id?: string | null
          banner?: string | null
          categories?: Database["public"]["Enums"]["category"][] | null
          created_at?: string
          description?: string
          downloads?: number
          edition?: Database["public"]["Enums"]["edition"]
          featured?: boolean | null
          gallery?: string[] | null
          icon?: string | null
          id?: string
          loaders?: Database["public"]["Enums"]["loader"][] | null
          minecraft_versions?: string[] | null
          name?: string
          primary_file_size?: string | null
          primary_file_url?: string | null
          project_type?: string
          rating?: number | null
          rating_count?: number | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          slug?: string
          status?: string | null
          summary?: string
          tags?: string[] | null
          updated_at?: string
          views?: number
        }
        Relationships: [
          {
            foreignKeyName: "mods_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          archived_at: string | null
          created_at: string
          id: string
          is_read: boolean
          link: string | null
          message: string
          metadata: Json | null
          priority: string
          read_at: string | null
          requires_action: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          archived_at?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          link?: string | null
          message: string
          metadata?: Json | null
          priority?: string
          read_at?: string | null
          requires_action?: boolean
          title: string
          type: string
          user_id: string
        }
        Update: {
          archived_at?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          link?: string | null
          message?: string
          metadata?: Json | null
          priority?: string
          read_at?: string | null
          requires_action?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      password_reset_codes: {
        Row: {
          code: string
          created_at: string
          email: string
          expires_at: string
          id: string
          ip_hash: string | null
          used: boolean
        }
        Insert: {
          code: string
          created_at?: string
          email: string
          expires_at: string
          id?: string
          ip_hash?: string | null
          used?: boolean
        }
        Update: {
          code?: string
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          ip_hash?: string | null
          used?: boolean
        }
        Relationships: []
      }
      permissions: {
        Row: {
          category: string
          code: string
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          category: string
          code: string
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      platform_feature_history: {
        Row: {
          change_reason: string | null
          changed_by: string
          created_at: string
          feature_id: string
          feature_key: string
          id: string
          new_value: boolean
          old_value: boolean
        }
        Insert: {
          change_reason?: string | null
          changed_by: string
          created_at?: string
          feature_id: string
          feature_key: string
          id?: string
          new_value: boolean
          old_value: boolean
        }
        Update: {
          change_reason?: string | null
          changed_by?: string
          created_at?: string
          feature_id?: string
          feature_key?: string
          id?: string
          new_value?: boolean
          old_value?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "platform_feature_history_feature_id_fkey"
            columns: ["feature_id"]
            isOneToOne: false
            referencedRelation: "platform_features"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_features: {
        Row: {
          category: string
          created_at: string
          default_value: boolean
          description: string | null
          enabled: boolean
          id: string
          key: string
          metadata: Json | null
          name: string
          requires_confirmation: boolean
          risk_level: string
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          default_value?: boolean
          description?: string | null
          enabled?: boolean
          id?: string
          key: string
          metadata?: Json | null
          name: string
          requires_confirmation?: boolean
          risk_level?: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          default_value?: boolean
          description?: string | null
          enabled?: boolean
          id?: string
          key?: string
          metadata?: Json | null
          name?: string
          requires_confirmation?: boolean
          risk_level?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar: string | null
          banner: string | null
          bio: string | null
          created_at: string
          display_name: string | null
          freeze_reason: string | null
          frozen_at: string | null
          frozen_by: string | null
          id: string
          is_frozen: boolean | null
          last_username_change: string | null
          level: number | null
          level_name: string | null
          nickname: string | null
          privacy_settings: Json | null
          referral_code: string | null
          referred_by: string | null
          social_links: Json | null
          updated_at: string
          user_id: string | null
          username: string
          verified: boolean | null
          xp: number | null
        }
        Insert: {
          avatar?: string | null
          banner?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          freeze_reason?: string | null
          frozen_at?: string | null
          frozen_by?: string | null
          id?: string
          is_frozen?: boolean | null
          last_username_change?: string | null
          level?: number | null
          level_name?: string | null
          nickname?: string | null
          privacy_settings?: Json | null
          referral_code?: string | null
          referred_by?: string | null
          social_links?: Json | null
          updated_at?: string
          user_id?: string | null
          username: string
          verified?: boolean | null
          xp?: number | null
        }
        Update: {
          avatar?: string | null
          banner?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          freeze_reason?: string | null
          frozen_at?: string | null
          frozen_by?: string | null
          id?: string
          is_frozen?: boolean | null
          last_username_change?: string | null
          level?: number | null
          level_name?: string | null
          nickname?: string | null
          privacy_settings?: Json | null
          referral_code?: string | null
          referred_by?: string | null
          social_links?: Json | null
          updated_at?: string
          user_id?: string | null
          username?: string
          verified?: boolean | null
          xp?: number | null
        }
        Relationships: []
      }
      project_types: {
        Row: {
          created_at: string
          description: string | null
          enabled: boolean
          icon: string | null
          id: string
          name: string
          name_plural: string
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          name: string
          name_plural: string
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          name?: string
          name_plural?: string
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          description: string | null
          id: string
          reason: string
          reporter_id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          target_id: string
          target_type: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          reason: string
          reporter_id: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id: string
          target_type: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          reason?: string
          reporter_id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id?: string
          target_type?: string
        }
        Relationships: []
      }
      role_permissions: {
        Row: {
          created_at: string
          id: string
          permission_id: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          id?: string
          permission_id: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          id?: string
          permission_id?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_permission_id_fkey"
            columns: ["permission_id"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["id"]
          },
        ]
      }
      security_events: {
        Row: {
          created_at: string
          details: Json | null
          event_type: string
          id: string
          ip_address: string | null
          severity: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          details?: Json | null
          event_type: string
          id?: string
          ip_address?: string | null
          severity?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          details?: Json | null
          event_type?: string
          id?: string
          ip_address?: string | null
          severity?: string
          user_id?: string | null
        }
        Relationships: []
      }
      site_block_history: {
        Row: {
          block_id: string
          change_reason: string | null
          changed_by: string
          created_at: string
          id: string
          new_config: Json | null
          new_visible: boolean | null
          old_config: Json | null
          old_visible: boolean | null
        }
        Insert: {
          block_id: string
          change_reason?: string | null
          changed_by: string
          created_at?: string
          id?: string
          new_config?: Json | null
          new_visible?: boolean | null
          old_config?: Json | null
          old_visible?: boolean | null
        }
        Update: {
          block_id?: string
          change_reason?: string | null
          changed_by?: string
          created_at?: string
          id?: string
          new_config?: Json | null
          new_visible?: boolean | null
          old_config?: Json | null
          old_visible?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "site_block_history_block_id_fkey"
            columns: ["block_id"]
            isOneToOne: false
            referencedRelation: "site_blocks"
            referencedColumns: ["id"]
          },
        ]
      }
      site_blocks: {
        Row: {
          block_type: string
          config: Json
          created_at: string
          description: string | null
          id: string
          key: string
          name: string
          page_id: string
          sort_order: number
          status: string
          updated_at: string
          visibility_roles: string[]
          visible: boolean
        }
        Insert: {
          block_type?: string
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          key: string
          name: string
          page_id: string
          sort_order?: number
          status?: string
          updated_at?: string
          visibility_roles?: string[]
          visible?: boolean
        }
        Update: {
          block_type?: string
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          name?: string
          page_id?: string
          sort_order?: number
          status?: string
          updated_at?: string
          visibility_roles?: string[]
          visible?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "site_blocks_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "site_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      site_pages: {
        Row: {
          created_at: string
          description: string | null
          enabled: boolean
          icon: string | null
          id: string
          key: string
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          key: string
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          key?: string
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      ticket_messages: {
        Row: {
          created_at: string
          id: string
          is_internal: boolean
          message: string
          ticket_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_internal?: boolean
          message: string
          ticket_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_internal?: boolean
          message?: string
          ticket_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ticket_messages_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      tickets: {
        Row: {
          assigned_to: string | null
          category: string
          created_at: string
          description: string
          id: string
          priority: string
          resolved_at: string | null
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          category?: string
          created_at?: string
          description: string
          id?: string
          priority?: string
          resolved_at?: string | null
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          category?: string
          created_at?: string
          description?: string
          id?: string
          priority?: string
          resolved_at?: string | null
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_appeals: {
        Row: {
          created_at: string
          id: string
          message: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          target_id: string | null
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id?: string | null
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id?: string | null
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_appeals_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_badges: {
        Row: {
          awarded_at: string
          awarded_by: string | null
          badge_description: string | null
          badge_icon: string | null
          badge_key: string
          badge_name: string
          expires_at: string | null
          id: string
          is_auto: boolean | null
          profile_id: string
        }
        Insert: {
          awarded_at?: string
          awarded_by?: string | null
          badge_description?: string | null
          badge_icon?: string | null
          badge_key: string
          badge_name: string
          expires_at?: string | null
          id?: string
          is_auto?: boolean | null
          profile_id: string
        }
        Update: {
          awarded_at?: string
          awarded_by?: string | null
          badge_description?: string | null
          badge_icon?: string | null
          badge_key?: string
          badge_name?: string
          expires_at?: string | null
          id?: string
          is_auto?: boolean | null
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_badges_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_bans: {
        Row: {
          ban_type: string
          banned_by: string
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          reason: string
          user_id: string
        }
        Insert: {
          ban_type?: string
          banned_by: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason: string
          user_id: string
        }
        Update: {
          ban_type?: string
          banned_by?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      user_follows: {
        Row: {
          created_at: string
          follower_id: string
          following_id: string
          id: string
        }
        Insert: {
          created_at?: string
          follower_id: string
          following_id: string
          id?: string
        }
        Update: {
          created_at?: string
          follower_id?: string
          following_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_follows_follower_id_fkey"
            columns: ["follower_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_follows_following_id_fkey"
            columns: ["following_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_login_history: {
        Row: {
          created_at: string
          id: string
          ip_hash: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          ip_hash?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_notification_settings: {
        Row: {
          analytics_enabled: boolean
          analytics_frequency: string
          created_at: string
          email_enabled: boolean
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          analytics_enabled?: boolean
          analytics_frequency?: string
          created_at?: string
          email_enabled?: boolean
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          analytics_enabled?: boolean
          analytics_frequency?: string
          created_at?: string
          email_enabled?: boolean
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_notification_settings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_warnings: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          issued_by: string
          reason: string
          severity: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          issued_by: string
          reason: string
          severity?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          issued_by?: string
          reason?: string
          severity?: string
          user_id?: string
        }
        Relationships: []
      }
      user_xp_log: {
        Row: {
          amount: number
          created_at: string
          id: string
          profile_id: string
          reason: string
          source_id: string | null
          source_type: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          profile_id: string
          reason: string
          source_id?: string | null
          source_type?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          profile_id?: string
          reason?: string
          source_id?: string | null
          source_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_xp_log_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      archive_old_notifications: { Args: never; Returns: undefined }
      award_xp: {
        Args: {
          _amount: number
          _profile_id: string
          _reason: string
          _source_id?: string
          _source_type?: string
        }
        Returns: undefined
      }
      calculate_level: { Args: { xp_value: number }; Returns: number }
      can_bootstrap_super_admin: { Args: never; Returns: boolean }
      cleanup_expired_reset_codes: { Args: never; Returns: undefined }
      create_broadcast_notification: {
        Args: {
          _link?: string
          _message: string
          _priority: string
          _requires_action?: boolean
          _title: string
          _type: string
        }
        Returns: number
      }
      get_level_name: { Args: { level_value: number }; Returns: string }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_permission: {
        Args: { _permission_code: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hash_ip: { Args: { ip_text: string }; Returns: string }
      increment_download_count: {
        Args: { mod_id_param: string; version_id_param?: string }
        Returns: undefined
      }
      increment_view_count: {
        Args: { mod_id_param: string }
        Returns: undefined
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      log_admin_action: {
        Args: {
          _action: string
          _details?: Json
          _target_id?: string
          _target_type?: string
        }
        Returns: string
      }
      rollback_platform_feature: {
        Args: { _history_id: string }
        Returns: boolean
      }
      toggle_platform_feature: {
        Args: { _feature_key: string; _new_value: boolean; _reason?: string }
        Returns: boolean
      }
      update_site_block: {
        Args: {
          _block_id: string
          _config?: Json
          _name?: string
          _reason?: string
          _sort_order?: number
          _visible?: boolean
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "user"
        | "author"
        | "moderator"
        | "admin"
        | "super_admin"
        | "support"
      category:
        | "adventure"
        | "decoration"
        | "economy"
        | "equipment"
        | "food"
        | "library"
        | "magic"
        | "management"
        | "minigame"
        | "mobs"
        | "optimization"
        | "social"
        | "storage"
        | "technology"
        | "transportation"
        | "utility"
        | "worldgen"
      edition: "java" | "bedrock"
      loader:
        | "fabric"
        | "forge"
        | "neoforge"
        | "quilt"
        | "liteloader"
        | "rift"
        | "modloader"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "user",
        "author",
        "moderator",
        "admin",
        "super_admin",
        "support",
      ],
      category: [
        "adventure",
        "decoration",
        "economy",
        "equipment",
        "food",
        "library",
        "magic",
        "management",
        "minigame",
        "mobs",
        "optimization",
        "social",
        "storage",
        "technology",
        "transportation",
        "utility",
        "worldgen",
      ],
      edition: ["java", "bedrock"],
      loader: [
        "fabric",
        "forge",
        "neoforge",
        "quilt",
        "liteloader",
        "rift",
        "modloader",
      ],
    },
  },
} as const
