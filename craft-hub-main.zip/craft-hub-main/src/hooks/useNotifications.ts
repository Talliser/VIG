import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Notification {
  id: string;
  user_id: string;
  type: 'legal' | 'analytics' | 'content' | 'system' | 'support';
  priority: 'high' | 'medium' | 'low';
  title: string;
  message: string;
  link: string | null;
  is_read: boolean;
  requires_action: boolean;
  metadata: Record<string, any>;
  created_at: string;
  read_at: string | null;
  archived_at: string | null;
}

export interface NotificationSettings {
  id: string;
  user_id: string;
  analytics_enabled: boolean;
  analytics_frequency: 'milestones' | 'disabled';
  email_enabled: boolean;
}

export function useNotifications() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();

  // Fetch notifications
  const {
    data: notifications = [],
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ['notifications', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return [];

      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', profile.id)
        .is('archived_at', null)
        .order('priority', { ascending: true })
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error fetching notifications:', error);
        return [];
      }

      return data as Notification[];
    },
    enabled: !!profile?.id,
    refetchInterval: 60000,
  });

  // Fetch notification settings
  const { data: settings } = useQuery({
    queryKey: ['notification-settings', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return null;

      const { data, error } = await supabase
        .from('user_notification_settings')
        .select('*')
        .eq('user_id', profile.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching notification settings:', error);
        return null;
      }

      return data as NotificationSettings | null;
    },
    enabled: !!profile?.id,
  });

  // Mark as read
  const markAsRead = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true, read_at: new Date().toISOString() })
        .eq('id', notificationId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Mark all as read
  const markAllAsRead = useMutation({
    mutationFn: async () => {
      if (!profile?.id) return;

      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true, read_at: new Date().toISOString() })
        .eq('user_id', profile.id)
        .eq('is_read', false);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Update settings
  const updateSettings = useMutation({
    mutationFn: async (newSettings: Partial<NotificationSettings>) => {
      if (!profile?.id) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('user_notification_settings')
        .upsert({
          user_id: profile.id,
          ...newSettings,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-settings'] });
    },
  });

  // Computed values
  const unreadCount = notifications.filter(n => !n.is_read).length;
  const highPriorityUnread = notifications.filter(n => !n.is_read && n.priority === 'high');
  const hasHighPriority = highPriorityUnread.length > 0;

  // Group by type
  const groupedNotifications = notifications.reduce((acc, n) => {
    if (!acc[n.type]) acc[n.type] = [];
    acc[n.type].push(n);
    return acc;
  }, {} as Record<string, Notification[]>);

  return {
    notifications,
    settings,
    isLoading,
    unreadCount,
    hasHighPriority,
    highPriorityUnread,
    groupedNotifications,
    markAsRead: markAsRead.mutate,
    markAllAsRead: markAllAsRead.mutate,
    updateSettings: updateSettings.mutate,
    refetch,
  };
}
