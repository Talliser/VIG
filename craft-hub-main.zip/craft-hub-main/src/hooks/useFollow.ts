import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export function useFollow(targetProfileId: string | undefined) {
  const { profile } = useAuth();
  const queryClient = useQueryClient();

  const { data: isFollowing = false } = useQuery({
    queryKey: ['is-following', profile?.id, targetProfileId],
    queryFn: async () => {
      if (!profile?.id || !targetProfileId) return false;
      const { count } = await supabase
        .from('user_follows')
        .select('id', { count: 'exact', head: true })
        .eq('follower_id', profile.id)
        .eq('following_id', targetProfileId);
      return (count || 0) > 0;
    },
    enabled: !!profile?.id && !!targetProfileId && profile.id !== targetProfileId,
  });

  const followMutation = useMutation({
    mutationFn: async () => {
      if (!profile?.id || !targetProfileId) throw new Error('Missing IDs');
      const { error } = await supabase.from('user_follows').insert({
        follower_id: profile.id,
        following_id: targetProfileId,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['is-following', profile?.id, targetProfileId] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: async () => {
      if (!profile?.id || !targetProfileId) throw new Error('Missing IDs');
      const { error } = await supabase
        .from('user_follows')
        .delete()
        .eq('follower_id', profile.id)
        .eq('following_id', targetProfileId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['is-following', profile?.id, targetProfileId] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
  });

  const toggleFollow = () => {
    if (isFollowing) {
      unfollowMutation.mutate();
    } else {
      followMutation.mutate();
    }
  };

  return {
    isFollowing,
    toggleFollow,
    isLoading: followMutation.isPending || unfollowMutation.isPending,
  };
}
