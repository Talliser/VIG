import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ProjectType {
  id: string;
  slug: string;
  name: string;
  name_plural: string;
  description: string | null;
  icon: string | null;
  enabled: boolean;
  sort_order: number;
}

export function useProjectTypes() {
  return useQuery({
    queryKey: ['project-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_types')
        .select('*')
        .eq('enabled', true)
        .order('sort_order', { ascending: true });

      if (error) throw error;
      return data as ProjectType[];
    },
  });
}
