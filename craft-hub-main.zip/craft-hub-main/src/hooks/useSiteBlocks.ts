import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface SitePage {
  id: string;
  key: string;
  name: string;
  description: string | null;
  icon: string | null;
  sort_order: number;
  enabled: boolean;
}

export interface SiteBlock {
  id: string;
  page_id: string;
  key: string;
  name: string;
  block_type: string;
  description: string | null;
  config: Record<string, unknown>;
  visible: boolean;
  sort_order: number;
  visibility_roles: string[];
  status: string;
}

export function useSitePages() {
  return useQuery({
    queryKey: ['site-pages'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_pages')
        .select('*')
        .order('sort_order');
      if (error) throw error;
      return data as SitePage[];
    },
  });
}

export function useSiteBlocks(pageId?: string) {
  return useQuery({
    queryKey: ['site-blocks', pageId],
    queryFn: async () => {
      let query = supabase
        .from('site_blocks')
        .select('*')
        .order('sort_order');

      if (pageId) {
        query = query.eq('page_id', pageId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as SiteBlock[];
    },
    enabled: !!pageId,
  });
}

export function useBlockHistory(blockId?: string) {
  return useQuery({
    queryKey: ['block-history', blockId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_block_history')
        .select('*')
        .eq('block_id', blockId!)
        .order('created_at', { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
    enabled: !!blockId,
  });
}
