import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

type DbComment = Database['public']['Tables']['comments']['Row'];
type DbProfile = Database['public']['Tables']['profiles']['Row'];

export interface CommentWithUser extends DbComment {
  user: DbProfile | null;
  replies?: CommentWithUser[];
}

export function useComments(modId: string) {
  return useQuery({
    queryKey: ['comments', modId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('comments')
        .select(`
          *,
          user:profiles!comments_user_id_fkey(*)
        `)
        .eq('mod_id', modId)
        .is('parent_id', null)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      // Fetch replies for each comment
      const commentsWithReplies: CommentWithUser[] = [];
      
      for (const comment of data || []) {
        const { data: replies } = await supabase
          .from('comments')
          .select(`
            *,
            user:profiles!comments_user_id_fkey(*)
          `)
          .eq('parent_id', comment.id)
          .order('created_at', { ascending: true });

        commentsWithReplies.push({
          ...comment,
          replies: replies as CommentWithUser[] || [],
        });
      }

      return commentsWithReplies;
    },
    enabled: !!modId,
  });
}

export function useAddComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      modId,
      userId,
      content,
      rating,
      parentId,
    }: {
      modId: string;
      userId: string;
      content: string;
      rating?: number;
      parentId?: string;
    }) => {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          mod_id: modId,
          user_id: userId,
          content,
          rating,
          parent_id: parentId,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.modId] });
    },
  });
}

export function useDeleteComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ commentId, modId }: { commentId: string; modId: string }) => {
      const { error } = await supabase
        .from('comments')
        .delete()
        .eq('id', commentId);

      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.modId] });
    },
  });
}
