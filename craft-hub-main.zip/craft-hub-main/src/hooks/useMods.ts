import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Edition, Category, Loader, SortOption } from '@/lib/types';
import type { Database } from '@/integrations/supabase/types';

type DbMod = Database['public']['Tables']['mods']['Row'];
type DbProfile = Database['public']['Tables']['profiles']['Row'];

export interface ModWithAuthor extends DbMod {
  author: DbProfile | null;
}

interface UseModsOptions {
  edition?: Edition | null;
  categories?: Category[];
  loaders?: Loader[];
  minecraftVersions?: string[];
  search?: string;
  sort?: SortOption;
  featured?: boolean;
  limit?: number;
  offset?: number;
  projectType?: string | null;
  status?: string;
}

export function useMods(options: UseModsOptions = {}) {
  const {
    edition,
    categories = [],
    loaders = [],
    minecraftVersions = [],
    search = '',
    sort = 'downloads',
    featured,
    limit = 20,
    offset = 0,
    projectType,
    status = 'published', // Only show published mods by default
  } = options;

  return useQuery({
    queryKey: ['mods', { edition, categories, loaders, minecraftVersions, search, sort, featured, limit, offset, projectType, status }],
    queryFn: async () => {
      let query = supabase
        .from('mods')
        .select(`
          *,
          author:profiles!mods_author_id_fkey(*)
        `);

      // Status filter - only show published mods publicly
      if (status) {
        query = query.eq('status', status);
      }

      // Project type filter (mods, resourcepacks, etc.)
      if (projectType) {
        query = query.eq('project_type', projectType);
      }

      // Edition filter
      if (edition) {
        query = query.eq('edition', edition);
      }

      // Featured filter
      if (featured !== undefined) {
        query = query.eq('featured', featured);
      }

      // Categories filter (array overlap)
      if (categories.length > 0) {
        query = query.overlaps('categories', categories);
      }

      // Loaders filter (array overlap)
      if (loaders.length > 0) {
        query = query.overlaps('loaders', loaders);
      }

      // Minecraft versions filter (array overlap)
      if (minecraftVersions.length > 0) {
        query = query.overlaps('minecraft_versions', minecraftVersions);
      }

      // Search filter
      if (search) {
        query = query.or(`name.ilike.%${search}%,summary.ilike.%${search}%`);
      }

      // Sorting
      switch (sort) {
        case 'downloads':
          query = query.order('downloads', { ascending: false });
          break;
        case 'views':
          query = query.order('views', { ascending: false });
          break;
        case 'rating':
          query = query.order('rating', { ascending: false });
          break;
        case 'updated':
          query = query.order('updated_at', { ascending: false });
          break;
        case 'created':
          query = query.order('created_at', { ascending: false });
          break;
        default:
          query = query.order('downloads', { ascending: false });
      }

      // Pagination
      query = query.range(offset, offset + limit - 1);

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      return data as ModWithAuthor[];
    },
  });
}

export function useFeaturedMods(limit = 6) {
  return useMods({ featured: true, limit, sort: 'downloads' });
}

export function usePopularMods(limit = 6) {
  return useMods({ limit, sort: 'downloads' });
}

export function useRecentMods(limit = 6) {
  return useMods({ limit, sort: 'updated' });
}

export function useModsStats() {
  return useQuery({
    queryKey: ['mods-stats'],
    queryFn: async () => {
      const { data: modsData, error: modsError } = await supabase
        .from('mods')
        .select('downloads');

      if (modsError) throw modsError;

      const { count: authorsCount, error: authorsError } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      if (authorsError) throw authorsError;

      const totalMods = modsData?.length || 0;
      const totalDownloads = modsData?.reduce((acc, mod) => acc + (mod.downloads || 0), 0) || 0;

      return {
        mods: totalMods,
        downloads: totalDownloads,
        authors: authorsCount || 0,
      };
    },
  });
}
