import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface PlatformFeature {
  id: string;
  key: string;
  name: string;
  description: string | null;
  category: string;
  enabled: boolean;
  risk_level: string;
  requires_confirmation: boolean;
  default_value: boolean;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export function useFeatureFlags() {
  const { data: features = [], isLoading } = useQuery({
    queryKey: ['platform-features'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('platform_features')
        .select('*')
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (error) throw error;
      return data as PlatformFeature[];
    },
    staleTime: 60_000, // cache for 1 min
  });

  const featureMap = new Map(features.map(f => [f.key, f]));

  const isEnabled = (key: string): boolean => {
    const feature = featureMap.get(key);
    return feature?.enabled ?? true; // safe default = enabled
  };

  const getFeature = (key: string): PlatformFeature | undefined => {
    return featureMap.get(key);
  };

  const getByCategory = (category: string): PlatformFeature[] => {
    return features.filter(f => f.category === category);
  };

  return {
    features,
    isLoading,
    isEnabled,
    getFeature,
    getByCategory,
  };
}
