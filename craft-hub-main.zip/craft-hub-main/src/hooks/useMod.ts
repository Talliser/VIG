import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

type DbMod = Database['public']['Tables']['mods']['Row'];
type DbProfile = Database['public']['Tables']['profiles']['Row'];
type DbModVersion = Database['public']['Tables']['mod_versions']['Row'];

export interface ModDetail extends DbMod {
  author: DbProfile | null;
  versions: DbModVersion[];
}

export function useMod(slug: string) {
  return useQuery({
    queryKey: ['mod', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('mods')
        .select(`
          *,
          author:profiles!mods_author_id_fkey(*),
          versions:mod_versions(*)
        `)
        .eq('slug', slug)
        .maybeSingle();

      if (error) {
        throw error;
      }

      return data as ModDetail | null;
    },
    enabled: !!slug,
  });
}

export function useSimilarMods(modId: string, categories: string[], limit = 4) {
  return useQuery({
    queryKey: ['similar-mods', modId, categories],
    queryFn: async () => {
      if (!categories.length) return [];

      const { data, error } = await supabase
        .from('mods')
        .select(`
          *,
          author:profiles!mods_author_id_fkey(*)
        `)
        .neq('id', modId)
        .overlaps('categories', categories)
        .order('downloads', { ascending: false })
        .limit(limit);

      if (error) {
        throw error;
      }

      return data;
    },
    enabled: !!modId && categories.length > 0,
  });
}

export function useIncrementViewCount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (modId: string) => {
      const { error } = await supabase.rpc('increment_view_count', { mod_id_param: modId });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mod'] });
    },
  });
}

export function useIncrementDownloadCount() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ modId, versionId }: { modId: string; versionId?: string }) => {
      const { error } = await supabase.rpc('increment_download_count', {
        mod_id_param: modId,
        version_id_param: versionId || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mod'] });
    },
  });
}
