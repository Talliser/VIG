import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Database } from '@/integrations/supabase/types';

export type AppRole = Database['public']['Enums']['app_role'];

// Permission codes from database
export type PermissionCode = 
  // Admin
  | 'admin.access'
  | 'admin.dashboard'
  // Users
  | 'users.view'
  | 'users.edit'
  | 'users.ban'
  | 'users.warn'
  | 'users.roles'
  | 'users.freeze'
  | 'users.xp'
  | 'users.badges'
  | 'users.verify'
  // Moderation
  | 'mods.view'
  | 'mods.approve'
  | 'mods.reject'
  | 'mods.delete'
  | 'mods.feature'
  // Platform
  | 'platform.settings'
  | 'platform.categories'
  | 'platform.legal'
  | 'platform.emergency'
  | 'platform.features'
  // Notifications
  | 'notifications.broadcast'
  // Reports
  | 'reports.view'
  | 'reports.resolve'
  // Tickets
  | 'tickets.view'
  | 'tickets.respond'
  | 'tickets.assign'
  // Security
  | 'security.view'
  | 'security.manage'
  | 'security.emergency'
  | 'security.export'
  // Audit
  | 'audit.view';

interface Permission {
  code: string;
  name: string;
  category: string;
}

// Staff roles that can access Admin Studio
const STAFF_ROLES: AppRole[] = ['super_admin', 'admin', 'moderator', 'support'];

export function usePermissions() {
  const { user, role } = useAuth();

  // Fetch user's permissions from database
  const { data: permissions = [], isLoading } = useQuery({
    queryKey: ['user-permissions', user?.id, role],
    queryFn: async () => {
      if (!user || !role) return [];

      const { data, error } = await supabase
        .from('role_permissions')
        .select(`
          permission_id,
          permissions:permission_id (
            code,
            name,
            category
          )
        `)
        .eq('role', role);

      if (error) {
        console.error('Error fetching permissions:', error);
        return [];
      }

      return data?.map(rp => rp.permissions as unknown as Permission) || [];
    },
    enabled: !!user && !!role,
  });

  // Permission codes set for quick lookup
  const permissionCodes = new Set(permissions.map(p => p.code));

  /**
   * Check if user has specific permission
   * Super admin always has all permissions
   */
  const hasPermission = (code: PermissionCode): boolean => {
    if (!role) return false;
    if (role === 'super_admin') return true;
    return permissionCodes.has(code);
  };

  /**
   * Check if user has ANY of the provided permissions
   */
  const hasAnyPermission = (codes: PermissionCode[]): boolean => {
    return codes.some(code => hasPermission(code));
  };

  /**
   * Check if user has ALL of the provided permissions
   */
  const hasAllPermissions = (codes: PermissionCode[]): boolean => {
    return codes.every(code => hasPermission(code));
  };

  /**
   * Check if user is staff (can access Admin Studio)
   */
  const isStaff = (): boolean => {
    return STAFF_ROLES.includes(role as AppRole);
  };

  /**
   * Check if user can access Admin Studio
   */
  const canAccessAdminStudio = (): boolean => {
    return hasPermission('admin.access');
  };

  /**
   * Get permissions grouped by category
   */
  const getPermissionsByCategory = (): Record<string, Permission[]> => {
    return permissions.reduce((acc, p) => {
      if (!acc[p.category]) acc[p.category] = [];
      acc[p.category].push(p);
      return acc;
    }, {} as Record<string, Permission[]>);
  };

  return {
    // Raw data
    permissions,
    permissionCodes: Array.from(permissionCodes),
    isLoading,
    role,
    
    // Permission checks (use these!)
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    
    // Access checks
    isStaff,
    canAccessAdminStudio,
    
    // Utilities
    getPermissionsByCategory,
  };
}
