import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface UserProfile {
  id: string;
  user_id: string | null;
  username: string;
  display_name: string | null;
  avatar: string | null;
  banner: string | null;
  bio: string | null;
  nickname: string | null;
  social_links: Record<string, string>;
  xp: number;
  level: number;
  level_name: string;
  is_frozen: boolean;
  freeze_reason: string | null;
  privacy_settings: {
    hide_followers: boolean;
    hide_registration_date: boolean;
    hide_activity: boolean;
  };
  verified: boolean;
  referral_code: string | null;
  referred_by: string | null;
  last_username_change: string | null;
  created_at: string;
  updated_at: string;
  // Aggregated stats
  mods_count: number;
  total_downloads: number;
  followers_count: number;
  following_count: number;
  badges: Badge[];
}

export interface Badge {
  id: string;
  badge_key: string;
  badge_name: string;
  badge_description: string | null;
  badge_icon: string | null;
  awarded_at: string;
  is_auto: boolean;
  expires_at: string | null;
}

export function useUserProfile(username: string | undefined) {
  return useQuery({
    queryKey: ['user-profile', username],
    queryFn: async (): Promise<UserProfile> => {
      if (!username) throw new Error('Username required');

      // Fetch profile
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('username', username)
        .single();

      if (error || !profile) throw new Error('Profile not found');

      // Fetch stats in parallel
      const [modsRes, followersRes, followingRes, badgesRes] = await Promise.all([
        supabase
          .from('mods')
          .select('downloads')
          .eq('author_id', profile.id)
          .eq('status', 'approved'),
        supabase
          .from('user_follows')
          .select('id', { count: 'exact', head: true })
          .eq('following_id', profile.id),
        supabase
          .from('user_follows')
          .select('id', { count: 'exact', head: true })
          .eq('follower_id', profile.id),
        supabase
          .from('user_badges')
          .select('*')
          .eq('profile_id', profile.id)
          .order('awarded_at', { ascending: false }),
      ]);

      const mods = modsRes.data || [];
      const totalDownloads = mods.reduce((sum, m) => sum + (m.downloads || 0), 0);

      return {
        ...profile,
        social_links: (profile.social_links as Record<string, string>) || {},
        privacy_settings: (profile.privacy_settings as UserProfile['privacy_settings']) || {
          hide_followers: false,
          hide_registration_date: false,
          hide_activity: false,
        },
        xp: profile.xp ?? 0,
        level: profile.level ?? 0,
        level_name: profile.level_name ?? 'Новичок',
        is_frozen: profile.is_frozen ?? false,
        freeze_reason: profile.freeze_reason ?? null,
        verified: profile.verified ?? false,
        referral_code: profile.referral_code ?? null,
        referred_by: profile.referred_by ?? null,
        last_username_change: profile.last_username_change ?? null,
        mods_count: mods.length,
        total_downloads: totalDownloads,
        followers_count: followersRes.count || 0,
        following_count: followingRes.count || 0,
        badges: (badgesRes.data || []) as Badge[],
      };
    },
    enabled: !!username,
  });
}
