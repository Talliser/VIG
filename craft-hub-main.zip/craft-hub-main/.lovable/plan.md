

## Plan: Extended User Profiles System

This is a large feature spanning database schema, new pages, admin integration, and social mechanics. I'll break it into implementation phases.

---

### Phase 1: Database Schema (Migration)

New tables and columns:

**Extend `profiles` table:**
- `banner` (text, nullable) -- banner image URL
- `nickname` (text, nullable) -- short @name for comments
- `social_links` (jsonb, default `{}`) -- {github, discord, curseforge, modrinth, website}
- `xp` (integer, default 0) -- experience points
- `level` (integer, default 0) -- calculated level
- `level_name` (text, default 'Новичок')
- `is_frozen` (boolean, default false) -- profile freeze
- `frozen_by` (uuid, nullable)
- `frozen_at` (timestamptz, nullable)
- `freeze_reason` (text, nullable)
- `privacy_settings` (jsonb, default `{"hide_followers":false,"hide_registration_date":false,"hide_activity":false}`)
- `last_username_change` (timestamptz, nullable) -- rate limit username changes to 7 days
- `referral_code` (text, unique) -- auto-generated
- `referred_by` (uuid, nullable) -- profile_id of referrer

**New table: `user_badges`**
- id, profile_id, badge_key, badge_name, badge_description, badge_icon, awarded_at, awarded_by (nullable), is_auto (boolean), expires_at (nullable)

**New table: `user_follows`**
- id, follower_id (profile ref), following_id (profile ref), created_at
- Unique constraint on (follower_id, following_id)

**New table: `user_xp_log`**
- id, profile_id, amount (int), reason (text), source_type (text), source_id (uuid nullable), created_at

**New table: `user_login_history`**
- id, user_id (auth.users ref), ip_hash (text), user_agent (text), created_at

**New table: `user_appeals`**
- id, user_id (profile ref), type (text: 'ban'|'warning'|'freeze'), target_id (uuid), message (text), status (text: 'pending'|'approved'|'rejected'), reviewed_by (uuid nullable), reviewed_at (timestamptz nullable), created_at

**Storage bucket:** `user-avatars` (public), `user-banners` (public)

**DB Functions:**
- `award_xp(profile_id, amount, reason, source_type, source_id)` -- SECURITY DEFINER, handles level calculation, respects freeze
- `calculate_level(xp)` -- returns level number
- `get_level_name(level)` -- returns level title string
- Trigger on profiles to auto-generate referral_code on insert
- Trigger/validation for username change rate limit (7 days)

**RLS Policies:**
- `user_badges`: public SELECT, staff INSERT/UPDATE/DELETE
- `user_follows`: authenticated INSERT/DELETE own, public SELECT
- `user_xp_log`: owner SELECT, staff ALL
- `user_login_history`: owner SELECT, staff SELECT
- `user_appeals`: owner INSERT/SELECT, staff ALL

---

### Phase 2: Public Profile Page (`/user/:username`)

**New file: `src/pages/UserProfilePage.tsx`**

Sections:
1. **Header** -- banner, avatar, display_name, @nickname, bio, social links, registration duration ("На сайте X лет Y месяцев"), level badge + XP progress bar, badges row with tooltip, Follow button + follower/following counts
2. **Tabs:**
   - **Моды** -- grid of user's published mods (reuse `ModCard`)
   - **Комментарии** -- user's public comments
   - **Бейджи** -- full badge list with descriptions and dates
   - **Активность** -- recent public activity (mods published, milestones)
3. **Stats bar** -- mods count, total downloads, followers, following

**New hook: `src/hooks/useUserProfile.ts`** -- fetch profile by username with stats aggregation

**Route:** Add `/user/:username` to App.tsx. Update Header profile link from `/author/:id` to `/user/:username`.

---

### Phase 3: Private Profile (Owner View)

On the same `/user/:username` page, if the viewer is the owner:

- **Edit Profile** section (inline or modal): change display_name, nickname, bio, social_links, upload avatar/banner (drag & drop to storage buckets with 5MB limit, JPG/PNG only)
- **Security tab:** login history, warnings history (from `user_warnings`), ban history (from `user_bans`), appeal submission button, privacy toggles (hide followers, hide registration date, hide activity)
- **Activity tab (private):** who liked, who followed, notification-related events
- **Referral section:** referral link display, count of invited users, bonus XP earned
- **Username change** with 7-day cooldown enforcement

---

### Phase 4: Admin Profile Management

**Extend `AdminUsers.tsx`** with a "View Profile" action that opens a detailed modal/panel:

- **Super Admin actions:** edit XP (with reason logging), award/remove badges, verify author (special badge), permanent ban, delete user, change roles
- **Admin actions:** warnings, temporary ban, freeze/unfreeze profile, edit profile fields, approve verification
- **Moderator actions:** warnings, temporary block, delete comments, view reports

**Profile freeze** implementation:
- Sets `is_frozen = true` on profile
- Frozen users cannot: publish mods, comment, earn XP
- Frontend checks `profile.is_frozen` and shows restriction messages
- Profile remains publicly visible

**XP edit** logs to `user_xp_log` and `admin_logs`

**Badge management** UI in admin user detail panel

---

### Phase 5: Follow System & Notifications Integration

- Follow/unfollow mutations with optimistic updates
- When a followed author publishes a mod → notification (type: `content`, priority: `low`)
- Follower count displayed on profile, with privacy toggle support
- Milestone notifications: first follower, 10/100/1000 followers

---

### Technical Details

**XP Level Thresholds:**
```text
0-99    → Level 0 "Новичок"
100-499 → Level 1 "Кузнец идей"
500-999 → Level 2 "Мастер модов"
1000+   → Level 3 "Легенда Майнкрафта"
```

**XP Awards (server-side only via `award_xp` function):**
- +10 mod published, +1 like received, +3 download, -20 violation

**Security measures:**
- Username uniqueness enforced at DB level (already exists)
- Username change rate limited to 1 per 7 days (DB trigger)
- XP manipulation only via SECURITY DEFINER function
- Avatar/banner uploads validated for type and size on frontend + storage policies
- All admin actions logged to `admin_logs`

**Files to create:**
- `src/pages/UserProfilePage.tsx`
- `src/hooks/useUserProfile.ts`
- `src/hooks/useFollow.ts`
- `src/components/profile/ProfileHeader.tsx`
- `src/components/profile/ProfileTabs.tsx`
- `src/components/profile/ProfileEditModal.tsx`
- `src/components/profile/BadgeDisplay.tsx`
- `src/components/profile/XPProgressBar.tsx`
- `src/components/profile/PrivacySettings.tsx`
- `src/components/profile/ReferralSection.tsx`
- `src/components/admin/UserDetailPanel.tsx`
- Migration SQL file

**Files to edit:**
- `src/App.tsx` -- add `/user/:username` route
- `src/components/layout/Header.tsx` -- update profile link
- `src/pages/admin/AdminUsers.tsx` -- add detail panel integration
- `src/hooks/usePermissions.ts` -- add `users.freeze`, `users.xp`, `users.badges`, `users.verify` permissions

