-- Create enum types for categories and loaders
CREATE TYPE public.edition AS ENUM ('java', 'bedrock');

CREATE TYPE public.loader AS ENUM (
  'fabric', 'forge', 'neoforge', 'quilt', 'liteloader', 'rift', 'modloader'
);

CREATE TYPE public.category AS ENUM (
  'adventure', 'decoration', 'economy', 'equipment', 'food', 'library', 
  'magic', 'management', 'minigame', 'mobs', 'optimization', 'social', 
  'storage', 'technology', 'transportation', 'utility', 'worldgen'
);

-- Create profiles table for user data
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT,
  avatar TEXT,
  bio TEXT,
  verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create mods table
CREATE TABLE public.mods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  summary TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT,
  banner TEXT,
  gallery TEXT[] DEFAULT '{}',
  edition public.edition NOT NULL DEFAULT 'java',
  categories public.category[] DEFAULT '{}',
  loaders public.loader[] DEFAULT '{}',
  minecraft_versions TEXT[] DEFAULT '{}',
  author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  downloads INTEGER NOT NULL DEFAULT 0,
  views INTEGER NOT NULL DEFAULT 0,
  rating NUMERIC(3,2) DEFAULT 0,
  rating_count INTEGER DEFAULT 0,
  featured BOOLEAN DEFAULT false,
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create mod versions table
CREATE TABLE public.mod_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mod_id UUID NOT NULL REFERENCES public.mods(id) ON DELETE CASCADE,
  version TEXT NOT NULL,
  minecraft_versions TEXT[] DEFAULT '{}',
  loaders public.loader[] DEFAULT '{}',
  release_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  downloads INTEGER DEFAULT 0,
  file_size TEXT,
  file_url TEXT,
  changelog TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create comments table
CREATE TABLE public.comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mod_id UUID NOT NULL REFERENCES public.mods(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  likes INTEGER DEFAULT 0,
  parent_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create favorites table
CREATE TABLE public.favorites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  mod_id UUID NOT NULL REFERENCES public.mods(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, mod_id)
);

-- Create download logs table for analytics
CREATE TABLE public.download_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mod_id UUID NOT NULL REFERENCES public.mods(id) ON DELETE CASCADE,
  version_id UUID REFERENCES public.mod_versions(id) ON DELETE SET NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  ip_hash TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mod_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.download_logs ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Profiles are viewable by everyone" 
ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Mods policies (public read, authors can manage their mods)
CREATE POLICY "Mods are viewable by everyone" 
ON public.mods FOR SELECT USING (true);

CREATE POLICY "Authors can insert their own mods" 
ON public.mods FOR INSERT WITH CHECK (
  author_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Authors can update their own mods" 
ON public.mods FOR UPDATE USING (
  author_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Authors can delete their own mods" 
ON public.mods FOR DELETE USING (
  author_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

-- Mod versions policies
CREATE POLICY "Mod versions are viewable by everyone" 
ON public.mod_versions FOR SELECT USING (true);

CREATE POLICY "Authors can manage their mod versions" 
ON public.mod_versions FOR ALL USING (
  mod_id IN (
    SELECT id FROM public.mods 
    WHERE author_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  )
);

-- Comments policies
CREATE POLICY "Comments are viewable by everyone" 
ON public.comments FOR SELECT USING (true);

CREATE POLICY "Authenticated users can insert comments" 
ON public.comments FOR INSERT WITH CHECK (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Users can update their own comments" 
ON public.comments FOR UPDATE USING (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Users can delete their own comments" 
ON public.comments FOR DELETE USING (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

-- Favorites policies
CREATE POLICY "Users can view their own favorites" 
ON public.favorites FOR SELECT USING (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Users can manage their own favorites" 
ON public.favorites FOR ALL USING (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

-- Download logs policies (insert only, no read for users)
CREATE POLICY "Anyone can log downloads" 
ON public.download_logs FOR INSERT WITH CHECK (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_mods_updated_at
  BEFORE UPDATE ON public.mods
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_comments_updated_at
  BEFORE UPDATE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to increment download count
CREATE OR REPLACE FUNCTION public.increment_download_count(mod_id_param UUID, version_id_param UUID DEFAULT NULL)
RETURNS void AS $$
BEGIN
  UPDATE public.mods SET downloads = downloads + 1 WHERE id = mod_id_param;
  IF version_id_param IS NOT NULL THEN
    UPDATE public.mod_versions SET downloads = downloads + 1 WHERE id = version_id_param;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to increment view count
CREATE OR REPLACE FUNCTION public.increment_view_count(mod_id_param UUID)
RETURNS void AS $$
BEGIN
  UPDATE public.mods SET views = views + 1 WHERE id = mod_id_param;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user profile
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, username, display_name)
  VALUES (
    NEW.id, 
    COALESCE(NEW.raw_user_meta_data ->> 'username', 'user_' || substr(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', NEW.raw_user_meta_data ->> 'username')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create indexes for better performance
CREATE INDEX idx_mods_edition ON public.mods(edition);
CREATE INDEX idx_mods_featured ON public.mods(featured);
CREATE INDEX idx_mods_downloads ON public.mods(downloads DESC);
CREATE INDEX idx_mods_views ON public.mods(views DESC);
CREATE INDEX idx_mods_rating ON public.mods(rating DESC);
CREATE INDEX idx_mods_created_at ON public.mods(created_at DESC);
CREATE INDEX idx_mods_updated_at ON public.mods(updated_at DESC);
CREATE INDEX idx_mods_author_id ON public.mods(author_id);
CREATE INDEX idx_mods_slug ON public.mods(slug);
CREATE INDEX idx_mod_versions_mod_id ON public.mod_versions(mod_id);
CREATE INDEX idx_comments_mod_id ON public.comments(mod_id);
CREATE INDEX idx_favorites_user_id ON public.favorites(user_id);
CREATE INDEX idx_favorites_mod_id ON public.favorites(mod_id);