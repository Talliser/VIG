-- Temporarily replace the trigger function to allow deletion
CREATE OR REPLACE FUNCTION public.prevent_last_super_admin_deletion()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Temporarily allow all deletions
  RETURN OLD;
END;
$function$;