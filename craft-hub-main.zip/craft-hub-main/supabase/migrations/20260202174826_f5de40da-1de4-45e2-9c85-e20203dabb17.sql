-- 1. Fix profiles RLS: Only authenticated users can view profiles
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;

CREATE POLICY "Authenticated users can view profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (true);

-- 2. Fix download_logs RLS: Staff can view, not public insert
DROP POLICY IF EXISTS "Anyone can log downloads" ON public.download_logs;

CREATE POLICY "Authenticated users can log downloads"
ON public.download_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Staff can view download logs"
ON public.download_logs
FOR SELECT
USING (public.is_staff(auth.uid()));

-- 3. Fix security_events RLS: Restrict insert to system/staff only  
DROP POLICY IF EXISTS "System can insert security events" ON public.security_events;

CREATE POLICY "Staff can insert security events"
ON public.security_events
FOR INSERT
TO authenticated
WITH CHECK (public.is_staff(auth.uid()));

-- 4. Add mod file URL column if not exists (for mod files upload)
ALTER TABLE public.mods 
ADD COLUMN IF NOT EXISTS primary_file_url text,
ADD COLUMN IF NOT EXISTS primary_file_size text;

-- 5. Add rejection_reason column for moderation feedback
ALTER TABLE public.mods 
ADD COLUMN IF NOT EXISTS rejection_reason text,
ADD COLUMN IF NOT EXISTS reviewed_by uuid,
ADD COLUMN IF NOT EXISTS reviewed_at timestamp with time zone;

-- 6. Create IP hash function for security (instead of plain text IPs)
CREATE OR REPLACE FUNCTION public.hash_ip(ip_text text)
RETURNS text
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT encode(sha256(ip_text::bytea), 'hex')
$$;