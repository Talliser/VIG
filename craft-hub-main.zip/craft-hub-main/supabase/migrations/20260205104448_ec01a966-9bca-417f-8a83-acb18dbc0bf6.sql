-- Drop the overly permissive notification insert policy
DROP POLICY IF EXISTS "System can insert notifications" ON public.notifications;

-- Create more restrictive policy - only staff can insert notifications
CREATE POLICY "Staff can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (is_staff(auth.uid()));

-- Also allow deletion for cleanup
CREATE POLICY "Staff can delete notifications"
ON public.notifications FOR DELETE
USING (is_staff(auth.uid()));