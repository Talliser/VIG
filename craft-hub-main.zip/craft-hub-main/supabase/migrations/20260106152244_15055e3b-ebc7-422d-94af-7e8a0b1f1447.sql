-- Clear existing role_permissions to rebuild correctly
DELETE FROM role_permissions;

-- Add missing permissions for complete RBAC
INSERT INTO permissions (code, name, description, category) VALUES
  -- Users management - expanded
  ('users.warn', 'Warn Users', 'Issue warnings to users', 'users'),
  -- Platform management - expanded  
  ('platform.emergency', 'Emergency Mode', 'Enable/disable emergency mode', 'platform'),
  ('platform.features', 'Feature Flags', 'Manage feature flags', 'platform'),
  -- Security - expanded
  ('security.emergency', 'Emergency Controls', 'Access emergency security controls', 'security'),
  ('security.export', 'Export Logs', 'Export security and audit logs', 'security'),
  -- Admin Studio access
  ('admin.access', 'Admin Studio Access', 'Access to Admin Studio', 'admin'),
  ('admin.dashboard', 'Admin Dashboard', 'View admin dashboard', 'admin')
ON CONFLICT (code) DO NOTHING;

-- ========================================
-- SUPER_ADMIN: Full access to everything
-- ========================================
INSERT INTO role_permissions (role, permission_id)
SELECT 'super_admin'::app_role, id FROM permissions;

-- ========================================
-- ADMIN: Operations management (no security-critical)
-- ========================================
INSERT INTO role_permissions (role, permission_id)
SELECT 'admin'::app_role, id FROM permissions 
WHERE code IN (
  -- Admin access
  'admin.access',
  'admin.dashboard',
  -- Users (can't manage roles of super_admin)
  'users.view',
  'users.edit', 
  'users.ban',
  'users.warn',
  -- Moderation
  'mods.view',
  'mods.approve',
  'mods.reject',
  'mods.delete',
  'mods.feature',
  -- Platform (no emergency)
  'platform.settings',
  'platform.categories',
  'platform.legal',
  'platform.features',
  -- Reports
  'reports.view',
  'reports.resolve',
  -- Tickets
  'tickets.view',
  'tickets.respond',
  'tickets.assign',
  -- Security (view only)
  'security.view',
  -- Audit (view only)
  'audit.view'
);

-- ========================================
-- MODERATOR: Content quality control
-- ========================================
INSERT INTO role_permissions (role, permission_id)
SELECT 'moderator'::app_role, id FROM permissions 
WHERE code IN (
  -- Admin access (limited)
  'admin.access',
  'admin.dashboard',
  -- Users (view + warn only)
  'users.view',
  'users.warn',
  -- Moderation (full except delete)
  'mods.view',
  'mods.approve',
  'mods.reject',
  'mods.feature',
  -- Reports
  'reports.view',
  'reports.resolve'
);

-- ========================================
-- SUPPORT: User communication only
-- ========================================
INSERT INTO role_permissions (role, permission_id)
SELECT 'support'::app_role, id FROM permissions 
WHERE code IN (
  -- Admin access (limited)
  'admin.access',
  'admin.dashboard',
  -- Users (read-only)
  'users.view',
  -- Tickets (full)
  'tickets.view',
  'tickets.respond',
  'tickets.assign',
  -- Reports (view only, for context)
  'reports.view'
);

-- ========================================
-- Create has_permission function for RLS
-- ========================================
CREATE OR REPLACE FUNCTION public.has_permission(_user_id uuid, _permission_code text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.role_permissions rp ON ur.role = rp.role
    JOIN public.permissions p ON rp.permission_id = p.id
    WHERE ur.user_id = _user_id
      AND p.code = _permission_code
  )
  OR EXISTS (
    -- Super admin has all permissions
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = 'super_admin'
  )
$$;

-- ========================================
-- Create is_staff function
-- ========================================
CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('super_admin', 'admin', 'moderator', 'support')
  )
$$;

-- ========================================
-- Create log_admin_action function
-- ========================================
CREATE OR REPLACE FUNCTION public.log_admin_action(
  _action text,
  _target_type text DEFAULT NULL,
  _target_id uuid DEFAULT NULL,
  _details jsonb DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _log_id uuid;
BEGIN
  INSERT INTO admin_logs (admin_id, action, target_type, target_id, details)
  VALUES (auth.uid(), _action, _target_type, _target_id, _details)
  RETURNING id INTO _log_id;
  
  RETURN _log_id;
END;
$$;

-- ========================================
-- Update RLS policies to use permission-based checks
-- ========================================

-- Drop existing policies that use has_role directly
DROP POLICY IF EXISTS "Admins can insert logs" ON admin_logs;
DROP POLICY IF EXISTS "Admins can view logs" ON admin_logs;

-- Recreate with permission-based access
CREATE POLICY "Staff can insert admin logs" 
ON admin_logs FOR INSERT
WITH CHECK (is_staff(auth.uid()));

CREATE POLICY "Users with audit permission can view logs" 
ON admin_logs FOR SELECT
USING (has_permission(auth.uid(), 'audit.view'));

-- Update site_settings policies
DROP POLICY IF EXISTS "Admins can update site_settings" ON site_settings;
DROP POLICY IF EXISTS "Admins can view site_settings" ON site_settings;
DROP POLICY IF EXISTS "Super admins can manage site_settings" ON site_settings;

CREATE POLICY "Users with settings permission can view site_settings" 
ON site_settings FOR SELECT
USING (has_permission(auth.uid(), 'platform.settings'));

CREATE POLICY "Users with settings permission can update site_settings" 
ON site_settings FOR UPDATE
USING (has_permission(auth.uid(), 'platform.settings'));

CREATE POLICY "Super admin can manage all site_settings" 
ON site_settings FOR ALL
USING (has_role(auth.uid(), 'super_admin'));

-- Update security_events policies  
DROP POLICY IF EXISTS "Admins can view security events" ON security_events;

CREATE POLICY "Users with security permission can view events" 
ON security_events FOR SELECT
USING (has_permission(auth.uid(), 'security.view'));

-- Update project_types policies
DROP POLICY IF EXISTS "Admins can manage project types" ON project_types;

CREATE POLICY "Users with categories permission can manage project types" 
ON project_types FOR ALL
USING (has_permission(auth.uid(), 'platform.categories'));

-- Add unique constraint on permissions.code if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'permissions_code_key'
  ) THEN
    ALTER TABLE permissions ADD CONSTRAINT permissions_code_key UNIQUE (code);
  END IF;
END $$;