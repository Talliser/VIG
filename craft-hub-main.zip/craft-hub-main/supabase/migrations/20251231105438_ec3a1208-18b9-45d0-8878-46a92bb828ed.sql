-- Fix search_path for existing functions that don't have it set
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.increment_download_count(mod_id_param uuid, version_id_param uuid DEFAULT NULL::uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.mods SET downloads = downloads + 1 WHERE id = mod_id_param;
  IF version_id_param IS NOT NULL THEN
    UPDATE public.mod_versions SET downloads = downloads + 1 WHERE id = version_id_param;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.increment_view_count(mod_id_param uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.mods SET views = views + 1 WHERE id = mod_id_param;
END;
$$;