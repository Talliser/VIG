-- 1. Функция проверки возможности bootstrap
CREATE OR REPLACE FUNCTION public.can_bootstrap_super_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM public.user_roles WHERE role = 'super_admin'
  )
$$;

-- 2. Функция защиты от удаления последнего Super Admin
CREATE OR REPLACE FUNCTION public.prevent_last_super_admin_deletion()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.role = 'super_admin' THEN
    IF (SELECT COUNT(*) FROM public.user_roles WHERE role = 'super_admin') <= 1 THEN
      RAISE EXCEPTION 'Cannot delete the last super_admin. System requires at least one super_admin.';
    END IF;
  END IF;
  RETURN OLD;
END;
$$;

-- 3. Триггер на user_roles
CREATE TRIGGER prevent_last_super_admin_delete
  BEFORE DELETE ON public.user_roles
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_last_super_admin_deletion();