
-- Fix search_path for validate_risk_level
CREATE OR REPLACE FUNCTION public.validate_risk_level()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.risk_level NOT IN ('low', 'medium', 'high') THEN
    RAISE EXCEPTION 'Invalid risk_level: %. Must be low, medium, or high', NEW.risk_level;
  END IF;
  RETURN NEW;
END;
$$;
