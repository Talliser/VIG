-- Add platform.legal permission if not exists
INSERT INTO public.permissions (code, name, category, description)
SELECT 'platform.legal', 'Legal Documents', 'platform', 'Manage legal documents'
WHERE NOT EXISTS (
  SELECT 1 FROM public.permissions WHERE code = 'platform.legal'
);

-- Grant platform.legal to admin and super_admin
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'admin', id FROM public.permissions WHERE code = 'platform.legal'
ON CONFLICT DO NOTHING;

INSERT INTO public.role_permissions (role, permission_id)
SELECT 'super_admin', id FROM public.permissions WHERE code = 'platform.legal'
ON CONFLICT DO NOTHING;

-- Create notifications table
CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('legal', 'analytics', 'content', 'system', 'support')),
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('high', 'medium', 'low')),
  title text NOT NULL,
  message text NOT NULL,
  link text,
  is_read boolean NOT NULL DEFAULT false,
  requires_action boolean NOT NULL DEFAULT false,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz,
  archived_at timestamptz
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread 
ON public.notifications (user_id, is_read, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_notifications_type 
ON public.notifications (type);

-- Create user notification settings table
CREATE TABLE IF NOT EXISTS public.user_notification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE UNIQUE,
  analytics_enabled boolean NOT NULL DEFAULT true,
  analytics_frequency text NOT NULL DEFAULT 'milestones' CHECK (analytics_frequency IN ('milestones', 'disabled')),
  email_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create legal document versions table for version history
CREATE TABLE IF NOT EXISTS public.legal_document_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES public.legal_documents(id) ON DELETE CASCADE,
  version integer NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  slug text NOT NULL,
  effective_date timestamptz NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  change_summary text
);

CREATE INDEX IF NOT EXISTS idx_legal_versions_document 
ON public.legal_document_versions (document_id, version DESC);

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_document_versions ENABLE ROW LEVEL SECURITY;

-- RLS policies for notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications FOR SELECT
USING (user_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Users can update their own notifications"
ON public.notifications FOR UPDATE
USING (user_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "System can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (true);

-- RLS policies for notification settings
CREATE POLICY "Users can manage their own notification settings"
ON public.user_notification_settings FOR ALL
USING (user_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- RLS policies for legal document versions
CREATE POLICY "Anyone can view legal document versions"
ON public.legal_document_versions FOR SELECT
USING (true);

CREATE POLICY "Admins can manage legal document versions"
ON public.legal_document_versions FOR ALL
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'super_admin'));

-- Function to auto-archive old notifications
CREATE OR REPLACE FUNCTION public.archive_old_notifications()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.notifications 
  SET archived_at = now()
  WHERE created_at < now() - interval '2 days'
    AND archived_at IS NULL
    AND is_read = true;
END;
$$;

-- Function to create notification for all users (for legal updates)
CREATE OR REPLACE FUNCTION public.create_broadcast_notification(
  _type text,
  _priority text,
  _title text,
  _message text,
  _link text DEFAULT NULL,
  _requires_action boolean DEFAULT false
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _count integer;
BEGIN
  INSERT INTO public.notifications (user_id, type, priority, title, message, link, requires_action)
  SELECT id, _type, _priority, _title, _message, _link, _requires_action
  FROM public.profiles;
  
  GET DIAGNOSTICS _count = ROW_COUNT;
  RETURN _count;
END;
$$;