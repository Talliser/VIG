-- Create table for password reset OTP codes
CREATE TABLE public.password_reset_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  expires_at timestamp with time zone NOT NULL,
  used boolean NOT NULL DEFAULT false,
  ip_hash text
);

-- Index for fast lookup
CREATE INDEX idx_password_reset_codes_email ON public.password_reset_codes(email);
CREATE INDEX idx_password_reset_codes_expires ON public.password_reset_codes(expires_at);

-- Enable RLS
ALTER TABLE public.password_reset_codes ENABLE ROW LEVEL SECURITY;

-- No direct access from client - only through edge functions
-- RLS policy: deny all direct access
CREATE POLICY "No direct access to password reset codes"
ON public.password_reset_codes
FOR ALL
USING (false);

-- Function to clean up expired codes (can be called by cron)
CREATE OR REPLACE FUNCTION public.cleanup_expired_reset_codes()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.password_reset_codes 
  WHERE expires_at < now() OR used = true;
END;
$$;

-- Rate limiting table for auth attempts
CREATE TABLE public.auth_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_hash text NOT NULL,
  action_type text NOT NULL, -- 'login', 'signup', 'reset'
  attempt_count integer NOT NULL DEFAULT 1,
  window_start timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX idx_auth_rate_limits_ip ON public.auth_rate_limits(ip_hash, action_type);

ALTER TABLE public.auth_rate_limits ENABLE ROW LEVEL SECURITY;

-- No direct access
CREATE POLICY "No direct access to rate limits"
ON public.auth_rate_limits
FOR ALL
USING (false);