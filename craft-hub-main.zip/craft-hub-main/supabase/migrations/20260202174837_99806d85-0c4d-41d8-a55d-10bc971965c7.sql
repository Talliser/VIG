-- Fix function search_path for hash_ip
CREATE OR REPLACE FUNCTION public.hash_ip(ip_text text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT encode(sha256(ip_text::bytea), 'hex')
$$;