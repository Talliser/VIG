-- Restore the original trigger function with protection
CREATE OR REPLACE FUNCTION public.prevent_last_super_admin_deletion()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF OLD.role = 'super_admin' THEN
    IF (SELECT COUNT(*) FROM public.user_roles WHERE role = 'super_admin') <= 1 THEN
      RAISE EXCEPTION 'Cannot delete the last super_admin. System requires at least one super_admin.';
    END IF;
  END IF;
  RETURN OLD;
END;
$function$;