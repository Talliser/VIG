-- Create permissions table
CREATE TABLE public.permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  category text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create role_permissions mapping
CREATE TABLE public.role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role app_role NOT NULL,
  permission_id uuid REFERENCES public.permissions(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(role, permission_id)
);

-- Create site_settings table for platform configuration
CREATE TABLE public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL DEFAULT '{}',
  category text NOT NULL,
  description text,
  updated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create legal_documents table with versioning
CREATE TABLE public.legal_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  version integer NOT NULL DEFAULT 1,
  effective_date timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  is_active boolean NOT NULL DEFAULT true
);

CREATE INDEX idx_legal_documents_slug ON public.legal_documents(slug);
CREATE INDEX idx_legal_documents_active ON public.legal_documents(is_active, slug);

-- Create tickets table for support system
CREATE TABLE public.tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  assigned_to uuid,
  subject text NOT NULL,
  description text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  priority text NOT NULL DEFAULT 'normal',
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE INDEX idx_tickets_status ON public.tickets(status);
CREATE INDEX idx_tickets_user ON public.tickets(user_id);
CREATE INDEX idx_tickets_assigned ON public.tickets(assigned_to);

-- Create ticket_messages table
CREATE TABLE public.ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid REFERENCES public.tickets(id) ON DELETE CASCADE NOT NULL,
  user_id uuid NOT NULL,
  message text NOT NULL,
  is_internal boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create security_events table for anti-abuse
CREATE TABLE public.security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  user_id uuid,
  ip_address text,
  details jsonb,
  severity text NOT NULL DEFAULT 'info',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_security_events_type ON public.security_events(event_type);
CREATE INDEX idx_security_events_severity ON public.security_events(severity);
CREATE INDEX idx_security_events_user ON public.security_events(user_id);

-- Create user_warnings table
CREATE TABLE public.user_warnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  issued_by uuid NOT NULL,
  reason text NOT NULL,
  severity text NOT NULL DEFAULT 'warning',
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create user_bans table
CREATE TABLE public.user_bans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  banned_by uuid NOT NULL,
  reason text NOT NULL,
  ban_type text NOT NULL DEFAULT 'temporary',
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  is_active boolean NOT NULL DEFAULT true
);

CREATE INDEX idx_user_bans_active ON public.user_bans(user_id, is_active);

-- Enable RLS on all new tables
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ticket_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_warnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_bans ENABLE ROW LEVEL SECURITY;

-- RLS Policies for permissions (read-only for admins)
CREATE POLICY "Admins can view permissions" ON public.permissions
  FOR SELECT USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Super admins can manage permissions" ON public.permissions
  FOR ALL USING (has_role(auth.uid(), 'super_admin'));

-- RLS Policies for role_permissions
CREATE POLICY "Admins can view role_permissions" ON public.role_permissions
  FOR SELECT USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Super admins can manage role_permissions" ON public.role_permissions
  FOR ALL USING (has_role(auth.uid(), 'super_admin'));

-- RLS Policies for site_settings
CREATE POLICY "Admins can view site_settings" ON public.site_settings
  FOR SELECT USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Super admins can manage site_settings" ON public.site_settings
  FOR ALL USING (has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Admins can update site_settings" ON public.site_settings
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for legal_documents
CREATE POLICY "Anyone can view active legal documents" ON public.legal_documents
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage legal documents" ON public.legal_documents
  FOR ALL USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

-- RLS Policies for tickets
CREATE POLICY "Users can view their own tickets" ON public.tickets
  FOR SELECT USING (
    user_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Users can create tickets" ON public.tickets
  FOR INSERT WITH CHECK (
    user_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Support and above can view all tickets" ON public.tickets
  FOR SELECT USING (
    has_role(auth.uid(), 'support') OR
    has_role(auth.uid(), 'moderator') OR
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Support and above can update tickets" ON public.tickets
  FOR UPDATE USING (
    has_role(auth.uid(), 'support') OR
    has_role(auth.uid(), 'moderator') OR
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

-- RLS Policies for ticket_messages
CREATE POLICY "Users can view their ticket messages" ON public.ticket_messages
  FOR SELECT USING (
    ticket_id IN (
      SELECT id FROM tickets WHERE user_id IN (
        SELECT id FROM profiles WHERE user_id = auth.uid()
      )
    ) AND is_internal = false
  );

CREATE POLICY "Support can view all messages" ON public.ticket_messages
  FOR SELECT USING (
    has_role(auth.uid(), 'support') OR
    has_role(auth.uid(), 'moderator') OR
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Users can create messages on their tickets" ON public.ticket_messages
  FOR INSERT WITH CHECK (
    (ticket_id IN (
      SELECT id FROM tickets WHERE user_id IN (
        SELECT id FROM profiles WHERE user_id = auth.uid()
      )
    ) AND is_internal = false)
    OR
    (has_role(auth.uid(), 'support') OR
     has_role(auth.uid(), 'moderator') OR
     has_role(auth.uid(), 'admin') OR 
     has_role(auth.uid(), 'super_admin'))
  );

-- RLS Policies for security_events
CREATE POLICY "Admins can view security events" ON public.security_events
  FOR SELECT USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "System can insert security events" ON public.security_events
  FOR INSERT WITH CHECK (true);

-- RLS Policies for user_warnings
CREATE POLICY "Moderators can view warnings" ON public.user_warnings
  FOR SELECT USING (
    has_role(auth.uid(), 'moderator') OR
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Moderators can create warnings" ON public.user_warnings
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'moderator') OR
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

-- RLS Policies for user_bans
CREATE POLICY "Admins can view bans" ON public.user_bans
  FOR SELECT USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

CREATE POLICY "Admins can manage bans" ON public.user_bans
  FOR ALL USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'super_admin')
  );

-- Update get_user_role function to handle new roles
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id uuid)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role
  FROM public.user_roles
  WHERE user_id = _user_id
  ORDER BY 
    CASE role
      WHEN 'super_admin' THEN 1
      WHEN 'admin' THEN 2
      WHEN 'moderator' THEN 3
      WHEN 'author' THEN 4
      WHEN 'support' THEN 5
      WHEN 'user' THEN 6
    END
  LIMIT 1
$$;

-- Insert default permissions
INSERT INTO public.permissions (code, name, description, category) VALUES
-- User management
('users.view', 'View Users', 'View user list and details', 'users'),
('users.edit', 'Edit Users', 'Edit user profiles', 'users'),
('users.ban', 'Ban Users', 'Ban/unban users', 'users'),
('users.roles', 'Manage Roles', 'Assign/remove user roles', 'users'),
-- Content moderation
('mods.view', 'View All Mods', 'View all mods including pending', 'moderation'),
('mods.approve', 'Approve Mods', 'Approve pending mods', 'moderation'),
('mods.reject', 'Reject Mods', 'Reject mods with reason', 'moderation'),
('mods.delete', 'Delete Mods', 'Delete any mod', 'moderation'),
('mods.feature', 'Feature Mods', 'Mark mods as featured', 'moderation'),
-- Reports
('reports.view', 'View Reports', 'View all reports', 'reports'),
('reports.resolve', 'Resolve Reports', 'Resolve/dismiss reports', 'reports'),
-- Tickets
('tickets.view', 'View Tickets', 'View support tickets', 'support'),
('tickets.respond', 'Respond to Tickets', 'Send responses to tickets', 'support'),
('tickets.assign', 'Assign Tickets', 'Assign tickets to staff', 'support'),
-- Platform
('platform.settings', 'Platform Settings', 'Manage platform configuration', 'platform'),
('platform.categories', 'Manage Categories', 'Add/edit categories', 'platform'),
('platform.legal', 'Legal Documents', 'Manage legal pages', 'platform'),
-- Security
('security.view', 'View Security', 'View security events', 'security'),
('security.manage', 'Manage Security', 'Manage security settings', 'security'),
-- Audit
('audit.view', 'View Audit Logs', 'View system audit logs', 'audit');

-- Insert default role permissions
-- Super Admin gets all permissions
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'super_admin', id FROM public.permissions;

-- Admin gets most permissions except security.manage
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'admin', id FROM public.permissions 
WHERE code NOT IN ('security.manage', 'users.roles');

-- Moderator gets moderation and reports permissions
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'moderator', id FROM public.permissions 
WHERE category IN ('moderation', 'reports') 
   OR code IN ('users.view');

-- Support gets ticket permissions
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'support', id FROM public.permissions 
WHERE category = 'support' OR code = 'users.view';

-- Triggers for updated_at
CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON public.site_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tickets_updated_at
  BEFORE UPDATE ON public.tickets
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();