
-- ============================================
-- Platform Feature Flags
-- ============================================
CREATE TABLE public.platform_features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'general',
  enabled BOOLEAN NOT NULL DEFAULT true,
  risk_level TEXT NOT NULL DEFAULT 'low',
  requires_confirmation BOOLEAN NOT NULL DEFAULT false,
  default_value BOOLEAN NOT NULL DEFAULT true,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Validation trigger for risk_level
CREATE OR REPLACE FUNCTION public.validate_risk_level()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.risk_level NOT IN ('low', 'medium', 'high') THEN
    RAISE EXCEPTION 'Invalid risk_level: %. Must be low, medium, or high', NEW.risk_level;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER validate_platform_features_risk_level
BEFORE INSERT OR UPDATE ON public.platform_features
FOR EACH ROW EXECUTE FUNCTION public.validate_risk_level();

-- Auto-update updated_at
CREATE TRIGGER update_platform_features_updated_at
BEFORE UPDATE ON public.platform_features
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- Feature Change History (for rollback + audit)
-- ============================================
CREATE TABLE public.platform_feature_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature_id UUID NOT NULL REFERENCES public.platform_features(id) ON DELETE CASCADE,
  feature_key TEXT NOT NULL,
  old_value BOOLEAN NOT NULL,
  new_value BOOLEAN NOT NULL,
  changed_by UUID NOT NULL,
  change_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================
-- RLS
-- ============================================
ALTER TABLE public.platform_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_feature_history ENABLE ROW LEVEL SECURITY;

-- Anyone can read features (frontend needs them for rendering)
CREATE POLICY "Anyone can view platform features"
ON public.platform_features FOR SELECT USING (true);

-- Only users with platform.features permission can modify
CREATE POLICY "Platform admins can manage features"
ON public.platform_features FOR ALL
USING (has_permission(auth.uid(), 'platform.features'));

-- History: readable by feature admins
CREATE POLICY "Platform admins can view feature history"
ON public.platform_feature_history FOR SELECT
USING (has_permission(auth.uid(), 'platform.features'));

-- History: insertable by feature admins
CREATE POLICY "Platform admins can insert feature history"
ON public.platform_feature_history FOR INSERT
WITH CHECK (has_permission(auth.uid(), 'platform.features'));

-- ============================================
-- Seed default feature flags
-- ============================================
INSERT INTO public.platform_features (key, name, description, category, enabled, risk_level, requires_confirmation) VALUES
  ('comments', 'Комментарии', 'Система комментариев на страницах модов', 'social', true, 'medium', true),
  ('ratings', 'Рейтинги', 'Система оценки модов пользователями', 'social', true, 'medium', true),
  ('favorites', 'Избранное', 'Добавление модов в избранное', 'social', true, 'low', false),
  ('search', 'Поиск', 'Поиск и фильтрация по каталогу модов', 'content', true, 'high', true),
  ('mod_upload', 'Загрузка модов', 'Возможность авторам загружать моды', 'content', true, 'high', true),
  ('reports', 'Жалобы', 'Система жалоб на контент и пользователей', 'moderation', true, 'medium', true),
  ('analytics_authors', 'Аналитика авторов', 'Статистика и метрики для авторов', 'analytics', true, 'low', false),
  ('notifications', 'Уведомления', 'Система уведомлений пользователей', 'system', true, 'high', true),
  ('registration', 'Регистрация', 'Регистрация новых пользователей', 'system', true, 'high', true),
  ('featured_mods', 'Рекомендуемые моды', 'Блок рекомендуемых модов на главной', 'content', true, 'low', false),
  ('mod_versions', 'Версии модов', 'Управление версиями модов авторами', 'content', true, 'medium', true),
  ('user_profiles', 'Профили пользователей', 'Публичные профили пользователей', 'social', true, 'medium', true);

-- ============================================
-- Permission: platform.features (if not exists)
-- ============================================
INSERT INTO public.permissions (code, name, description, category)
SELECT 'platform.features', 'Управление функциями', 'Управление feature flags платформы', 'platform'
WHERE NOT EXISTS (SELECT 1 FROM public.permissions WHERE code = 'platform.features');

-- Grant to super_admin
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'super_admin', id FROM public.permissions WHERE code = 'platform.features'
AND NOT EXISTS (
  SELECT 1 FROM public.role_permissions rp 
  JOIN public.permissions p ON rp.permission_id = p.id 
  WHERE rp.role = 'super_admin' AND p.code = 'platform.features'
);

-- Grant to admin
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'admin', id FROM public.permissions WHERE code = 'platform.features'
AND NOT EXISTS (
  SELECT 1 FROM public.role_permissions rp 
  JOIN public.permissions p ON rp.permission_id = p.id 
  WHERE rp.role = 'admin' AND p.code = 'platform.features'
);

-- ============================================
-- Function: toggle feature with history logging
-- ============================================
CREATE OR REPLACE FUNCTION public.toggle_platform_feature(
  _feature_key TEXT,
  _new_value BOOLEAN,
  _reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _feature RECORD;
  _user_id UUID;
BEGIN
  _user_id := auth.uid();
  
  -- Check permission
  IF NOT has_permission(_user_id, 'platform.features') THEN
    RAISE EXCEPTION 'Access denied: missing platform.features permission';
  END IF;
  
  -- Get current feature
  SELECT * INTO _feature FROM platform_features WHERE key = _feature_key;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Feature not found: %', _feature_key;
  END IF;
  
  -- Skip if no change
  IF _feature.enabled = _new_value THEN
    RETURN _new_value;
  END IF;
  
  -- Log history
  INSERT INTO platform_feature_history (feature_id, feature_key, old_value, new_value, changed_by, change_reason)
  VALUES (_feature.id, _feature_key, _feature.enabled, _new_value, _user_id, _reason);
  
  -- Update feature
  UPDATE platform_features SET enabled = _new_value WHERE key = _feature_key;
  
  -- Audit log
  INSERT INTO admin_logs (admin_id, action, target_type, target_id, details)
  VALUES (
    _user_id,
    CASE WHEN _new_value THEN 'feature_enabled' ELSE 'feature_disabled' END,
    'feature',
    _feature.id,
    jsonb_build_object('key', _feature_key, 'old_value', _feature.enabled, 'new_value', _new_value, 'reason', _reason, 'risk_level', _feature.risk_level)
  );
  
  RETURN _new_value;
END;
$$;

-- ============================================
-- Function: rollback feature to previous state
-- ============================================
CREATE OR REPLACE FUNCTION public.rollback_platform_feature(
  _history_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _history RECORD;
  _user_id UUID;
BEGIN
  _user_id := auth.uid();
  
  IF NOT has_permission(_user_id, 'platform.features') THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  
  SELECT * INTO _history FROM platform_feature_history WHERE id = _history_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'History entry not found';
  END IF;
  
  -- Rollback = toggle back to old_value
  PERFORM toggle_platform_feature(_history.feature_key, _history.old_value, 'Rollback to previous state');
  
  RETURN TRUE;
END;
$$;
