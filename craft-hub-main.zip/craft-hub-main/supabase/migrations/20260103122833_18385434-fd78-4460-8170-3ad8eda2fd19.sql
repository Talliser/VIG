-- Create project_types table for dynamic content types (Mods, Resource packs, etc.)
CREATE TABLE public.project_types (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  name_plural TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  enabled BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.project_types ENABLE ROW LEVEL SECURITY;

-- Everyone can view enabled project types
CREATE POLICY "Project types are viewable by everyone"
ON public.project_types
FOR SELECT
USING (enabled = true);

-- Only admins can manage project types
CREATE POLICY "Admins can manage project types"
ON public.project_types
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add project_type column to mods table
ALTER TABLE public.mods 
ADD COLUMN project_type TEXT NOT NULL DEFAULT 'mods';

-- Create storage bucket for mod files
INSERT INTO storage.buckets (id, name, public) VALUES ('mod-files', 'mod-files', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('mod-icons', 'mod-icons', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('mod-banners', 'mod-banners', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('mod-gallery', 'mod-gallery', true);

-- Storage policies for mod-icons
CREATE POLICY "Anyone can view mod icons"
ON storage.objects FOR SELECT
USING (bucket_id = 'mod-icons');

CREATE POLICY "Authors can upload mod icons"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'mod-icons' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can update their mod icons"
ON storage.objects FOR UPDATE
USING (bucket_id = 'mod-icons' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can delete their mod icons"
ON storage.objects FOR DELETE
USING (bucket_id = 'mod-icons' AND auth.uid() IS NOT NULL);

-- Storage policies for mod-banners
CREATE POLICY "Anyone can view mod banners"
ON storage.objects FOR SELECT
USING (bucket_id = 'mod-banners');

CREATE POLICY "Authors can upload mod banners"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'mod-banners' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can update their mod banners"
ON storage.objects FOR UPDATE
USING (bucket_id = 'mod-banners' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can delete their mod banners"
ON storage.objects FOR DELETE
USING (bucket_id = 'mod-banners' AND auth.uid() IS NOT NULL);

-- Storage policies for mod-gallery
CREATE POLICY "Anyone can view mod gallery"
ON storage.objects FOR SELECT
USING (bucket_id = 'mod-gallery');

CREATE POLICY "Authors can upload gallery images"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'mod-gallery' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can update gallery images"
ON storage.objects FOR UPDATE
USING (bucket_id = 'mod-gallery' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can delete gallery images"
ON storage.objects FOR DELETE
USING (bucket_id = 'mod-gallery' AND auth.uid() IS NOT NULL);

-- Storage policies for mod-files
CREATE POLICY "Anyone can view mod files"
ON storage.objects FOR SELECT
USING (bucket_id = 'mod-files');

CREATE POLICY "Authors can upload mod files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'mod-files' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can update mod files"
ON storage.objects FOR UPDATE
USING (bucket_id = 'mod-files' AND auth.uid() IS NOT NULL);

CREATE POLICY "Authors can delete mod files"
ON storage.objects FOR DELETE
USING (bucket_id = 'mod-files' AND auth.uid() IS NOT NULL);

-- Insert default project types
INSERT INTO public.project_types (slug, name, name_plural, description, icon, sort_order) VALUES
('mods', 'Мод', 'Моды', 'Модификации для игры', '🔧', 1),
('resource-packs', 'Ресурс-пак', 'Ресурс-паки', 'Текстуры и звуки', '🎨', 2),
('data-packs', 'Дата-пак', 'Дата-паки', 'Изменения механик без кода', '📊', 3),
('shaders', 'Шейдер', 'Шейдеры', 'Графические улучшения', '✨', 4),
('modpacks', 'Мод-пак', 'Мод-паки', 'Сборки модов', '📦', 5),
('plugins', 'Плагин', 'Плагины', 'Серверные плагины', '🔌', 6);

-- Trigger for updated_at
CREATE TRIGGER update_project_types_updated_at
BEFORE UPDATE ON public.project_types
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();