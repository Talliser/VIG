
-- =============================================
-- PHASE 1: Extended User Profiles System
-- =============================================

-- 1. Extend profiles table
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS banner text,
  ADD COLUMN IF NOT EXISTS nickname text,
  ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS xp integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS level integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS level_name text DEFAULT 'Новичок',
  ADD COLUMN IF NOT EXISTS is_frozen boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS frozen_by uuid,
  ADD COLUMN IF NOT EXISTS frozen_at timestamptz,
  ADD COLUMN IF NOT EXISTS freeze_reason text,
  ADD COLUMN IF NOT EXISTS privacy_settings jsonb DEFAULT '{"hide_followers":false,"hide_registration_date":false,"hide_activity":false}'::jsonb,
  ADD COLUMN IF NOT EXISTS last_username_change timestamptz,
  ADD COLUMN IF NOT EXISTS referral_code text,
  ADD COLUMN IF NOT EXISTS referred_by uuid;

-- Unique constraint on nickname and referral_code
CREATE UNIQUE INDEX IF NOT EXISTS profiles_nickname_unique ON public.profiles (nickname) WHERE nickname IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS profiles_referral_code_unique ON public.profiles (referral_code) WHERE referral_code IS NOT NULL;

-- 2. user_badges table
CREATE TABLE IF NOT EXISTS public.user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  badge_key text NOT NULL,
  badge_name text NOT NULL,
  badge_description text,
  badge_icon text,
  awarded_at timestamptz NOT NULL DEFAULT now(),
  awarded_by uuid,
  is_auto boolean DEFAULT false,
  expires_at timestamptz
);

ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view badges" ON public.user_badges FOR SELECT USING (true);
CREATE POLICY "Staff can manage badges" ON public.user_badges FOR INSERT WITH CHECK (public.is_staff(auth.uid()));
CREATE POLICY "Staff can update badges" ON public.user_badges FOR UPDATE USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff can delete badges" ON public.user_badges FOR DELETE USING (public.is_staff(auth.uid()));

-- 3. user_follows table
CREATE TABLE IF NOT EXISTS public.user_follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(follower_id, following_id)
);

ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view follows" ON public.user_follows FOR SELECT USING (true);
CREATE POLICY "Authenticated users can follow" ON public.user_follows FOR INSERT WITH CHECK (
  follower_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);
CREATE POLICY "Users can unfollow" ON public.user_follows FOR DELETE USING (
  follower_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);

-- 4. user_xp_log table
CREATE TABLE IF NOT EXISTS public.user_xp_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  reason text NOT NULL,
  source_type text,
  source_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_xp_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own xp log" ON public.user_xp_log FOR SELECT USING (
  profile_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);
CREATE POLICY "Staff can view all xp logs" ON public.user_xp_log FOR SELECT USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff can manage xp logs" ON public.user_xp_log FOR ALL USING (public.is_staff(auth.uid()));

-- 5. user_login_history table
CREATE TABLE IF NOT EXISTS public.user_login_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  ip_hash text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_login_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own login history" ON public.user_login_history FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Staff can view all login history" ON public.user_login_history FOR SELECT USING (public.is_staff(auth.uid()));

-- 6. user_appeals table
CREATE TABLE IF NOT EXISTS public.user_appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  target_id uuid,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_appeals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can create appeals" ON public.user_appeals FOR INSERT WITH CHECK (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);
CREATE POLICY "Users can view own appeals" ON public.user_appeals FOR SELECT USING (
  user_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
);
CREATE POLICY "Staff can manage appeals" ON public.user_appeals FOR ALL USING (public.is_staff(auth.uid()));

-- 7. Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('user-avatars', 'user-avatars', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('user-banners', 'user-banners', true) ON CONFLICT (id) DO NOTHING;

-- Storage policies for user-avatars
CREATE POLICY "Avatar images are publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'user-avatars');
CREATE POLICY "Users can upload their own avatar" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'user-avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update their own avatar" ON storage.objects FOR UPDATE USING (bucket_id = 'user-avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete their own avatar" ON storage.objects FOR DELETE USING (bucket_id = 'user-avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Storage policies for user-banners
CREATE POLICY "Banner images are publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'user-banners');
CREATE POLICY "Users can upload their own banner" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'user-banners' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update their own banner" ON storage.objects FOR UPDATE USING (bucket_id = 'user-banners' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete their own banner" ON storage.objects FOR DELETE USING (bucket_id = 'user-banners' AND auth.uid()::text = (storage.foldername(name))[1]);

-- 8. DB Functions

-- Calculate level from XP
CREATE OR REPLACE FUNCTION public.calculate_level(xp_value integer)
RETURNS integer
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT CASE
    WHEN xp_value >= 1000 THEN 3
    WHEN xp_value >= 500 THEN 2
    WHEN xp_value >= 100 THEN 1
    ELSE 0
  END
$$;

-- Get level name
CREATE OR REPLACE FUNCTION public.get_level_name(level_value integer)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT CASE level_value
    WHEN 0 THEN 'Новичок'
    WHEN 1 THEN 'Кузнец идей'
    WHEN 2 THEN 'Мастер модов'
    WHEN 3 THEN 'Легенда Майнкрафта'
    ELSE 'Новичок'
  END
$$;

-- Award XP (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.award_xp(
  _profile_id uuid,
  _amount integer,
  _reason text,
  _source_type text DEFAULT NULL,
  _source_id uuid DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _is_frozen boolean;
  _new_xp integer;
  _new_level integer;
  _new_level_name text;
BEGIN
  -- Check if profile is frozen
  SELECT is_frozen INTO _is_frozen FROM profiles WHERE id = _profile_id;
  IF _is_frozen THEN
    RETURN; -- Silently skip XP for frozen profiles
  END IF;

  -- Log XP change
  INSERT INTO user_xp_log (profile_id, amount, reason, source_type, source_id)
  VALUES (_profile_id, _amount, _reason, _source_type, _source_id);

  -- Update XP (prevent negative)
  UPDATE profiles 
  SET xp = GREATEST(0, xp + _amount),
      level = calculate_level(GREATEST(0, xp + _amount)),
      level_name = get_level_name(calculate_level(GREATEST(0, xp + _amount)))
  WHERE id = _profile_id
  RETURNING xp INTO _new_xp;
END;
$$;

-- Auto-generate referral code on profile insert
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.referral_code IS NULL THEN
    NEW.referral_code := upper(substr(md5(random()::text || NEW.id::text), 1, 8));
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_generate_referral_code ON public.profiles;
CREATE TRIGGER trigger_generate_referral_code
  BEFORE INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_referral_code();

-- Username change rate limit trigger
CREATE OR REPLACE FUNCTION public.check_username_change_rate()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF OLD.username IS DISTINCT FROM NEW.username THEN
    IF OLD.last_username_change IS NOT NULL 
       AND OLD.last_username_change > now() - interval '7 days' THEN
      RAISE EXCEPTION 'Username can only be changed once every 7 days. Next change available after %', 
        OLD.last_username_change + interval '7 days';
    END IF;
    NEW.last_username_change := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_check_username_change ON public.profiles;
CREATE TRIGGER trigger_check_username_change
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.check_username_change_rate();

-- Allow staff to update any profile (for freeze/xp/badges management)
CREATE POLICY "Staff can update any profile" ON public.profiles FOR UPDATE USING (public.is_staff(auth.uid()));

-- Add new permissions for profile management
INSERT INTO public.permissions (code, name, category, description) VALUES
  ('users.freeze', 'Freeze User Profiles', 'Users', 'Can freeze/unfreeze user profiles'),
  ('users.xp', 'Manage User XP', 'Users', 'Can edit user XP and levels'),
  ('users.badges', 'Manage User Badges', 'Users', 'Can award/remove badges'),
  ('users.verify', 'Verify Authors', 'Users', 'Can verify author profiles')
ON CONFLICT DO NOTHING;

-- Grant new permissions to appropriate roles
INSERT INTO public.role_permissions (role, permission_id)
SELECT 'super_admin', id FROM public.permissions WHERE code IN ('users.freeze', 'users.xp', 'users.badges', 'users.verify')
ON CONFLICT DO NOTHING;

INSERT INTO public.role_permissions (role, permission_id)
SELECT 'admin', id FROM public.permissions WHERE code IN ('users.freeze', 'users.badges', 'users.verify')
ON CONFLICT DO NOTHING;

-- Generate referral codes for existing profiles that don't have one
UPDATE public.profiles SET referral_code = upper(substr(md5(random()::text || id::text), 1, 8)) WHERE referral_code IS NULL;
