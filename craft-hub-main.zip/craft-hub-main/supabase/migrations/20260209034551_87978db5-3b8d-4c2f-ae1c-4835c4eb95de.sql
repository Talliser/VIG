
-- Site Control: Pages and Blocks system
CREATE TABLE public.site_pages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  icon text,
  sort_order integer NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.site_blocks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_id uuid NOT NULL REFERENCES public.site_pages(id) ON DELETE CASCADE,
  key text NOT NULL,
  name text NOT NULL,
  block_type text NOT NULL DEFAULT 'section',
  description text,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  visible boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  visibility_roles text[] NOT NULL DEFAULT '{}'::text[],
  status text NOT NULL DEFAULT 'published',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(page_id, key)
);

CREATE TABLE public.site_block_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  block_id uuid NOT NULL REFERENCES public.site_blocks(id) ON DELETE CASCADE,
  changed_by uuid NOT NULL,
  old_config jsonb,
  new_config jsonb,
  old_visible boolean,
  new_visible boolean,
  change_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- RLS
ALTER TABLE public.site_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_block_history ENABLE ROW LEVEL SECURITY;

-- Everyone can read pages and blocks (needed for frontend rendering)
CREATE POLICY "Anyone can view site pages" ON public.site_pages FOR SELECT USING (true);
CREATE POLICY "Anyone can view site blocks" ON public.site_blocks FOR SELECT USING (true);

-- Only admins with platform.settings can manage
CREATE POLICY "Admins can manage site pages" ON public.site_pages FOR ALL USING (has_permission(auth.uid(), 'platform.settings'));
CREATE POLICY "Admins can manage site blocks" ON public.site_blocks FOR ALL USING (has_permission(auth.uid(), 'platform.settings'));
CREATE POLICY "Admins can view block history" ON public.site_block_history FOR SELECT USING (has_permission(auth.uid(), 'platform.settings'));
CREATE POLICY "Admins can insert block history" ON public.site_block_history FOR INSERT WITH CHECK (has_permission(auth.uid(), 'platform.settings'));

-- Seed default pages and blocks
INSERT INTO public.site_pages (key, name, description, icon, sort_order) VALUES
  ('home', 'Главная', 'Главная страница платформы', '🏠', 0),
  ('mod_detail', 'Страница мода', 'Детальная страница мода', '📦', 1),
  ('mods_list', 'Каталог', 'Список модов с фильтрами', '📋', 2),
  ('author_profile', 'Профиль автора', 'Публичный профиль автора', '👤', 3),
  ('author_studio', 'Author Studio', 'Панель автора', '🎨', 4);

-- Home page blocks
INSERT INTO public.site_blocks (page_id, key, name, block_type, description, sort_order, config) VALUES
  ((SELECT id FROM site_pages WHERE key='home'), 'hero', 'Hero баннер', 'hero', 'Главный баннер с CTA', 0, '{"title":"Откройте мир модов Minecraft","subtitle":"Тысячи модов для Java и Bedrock Edition","cta_text":"Смотреть моды","cta_link":"/mods"}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='home'), 'featured', 'Популярные моды', 'list', 'Блок с рекомендуемыми модами', 1, '{"limit":6,"show_rating":true}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='home'), 'recent', 'Новые моды', 'list', 'Блок с последними модами', 2, '{"limit":8,"sort":"created_at"}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='home'), 'stats', 'Статистика', 'stats', 'Счётчики платформы', 3, '{"show_users":true,"show_mods":true,"show_downloads":true}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='home'), 'categories', 'Категории', 'grid', 'Сетка категорий', 4, '{"columns":4}'::jsonb);

-- Mod detail blocks
INSERT INTO public.site_blocks (page_id, key, name, block_type, description, sort_order, config) VALUES
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'header', 'Заголовок мода', 'header', 'Название, автор, иконка', 0, '{}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'description', 'Описание', 'text', 'Полное описание мода', 1, '{}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'gallery', 'Галерея', 'gallery', 'Скриншоты и медиа', 2, '{}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'versions', 'Версии', 'list', 'Список версий для скачивания', 3, '{}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'comments', 'Комментарии', 'comments', 'Секция комментариев', 4, '{"allow_replies":true}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'rating', 'Рейтинг', 'rating', 'Система оценок', 5, '{}'::jsonb),
  ((SELECT id FROM site_pages WHERE key='mod_detail'), 'related', 'Похожие моды', 'list', 'Рекомендованные моды', 6, '{"limit":4}'::jsonb);

-- Function to save block with history
CREATE OR REPLACE FUNCTION public.update_site_block(
  _block_id uuid,
  _config jsonb DEFAULT NULL,
  _visible boolean DEFAULT NULL,
  _name text DEFAULT NULL,
  _sort_order integer DEFAULT NULL,
  _reason text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _old_config jsonb;
  _old_visible boolean;
BEGIN
  -- Get current values
  SELECT config, visible INTO _old_config, _old_visible
  FROM site_blocks WHERE id = _block_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Block not found';
  END IF;

  -- Log history
  INSERT INTO site_block_history (block_id, changed_by, old_config, new_config, old_visible, new_visible, change_reason)
  VALUES (_block_id, auth.uid(), _old_config, COALESCE(_config, _old_config), _old_visible, COALESCE(_visible, _old_visible), _reason);

  -- Update block
  UPDATE site_blocks SET
    config = COALESCE(_config, config),
    visible = COALESCE(_visible, visible),
    name = COALESCE(_name, name),
    sort_order = COALESCE(_sort_order, sort_order),
    updated_at = now()
  WHERE id = _block_id;

  -- Log admin action
  PERFORM log_admin_action('site_block_updated', _target_type := 'site_block', _target_id := _block_id::text, _details := jsonb_build_object('reason', _reason));

  RETURN true;
END;
$$;
