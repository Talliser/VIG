import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  console.log("[bootstrap-super-admin] Request received");

  try {
    const { bootstrap_token } = await req.json();

    // 1. Validate bootstrap secret
    const BOOTSTRAP_SECRET = Deno.env.get("BOOTSTRAP_SECRET");
    if (!BOOTSTRAP_SECRET) {
      console.error("[bootstrap-super-admin] BOOTSTRAP_SECRET not configured");
      return new Response(
        JSON.stringify({ error: "Bootstrap not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (bootstrap_token !== BOOTSTRAP_SECRET) {
      console.warn("[bootstrap-super-admin] Invalid bootstrap token provided");
      return new Response(
        JSON.stringify({ error: "Invalid bootstrap token" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Validate JWT from Authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      console.warn("[bootstrap-super-admin] Missing or invalid Authorization header");
      return new Response(
        JSON.stringify({ error: "Authorization required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 3. Create Supabase clients
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Auth client for validating user
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Service role client for privileged operations
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    // 4. Validate user session
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error("[bootstrap-super-admin] JWT validation failed:", claimsError?.message);
      return new Response(
        JSON.stringify({ error: "Invalid session" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userId = claimsData.claims.sub;
    const userEmail = claimsData.claims.email;
    console.log(`[bootstrap-super-admin] User validated: ${userEmail} (${userId})`);

    // 5. Check if bootstrap is still available
    const { data: canBootstrap, error: checkError } = await supabaseAdmin.rpc("can_bootstrap_super_admin");
    
    if (checkError) {
      console.error("[bootstrap-super-admin] Failed to check bootstrap status:", checkError.message);
      return new Response(
        JSON.stringify({ error: "Failed to verify bootstrap status" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!canBootstrap) {
      console.warn("[bootstrap-super-admin] Bootstrap already completed - super_admin exists");
      return new Response(
        JSON.stringify({ error: "Bootstrap already completed. Super Admin exists." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 6. Assign super_admin role using service role (bypasses RLS)
    const { error: roleError } = await supabaseAdmin
      .from("user_roles")
      .insert({ 
        user_id: userId, 
        role: "super_admin" 
      });

    if (roleError) {
      console.error("[bootstrap-super-admin] Failed to assign role:", roleError.message);
      return new Response(
        JSON.stringify({ error: "Failed to assign role", details: roleError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[bootstrap-super-admin] super_admin role assigned to ${userEmail}`);

    // 7. Log to admin_logs for audit
    const { error: logError } = await supabaseAdmin.from("admin_logs").insert({
      admin_id: userId,
      action: "bootstrap_super_admin",
      target_type: "user",
      target_id: userId,
      details: {
        email: userEmail,
        method: "bootstrap",
        timestamp: new Date().toISOString(),
      },
    });

    if (logError) {
      console.warn("[bootstrap-super-admin] Failed to create audit log:", logError.message);
      // Don't fail the request, role was already assigned
    }

    console.log("[bootstrap-super-admin] Bootstrap completed successfully");

    return new Response(
      JSON.stringify({
        success: true,
        message: "Super Admin role assigned successfully",
        user_id: userId,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("[bootstrap-super-admin] Unexpected error:", errorMessage);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
