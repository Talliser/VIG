import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface AuthRequest {
  action: 'login' | 'signup';
  email: string;
  password: string;
  captchaToken: string;
  username?: string;
}

// Hash IP for rate limiting
function hashIP(ip: string): string {
  const encoder = new TextEncoder();
  const data = encoder.encode(ip + Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'));
  return Array.from(new Uint8Array(data))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
    .substring(0, 32);
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, email, password, captchaToken, username }: AuthRequest = await req.json();

    // Validate required fields
    if (!action || !email || !password || !captchaToken) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify CAPTCHA first
    const secretKey = Deno.env.get('TURNSTILE_SECRET_KEY');
    if (!secretKey) {
      console.error('TURNSTILE_SECRET_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'Server configuration error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const formData = new FormData();
    formData.append('secret', secretKey);
    formData.append('response', captchaToken);

    const captchaResponse = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      body: formData,
    });

    const captchaResult = await captchaResponse.json();
    
    if (!captchaResult.success) {
      console.error('CAPTCHA verification failed:', captchaResult);
      return new Response(
        JSON.stringify({ success: false, error: 'CAPTCHA verification failed. Please try again.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase clients
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const anonClient = createClient(supabaseUrl, supabaseAnonKey);

    // Get client IP for rate limiting
    const clientIP = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                     req.headers.get('cf-connecting-ip') || 
                     'unknown';
    const ipHash = hashIP(clientIP);

    // Rate limiting: 5 attempts per 15 minutes per IP
    const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    
    const { data: rateData, error: rateError } = await adminClient
      .from('auth_rate_limits')
      .select('*')
      .eq('ip_hash', ipHash)
      .eq('action_type', action)
      .gte('window_start', fifteenMinutesAgo)
      .single();

    if (rateData && rateData.attempt_count >= 5) {
      console.warn(`Rate limit exceeded for IP hash: ${ipHash}`);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Too many attempts. Please try again in 15 minutes.' 
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update rate limit counter
    if (rateData) {
      await adminClient
        .from('auth_rate_limits')
        .update({ attempt_count: rateData.attempt_count + 1 })
        .eq('id', rateData.id);
    } else {
      await adminClient
        .from('auth_rate_limits')
        .insert({
          ip_hash: ipHash,
          action_type: action,
          attempt_count: 1,
          window_start: new Date().toISOString()
        });
    }

    // Perform auth action
    if (action === 'login') {
      const { data, error } = await anonClient.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('Login error:', error.message);
        
      // Log failed attempt
      try {
        await adminClient.from('security_events').insert({
          event_type: 'login_failed',
          severity: 'warning',
          ip_address: ipHash,
          details: { email, reason: error.message }
        });
      } catch (logErr) {
        console.error('Failed to log event:', logErr);
      }

        return new Response(
          JSON.stringify({ 
            success: false, 
            error: error.message.includes('Invalid login') 
              ? 'Invalid email or password' 
              : error.message 
          }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Clear rate limit on successful login
      if (rateData) {
        await adminClient
          .from('auth_rate_limits')
          .delete()
          .eq('id', rateData.id);
      }

      // Log successful login
      try {
        await adminClient.from('security_events').insert({
          event_type: 'login_success',
          user_id: data.user?.id,
          severity: 'info',
          ip_address: ipHash,
          details: { email }
        });
      } catch (logErr) {
        console.error('Failed to log event:', logErr);
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          session: data.session,
          user: data.user
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'signup') {
      // Validate username for signup
      if (!username || username.length < 3) {
        return new Response(
          JSON.stringify({ success: false, error: 'Username must be at least 3 characters' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        return new Response(
          JSON.stringify({ success: false, error: 'Username can only contain letters, numbers, and underscores' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if username is taken
      const { data: existingProfile } = await adminClient
        .from('profiles')
        .select('username')
        .ilike('username', username)
        .single();

      if (existingProfile) {
        return new Response(
          JSON.stringify({ success: false, error: 'Username is already taken' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Validate password strength
      if (password.length < 8) {
        return new Response(
          JSON.stringify({ success: false, error: 'Password must be at least 8 characters' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: 'Password must contain uppercase, lowercase, and a number' 
          }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data, error } = await anonClient.auth.signUp({
        email,
        password,
        options: {
          data: {
            username,
            display_name: username
          }
        }
      });

      if (error) {
        console.error('Signup error:', error.message);
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: error.message.includes('already registered') 
              ? 'This email is already registered' 
              : error.message 
          }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Log signup
      try {
        await adminClient.from('security_events').insert({
          event_type: 'signup_success',
          user_id: data.user?.id,
          severity: 'info',
          ip_address: ipHash,
          details: { email, username }
        });
      } catch (logErr) {
        console.error('Failed to log event:', logErr);
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Registration successful! Please check your email to confirm your account.',
          user: data.user
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Invalid action' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Auth error:', error);
    return new Response(
      JSON.stringify({ success: false, error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
