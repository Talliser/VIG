import Link from 'next/link';


export default function Header() {
return (
<header className="w-full border-b py-4">
<div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
<Link href="/" className="text-2xl font-semibold text-vig-700">VIG</Link>
<nav className="flex gap-4 items-center">
<Link href="/" className="text-sm">Home</Link>
<Link href="/compare" className="text-sm">Compare</Link>
<Link href="/reviews" className="text-sm">Reviews</Link>
</nav>
</div>
</header>
);
}