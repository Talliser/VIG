import Link from 'next/link';
import { Device } from '../types/device';
import RatingBadge from './RatingBadge';


export default function DeviceCard({ device }: { device: Device }) {
return (
<Link href={`/device/${device.id}`} className="block card p-4 rounded-2xl shadow-sm hover:shadow-md transition">
<div className="flex gap-4">
<img src={device.image ?? '/device-placeholder.png'} alt={device.name} className="w-24 h-24 object-contain rounded-lg" />
<div className="flex-1">
<div className="flex items-center justify-between">
<h3 className="text-lg font-medium">{device.name}</h3>
<RatingBadge score={device.ratings.overall} />
</div>
<p className="text-sm text-slate-500">{device.specs.soc} • {device.specs.display}</p>
<p className="mt-2 text-sm text-slate-600">{device.price ? `$${device.price}` : '—'}</p>
</div>
</div>
</Link>
);
}