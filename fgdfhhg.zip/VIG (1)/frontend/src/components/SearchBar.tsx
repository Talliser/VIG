import { useState } from 'react';


export default function SearchBar({ onSearch }: { onSearch: (q: string) => void }) {
const [value, setValue] = useState('');
return (
<div className="flex items-center gap-2">
<input
value={value}
onChange={(e) => setValue(e.target.value)}
placeholder="Поиск модели, SoC, серия..."
className="w-80 px-3 py-2 rounded-md border"
/>
<button
onClick={() => onSearch(value)}
className="px-3 py-2 rounded-md bg-vig-500 text-white"
>
Найти
</button>
</div>
);
}