export default function RatingBadge({ score }: { score: number }) {
    return (
    <div className="px-2 py-1 rounded-md bg-vig-50 text-vig-700 font-semibold">{score.toFixed(1)}</div>
    );
    }