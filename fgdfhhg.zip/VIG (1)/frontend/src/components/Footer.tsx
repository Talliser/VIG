export default function Footer() {
    return (
    <footer className="w-full border-t mt-12 py-6">
    <div className="max-w-6xl mx-auto px-4 text-sm text-slate-500">
    <p>VIG — независимый неофициальный каталог Vivo & IQOO. Мы не связаны с Vivo.</p>
    <p className="mt-2">© {new Date().getFullYear()} VIG — Verified Info Guide</p>
    </div>
    </footer>
    );
    }