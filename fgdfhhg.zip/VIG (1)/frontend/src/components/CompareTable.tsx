import { Device } from '../types/device';
return (
<div className="overflow-x-auto card p-4 rounded-xl">
<table className="min-w-full">
<thead>
<tr>
<th className="text-left p-2">Характеристика</th>
{devices.map((d) => (
<th key={d.id} className="p-2 text-left">{d.name}</th>
))}
</tr>
</thead>
<tbody>
<tr>
<td className="p-2 font-medium">SoC</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.specs.soc}</td>)}
</tr>
<tr>
<td className="p-2 font-medium">AnTuTu</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.specs.anTuTu ?? '—'}</td>)}
</tr>
<tr>
<td className="p-2 font-medium">Дисплей</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.specs.display}</td>)}
</tr>
<tr>
<td className="p-2 font-medium">Батарея</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.specs.battery} mAh</td>)}
</tr>
<tr>
<td className="p-2 font-medium">Камера</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.specs.camera}</td>)}
</tr>
<tr>
<td className="p-2 font-medium">Overall</td>
{devices.map((d) => <td key={d.id} className="p-2">{d.ratings.overall}</td>)}
</tr>
</tbody>
</table>
</div>
);
}