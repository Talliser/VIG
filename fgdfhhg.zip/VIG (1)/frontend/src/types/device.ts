export type Device = {
    id: string;
    name: string;
    series?: string;
    image?: string;
    releaseDate?: string;
    price?: number;
    specs: {
    soc: string;
    cpuScore?: number;
    anTuTu?: number;
    display: string;
    battery: number;
    camera: string;
    ram?: number;
    storage?: number;
    };
    ratings: {
    performance: number;
    camera: number;
    battery: number;
    display: number;
    overall: number;
    };
    };
