import { Device } from '../types/device';
id: 'iqoo-12',
name: 'iQOO 12',
series: 'iQOO',
image: '/device-placeholder.png',
releaseDate: '2024-10-12',
price: 499,
specs: {
soc: 'Snapdragon 8 Gen 3',
anTuTu: 1450000,
display: '6.78" LTPO 144Hz',
battery: 5000,
camera: '50MP Sony IMX',
ram: 12,
storage: 256
},
ratings: {
performance: 9.6,
camera: 8.3,
battery: 9.2,
display: 9.5,
overall: 9.2
}
},
{
id: 'vivo-x200',
name: 'Vivo X200',
series: 'Vivo X',
image: '/device-placeholder.png',
releaseDate: '2025-03-02',
price: 599,
specs: {
soc: 'Dimensity 9300',
anTuTu: 1320000,
display: '6.78" AMOLED 120Hz',
battery: 4800,
camera: '64MP Samsung',
ram: 12,
storage: 256
},
ratings: {
performance: 9.2,
camera: 9.0,
battery: 8.8,
display: 9.0,
overall: 9.0
}
}
];


export async function fetchDevices() {
// имитируем вызов API
return new Promise<Device[]>((res) => setTimeout(() => res(MOCK_DEVICES), 200));
}


export async function fetchDeviceById(id: string) {
return new Promise<Device | null>((res) =>
setTimeout(() => res(MOCK_DEVICES.find((d) => d.id === id) ?? null), 150)
);
}