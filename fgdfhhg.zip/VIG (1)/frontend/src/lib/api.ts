import { fetchDevices, fetchDeviceById } from './mockDevices';


export const api = {
getDevices: async () => {
return await fetchDevices();
},
getDevice: async (id: string) => {
return await fetchDeviceById(id);
}
};