/** @type {import('tailwindcss').Config} */
module.exports = {
content: ["./src/**/*.{ts,tsx,js,jsx,mdx}"],
theme: {
extend: {
colors: {
vig: {
50: '#f7fbff',
100: '#eef7ff',
500: '#5b6cff',
700: '#3b45d6'
}
}
}
},
plugins: []
};